package testcases;

import Constant.Constant;
import PageObjects.AlertPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

/**
 * TC5.19 - TC5.27: Alert Detail (alert-detail.html)
 */
public class AlertDetailTest extends BaseTest {

    private AlertPage alertPage;
    private static final String DETAIL_BASE =
        "https://evsc-production.up.railway.app/alert-detail.html";

    @BeforeMethod(alwaysRun = true)
    public void setup() {
        alertPage = new AlertPage();
        alertPage.navigateToStationPage();
        seedAlerts();
    }

    private void seedAlerts() {
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "localStorage.removeItem('evc-alerts-data-v1');" +
            "var d=[" +
            "{id:'ALT-1001',type:'Connection Lost',stationName:'Station 1',occurredAt:'2026-04-08T08:15:00',severity:'critical',status:'open',description:'Station connection lost',suggestion:'Check network',logs:[]}," +
            "{id:'ALT-1002',type:'Charger Overheating',stationName:'Station 3',occurredAt:'2026-04-08T09:40:00',severity:'critical',status:'open',description:'Temperature exceeded',suggestion:'Check cooling',logs:[]}," +
            "{id:'ALT-1003',type:'Charging Port Error',stationName:'Station 2',occurredAt:'2026-04-08T10:05:00',severity:'medium',status:'open',description:'Port error E-24',suggestion:'Reset port',logs:[]}" +
            "];" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));"
        );
    }

    private void openDetail(String id) {
        Constant.WEBDRIVER.navigate().to(DETAIL_BASE + "?id=" + id);
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER,
            java.time.Duration.ofSeconds(Constant.MEDIUM_TIMEOUT));
        wait.until(d -> ((JavascriptExecutor) d)
            .executeScript("return document.readyState").equals("complete"));
        try {
            wait.until(d -> {
                try { return !d.findElement(By.id("detailTitle")).getText().trim().isEmpty(); }
                catch (Exception e) { return false; }
            });
        } catch (Exception ignored) {}
    }

    private String getText(By loc) {
        try { return Constant.WEBDRIVER.findElement(loc).getText().trim(); }
        catch (Exception e) { return ""; }
    }

    @Test(description = "TC5.19 - Alert Detail hien thi dung tieu de loi")
    public void TC5_19_AlertDetailShowsCorrectTitle() {
        openDetail("ALT-1001");
        String title = getText(By.id("detailTitle"));
        Assert.assertFalse(title.isEmpty(), "TC5.19 FAIL: detailTitle rong");
        Assert.assertEquals(title, "Connection Lost",
            "TC5.19 FAIL: Title sai. Actual='" + title + "'");
    }

    @Test(description = "TC5.20 - Alert Detail hien thi dung thong tin station")
    public void TC5_20_AlertDetailShowsCorrectStation() {
        openDetail("ALT-1001");
        String station = getText(By.id("detailStation"));
        Assert.assertFalse(station.isEmpty(), "TC5.20 FAIL: detailStation rong");
        Assert.assertEquals(station, "Station 1",
            "TC5.20 FAIL: Station sai. Actual='" + station + "'");
    }

    @Test(description = "TC5.21 - Alert Detail hien thi dung thoi gian")
    public void TC5_21_AlertDetailShowsCorrectTimestamp() {
        openDetail("ALT-1001");
        String time = getText(By.id("detailTime"));
        Assert.assertFalse(time.isEmpty(), "TC5.21 FAIL: detailTime rong");
        Assert.assertTrue(
            time.matches(".*\\d{2}/\\d{2}/\\d{4}.*") || time.matches(".*\\d{2}:\\d{2}.*"),
            "TC5.21 FAIL: Timestamp sai format. Actual='" + time + "'");
    }

    @Test(description = "TC5.22 - Alert Detail hien thi dung severity badge")
    public void TC5_22_AlertDetailShowsCorrectSeverityBadge() {
        openDetail("ALT-1001");
        String badge = getText(By.id("detailSeverityBadge"));
        Assert.assertFalse(badge.isEmpty(), "TC5.22 FAIL: detailSeverityBadge rong");
        Assert.assertTrue(
            badge.equals("Critical") || badge.equals("High") || badge.equals("Medium") || badge.equals("Low"),
            "TC5.22 FAIL: Severity badge sai. Actual='" + badge + "'");
    }

    @Test(description = "TC5.23 - Alert Detail hien thi dung status badge")
    public void TC5_23_AlertDetailShowsCorrectStatusBadge() {
        openDetail("ALT-1001");
        String badge = getText(By.id("detailStatusBadge"));
        Assert.assertFalse(badge.isEmpty(), "TC5.23 FAIL: detailStatusBadge rong");
        Assert.assertTrue(
            badge.equals("Unresolved") || badge.equals("Resolved") || badge.equals("In Progress"),
            "TC5.23 FAIL: Status badge sai. Actual='" + badge + "'");
    }

    @Test(description = "TC5.24 - Alert Detail hien thi day du description va suggestion")
    public void TC5_24_AlertDetailShowsDescriptionAndSuggestion() {
        openDetail("ALT-1001");
        String desc       = getText(By.id("detailDescription"));
        String suggestion = getText(By.id("detailSuggestion"));
        Assert.assertFalse(desc.isEmpty(),       "TC5.24 FAIL: detailDescription rong");
        Assert.assertFalse(suggestion.isEmpty(), "TC5.24 FAIL: detailSuggestion rong");
    }

    @Test(description = "TC5.25 - Alert Detail hien thi lich su log dung")
    public void TC5_25_AlertDetailShowsLogs() {
        openDetail("ALT-1001");
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER,
            java.time.Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("maintenanceBtn"))).click();
        try { Thread.sleep(800); } catch (Exception ignored) {}
        List<WebElement> items = Constant.WEBDRIVER.findElements(By.cssSelector("#historyList > div"));
        Assert.assertTrue(items.size() > 0, "TC5.25 FAIL: historyList khong co log nao");
        Assert.assertFalse(items.get(0).getText().trim().isEmpty(), "TC5.25 FAIL: Log entry rong");
    }

    @Test(description = "TC5.26 - Tao maintenance request tu Alert Detail")
    public void TC5_26_CreateMaintenanceRequest() {
        openDetail("ALT-1001");
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER,
            java.time.Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("maintenanceBtn"))).click();
        try { Thread.sleep(800); } catch (Exception ignored) {}
        WebElement msg = Constant.WEBDRIVER.findElement(By.id("actionMessage"));
        Assert.assertFalse(msg.getAttribute("class").contains("hidden"),
            "TC5.26 FAIL: actionMessage van hidden");
        Assert.assertFalse(msg.getText().trim().isEmpty(), "TC5.26 FAIL: actionMessage rong");
    }

    @Test(description = "TC5.27 - Call Technician tu Alert Detail")
    public void TC5_27_CallTechnician() {
        openDetail("ALT-1001");
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER,
            java.time.Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("technicianBtn"))).click();
        try { Thread.sleep(800); } catch (Exception ignored) {}
        WebElement msg = Constant.WEBDRIVER.findElement(By.id("actionMessage"));
        Assert.assertFalse(msg.getAttribute("class").contains("hidden"),
            "TC5.27 FAIL: actionMessage van hidden");
        Assert.assertFalse(msg.getText().trim().isEmpty(), "TC5.27 FAIL: actionMessage rong");
    }
}
