package testcases;

import PageObjects.StationPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * XEM THÔNG TIN TRẠM SẠC: TC1.10 → TC1.15
 */
public class ViewStationTest extends BaseTest {

    private StationPage stationPage;

    @BeforeMethod(alwaysRun = true)
    public void openStationPage() {
        stationPage = homePage.openStation();
    }

    // =========================================================
    /**
     * TC1.10 - Xem chi tiết trạm sạc thành công
     * Bước 1: Truy cập trang Station Management
     * Bước 2: Chọn một trạm sạc trong danh sách
     * Expected: Hiển thị đầy đủ thông tin chi tiết
     */
    @Test(description = "TC1.10 - Xem chi tiet tram sac thanh cong")
    public void TC1_10_ViewStationDetailSuccess() {
        // Bước 2: Click trạm đầu tiên
        stationPage.clickFirstStation();

        // Verify: Panel chi tiết hiển thị
        Assert.assertTrue(
            stationPage.isDetailPanelDisplayed(),
            "TC1.10 FAIL: Panel chi tiet khong hien thi sau khi click vao tram"
        );
    }

    // =========================================================
    /**
     * TC1.11 - Hiển thị đầy đủ và chính xác thông tin trạm sạc
     * Bước 1: Chọn một trạm sạc cần xem
     * Expected: Hiển thị đủ: Tên, Mã, Địa chỉ, Tọa độ, Trạng thái, Cổng sạc, Thời gian
     */
    @Test(description = "TC1.11 - Hien thi day du thong tin tram sac")
    public void TC1_11_VerifyFullStationInfo() {
        // Bước 1: Click trạm đầu tiên
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.11 SETUP: Panel chi tiet khong mo duoc");

        // Verify: Section Coordinates hiển thị
        Assert.assertTrue(
            stationPage.isCoordinatesSectionDisplayed(),
            "TC1.11 FAIL: Khong hien thi section 'Coordinates'"
        );

        // Verify: Section Poles & Pole Status hiển thị
        Assert.assertTrue(
            stationPage.isConnectorsSectionDisplayed(),
            "TC1.11 FAIL: Khong hien thi section 'Poles & Pole Status'"
        );
    }

    // =========================================================
    /**
     * TC1.12 - Quay lại màn hình danh sách
     * Bước 1: Mở chi tiết trạm
     * Bước 2: Nhấn biểu tượng thoát (←)
     * Expected: Quay lại danh sách, panel đóng
     */
    @Test(description = "TC1.12 - Quay lai man hinh danh sach")
    public void TC1_12_CloseDetailReturnToList() {
        // Bước 1: Mở chi tiết
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.12 SETUP: Panel chi tiet khong mo duoc");

        // Bước 2: Nhấn thoát
        stationPage.closeDetailPanel();

        // Verify: Panel đóng
        Assert.assertFalse(
            stationPage.isDetailPanelDisplayed(),
            "TC1.12 FAIL: Panel chi tiet van hien thi sau khi nhan thoat"
        );
    }

    // =========================================================
    /**
     * TC1.13 - Hiển thị đúng thông tin với trạm có nhiều cổng sạc
     * Bước 1: Chọn trạm có nhiều cổng (ST001 có 4 poles theo DB)
     * Expected: Hiển thị đầy đủ tất cả cổng và tình trạng
     */
    @Test(description = "TC1.13 - Hien thi tram co nhieu cong sac")
    public void TC1_13_ViewStationWithMultipleConnectors() {
        // Bước 1: Click ST001 (có PL001-PL004 theo DB)
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.13 SETUP: Panel chi tiet khong mo duoc");

        // Verify: Section Poles & Pole Status hiển thị
        Assert.assertTrue(
            stationPage.isConnectorsSectionDisplayed(),
            "TC1.13 FAIL: Khong hien thi section 'Poles & Pole Status'"
        );
    }

    // =========================================================
    /**
     * TC1.14 - Hiển thị đúng thông tin với trạm có 1 cổng sạc
     * Bước 1: Chọn trạm chỉ có 1 cổng
     * Expected: Hiển thị đúng số lượng và trạng thái
     */
    @Test(description = "TC1.14 - Hien thi tram co 1 cong sac")
    public void TC1_14_ViewStationWithSingleConnector() {
        // Bước 1: Click trạm đầu tiên
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.14 SETUP: Panel chi tiet khong mo duoc");

        // Verify: Section Poles & Pole Status hiển thị
        Assert.assertTrue(
            stationPage.isConnectorsSectionDisplayed(),
            "TC1.14 FAIL: Khong hien thi section 'Poles & Pole Status'"
        );
    }

    // =========================================================
    /**
     * TC1.15 - Điều hướng sang chức năng xóa (không còn dùng — đã chuyển sang UpdateStationTest)
     * Giữ lại để không break testng.xml, nhưng đổi thành TC1.14b
     * Bước 1: Mở chi tiết trạm
     * Bước 2: Nhấn "Delete"
     * Expected: Chuyển sang flow xóa (popup xác nhận hiển thị)
     */
    @Test(description = "TC1.14b - Dieu huong sang chuc nang xoa tu detail")
    public void TC1_15_NavigateToDeleteFromDetail() {
        // Bước 1: Mở chi tiết
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.15 SETUP: Panel chi tiet khong mo duoc");

        // Verify nút Delete visible
        Assert.assertTrue(
            stationPage.isDeleteButtonDisplayed(),
            "TC1.15 FAIL: Nut 'Delete' khong hien thi trong panel chi tiet"
        );

        // Bước 2: Nhấn Delete
        stationPage.clickDelete();

        // Verify: Popup xác nhận hiển thị
        Assert.assertTrue(
            stationPage.isDeleteConfirmPopupDisplayed(),
            "TC1.15 FAIL: Popup xac nhan xoa khong hien thi"
        );
    }
}
