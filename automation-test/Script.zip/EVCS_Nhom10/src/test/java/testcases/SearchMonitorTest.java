package testcases;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

// @Listeners không cần khai báo lại — đã có trên BaseTest
public class SearchMonitorTest extends BaseTest {

    private final String MONITOR_URL = "https://evsc-production.up.railway.app/monitor.html";

    private WebDriverWait getWait() {
        return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(40));
    }

    private String getBodyText() {
        return Constant.WEBDRIVER.findElement(By.tagName("body")).getText();
    }

    private void slow() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void openMonitor() {
        WebDriverWait wait = getWait();

        // Step 1: mở monitor
        Constant.WEBDRIVER.get(MONITOR_URL);
        slow();
        // Step 2: chờ load UI + data
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Monitor")
                    || body.contains("Station")
                    || body.contains("No data");
        });
        slow();
    }

    // ============================================
    // TC3.06 - Search station
    // ============================================
    @Test
    public void TC3_06_SearchStation() {
        WebDriverWait wait = getWait();

        openMonitor();
        slow();

        // Step 1: tìm ô search
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[contains(@placeholder,'Search')]")
        ));
        slow();

        // ================================
        // CASE 1: Partial match (có data)
        // ================================
        String keyword = "1";
        searchBox.clear();
        searchBox.sendKeys(keyword);
        searchBox.sendKeys(Keys.ENTER);
        slow();

        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains(keyword) || body.contains("No data");
        });
        slow();

        String actual1 = getBodyText();

        Assert.assertTrue(
                actual1.contains(keyword) || actual1.contains("No data"),
                "Partial match fail. Actual: " + actual1
        );

        // ================================
        // CASE 2: Không có data
        // ================================
        String keywordNotExist = "zzzz_9999";
        searchBox.clear();
        searchBox.sendKeys(keywordNotExist);
        searchBox.sendKeys(Keys.ENTER);
        slow();

        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("No data");
        });
        slow();

        String actual2 = getBodyText();

        Assert.assertTrue(
                actual2.contains("No data") || actual2.contains("No data available"),
                "No data case fail. Actual: " + actual2
        );
    }

    // ============================================
    // TC3.07 - Filter Region
    // ============================================
    @Test
    public void TC3_07_FilterRegion() {
        WebDriverWait wait = getWait();

        openMonitor();
        slow();

        // Step 1: tìm dropdown region
        WebElement region = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//select)[1]")
        ));
        slow();

        // Step 2: verify có option "All"
        List<WebElement> options = region.findElements(By.tagName("option"));
        boolean hasAll = false;

        for (WebElement opt : options) {
            if (opt.getText().equalsIgnoreCase("All")) {
                hasAll = true;
                break;
            }
        }

        Assert.assertTrue(hasAll, "Không có option 'All' trong Region");

        // Step 3: chọn 1 region cụ thể (khác All)
        String selectedRegion = "";

        if (options.size() > 1) {
            selectedRegion = options.get(1).getText();
            options.get(1).click();
            slow();
        }

        // Step 4: verify dropdown hiển thị đúng giá trị đã chọn
        String selectedValue = region.getAttribute("value");
        Assert.assertTrue(
                selectedValue != null && !selectedValue.isEmpty(),
                "Dropdown không hiển thị giá trị đã chọn"
        );

        // Step 5: chờ UI update
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Station") || body.contains("No data");
        });
        slow();

        String actual = getBodyText();

        // Step 6: verify kết quả filter
        Assert.assertTrue(
                actual.contains(selectedRegion) || actual.contains("No data"),
                "Filter region không đúng. Actual: " + actual
        );

        // ================================
        // Step 7: chọn lại "All"
        // ================================
        for (WebElement opt : options) {
            if (opt.getText().equalsIgnoreCase("All")) {
                opt.click();
                slow();
                break;
            }
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
        slow();

        String actualAll = getBodyText();

        // Step 8: verify hiển thị lại toàn bộ danh sách
        Assert.assertTrue(
                actualAll.contains("Station") || actualAll.contains("Monitor"),
                "Chọn All không hiển thị lại toàn bộ dữ liệu. Actual: " + actualAll
        );
    }

    // ============================================
    // TC3.08 - Filter Status
    // ============================================
    @Test
    public void TC3_08_FilterStatus() {
        WebDriverWait wait = getWait();

        openMonitor();
        slow();

        // Step 1: tìm dropdown status (select thứ 2)
        WebElement status = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//select)[2]")
        ));
        slow();

        List<WebElement> options = status.findElements(By.tagName("option"));

        // ================================
        // CASE 1: All
        // ================================
        for (WebElement opt : options) {
            if (opt.getText().equalsIgnoreCase("All")) {
                opt.click();
                slow();
                break;
            }
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
        slow();

        String actualAll = getBodyText();

        Assert.assertTrue(
                actualAll.contains("Station") || actualAll.contains("Monitor"),
                "All không hiển thị full data. Actual: " + actualAll
        );

        // ================================
        // CASE 2: Online
        // ================================
        for (WebElement opt : options) {
            if (opt.getText().equalsIgnoreCase("Online")) {
                opt.click();
                slow();
                break;
            }
        }

        // Verify dropdown giữ giá trị
        Assert.assertTrue(
                status.getAttribute("value") != null,
                "Dropdown không giữ giá trị Online"
        );

        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Online") || body.contains("No data");
        });
        slow();

        String actualOnline = getBodyText();

        Assert.assertTrue(
                actualOnline.contains("Online") || actualOnline.contains("No data"),
                "Filter Online sai. Actual: " + actualOnline
        );

        // ================================
        // CASE 3: Offline
        // ================================
        for (WebElement opt : options) {
            if (opt.getText().equalsIgnoreCase("Offline")) {
                opt.click();
                slow();
                break;
            }
        }

        Assert.assertTrue(
                status.getAttribute("value") != null,
                "Dropdown không giữ giá trị Offline"
        );

        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Offline") || body.contains("No data");
        });
        slow();

        String actualOffline = getBodyText();

        Assert.assertTrue(
                actualOffline.contains("Offline") || actualOffline.contains("No data"),
                "Filter Offline sai. Actual: " + actualOffline
        );
    }

    // ============================================
    // TC3.09 - Combine filter
    // ============================================
    @Test
    public void TC3_09_CombineFilter() {
        WebDriverWait wait = getWait();

        openMonitor();
        slow();

        WebElement search = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[contains(@placeholder,'Search')]")
        ));
        slow();

        String keyword = "8";
        String selectedRegion = "District 9";
        String selectedStatus = "Online";

        // ================================
        // CASE 1: ĐÚNG 3 điều kiện
        // ================================
        search.clear();
        search.sendKeys(keyword);
        search.sendKeys(Keys.ENTER);
        slow();

        // chọn region
        boolean foundRegion = false;
        for (WebElement opt : Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[1]"))
                .findElements(By.tagName("option"))) {

            if (opt.getText().equalsIgnoreCase(selectedRegion)) {
                opt.click();
                foundRegion = true;
                slow();
                break;
            }
        }

        // fallback nếu không có District 9
        if (!foundRegion) {
            List<WebElement> regions = Constant.WEBDRIVER
                    .findElement(By.xpath("(//select)[1]"))
                    .findElements(By.tagName("option"));

            if (regions.size() > 1) {
                selectedRegion = regions.get(1).getText();
                regions.get(1).click();
                slow();
            }
        }

        // chọn status Online
        for (WebElement opt : Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[2]"))
                .findElements(By.tagName("option"))) {

            if (opt.getText().equalsIgnoreCase(selectedStatus)) {
                opt.click();
                slow();
                break;
            }
        }

        wait.until(d -> getBodyText().contains("Station") || getBodyText().contains("No data"));
        slow();

        Assert.assertTrue(
                getBodyText().contains(keyword)
                        || getBodyText().contains("No data"),
                "CASE 1 sai logic AND"
        );

        // ================================
        // CASE 2: Sai keyword (không tồn tại)
        // ================================
        search.clear();
        search.sendKeys("999999_not_exist");
        search.sendKeys(Keys.ENTER);
        slow();

        wait.until(d -> getBodyText().contains("No data"));
        slow();

        Assert.assertTrue(getBodyText().contains("No data"),
                "CASE 2 phải No data khi sai keyword");

        // ================================
        // CASE 3: Sai region (keyword đúng nhưng region không match)
        // ================================
        search.clear();
        search.sendKeys(keyword);
        search.sendKeys(Keys.ENTER);
        slow();

        // chọn region KHÁC
        List<WebElement> regions = Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[1]"))
                .findElements(By.tagName("option"));

        if (regions.size() > 2) {
            regions.get(regions.size() - 1).click(); // region khác
            slow();
        }

        wait.until(d -> getBodyText().contains("No data"));
        slow();

        Assert.assertTrue(getBodyText().contains("No data"),
                "CASE 3 phải No data khi sai region");

        // ================================
        // CASE 4: Sai status
        // ================================
        for (WebElement opt : Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[2]"))
                .findElements(By.tagName("option"))) {

            if (opt.getText().equalsIgnoreCase("Offline")) {
                opt.click();
                slow();
                break;
            }
        }

        wait.until(d ->
                getBodyText().contains("Offline") ||
                        getBodyText().contains("No data")
        );
        slow();

        Assert.assertTrue(
                getBodyText().contains("Offline") || getBodyText().contains("No data"),
                "CASE 4 sai status"
        );

        // ================================
        // CASE 5: Sai nhiều điều kiện (keyword + region + status)
        // ================================
        search.clear();
        search.sendKeys("xxxxx_not_exist");
        search.sendKeys(Keys.ENTER);
        slow();

        // chọn region cuối + status offline
        List<WebElement> regions2 = Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[1]"))
                .findElements(By.tagName("option"));

        if (regions2.size() > 2) {
            regions2.get(regions2.size() - 1).click();
            slow();
        }

        for (WebElement opt : Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[2]"))
                .findElements(By.tagName("option"))) {

            if (opt.getText().equalsIgnoreCase("Offline")) {
                opt.click();
                slow();
                break;
            }
        }

        wait.until(d -> getBodyText().contains("No data"));
        slow();

        Assert.assertTrue(getBodyText().contains("No data"),
                "CASE 5 phải No data khi sai nhiều điều kiện");
    }

    // ============================================
    // TC3.10 - Reset filter
    // ============================================
    @Test
    public void TC3_10_ResetFilter() {
        WebDriverWait wait = getWait();

        openMonitor();
        slow();

        // ================================
        // Step 1: Nhập Search
        // ================================
        WebElement search = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[contains(@placeholder,'Search')]")
        ));
        search.clear();
        search.sendKeys("8");
        slow();

        // ================================
        // Step 2: Chọn Region khác All
        // ================================
        WebElement region = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//select)[1]")
        ));

        List<WebElement> regionOptions = region.findElements(By.tagName("option"));

        if (regionOptions.size() > 1) {
            regionOptions.get(1).click(); // chọn khác All
            slow();
        }

        // ================================
        // Step 3: Chọn Status khác All
        // ================================
        WebElement status = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//select)[2]")
        ));

        for (WebElement opt : status.findElements(By.tagName("option"))) {
            if (!opt.getText().equalsIgnoreCase("All")) {
                opt.click(); // chọn khác All
                slow();
                break;
            }
        }

        // ================================
        // Step 4: Nhấn Reset
        // ================================
        WebElement reset = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Reset')]")
        ));
        slow();

        reset.click();
        slow();

        // ================================
        // VERIFY 1: Search rỗng
        // ================================
        search = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//input[contains(@placeholder,'Search')]")
        ));

        Assert.assertTrue(
                search.getAttribute("value").isEmpty(),
                "Search chưa được clear"
        );

        // ================================
        // VERIFY 2: Region = All
        // ================================
        String regionValue = Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[1]"))
                .getAttribute("value");

        Assert.assertTrue(
                regionValue.equalsIgnoreCase("All") || regionValue.equals(""),
                "Region không về All"
        );

        // ================================
        // VERIFY 3: Status = All
        // ================================
        String statusValue = Constant.WEBDRIVER
                .findElement(By.xpath("(//select)[2]"))
                .getAttribute("value");

        Assert.assertTrue(
                statusValue.equalsIgnoreCase("All") || statusValue.equals(""),
                "Status không về All"
        );

        // ================================
        // VERIFY 4: Data hiển thị lại
        // ================================
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Station")
                    || body.contains("Online")
                    || body.contains("Offline");
        });
        slow();

        String actual = getBodyText();

        Assert.assertTrue(
                actual.contains("Station")
                        || actual.contains("Online")
                        || actual.contains("Offline"),
                "Danh sách không reset lại"
        );
    }
}
