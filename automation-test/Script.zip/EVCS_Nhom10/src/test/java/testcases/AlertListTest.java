package testcases;

import Constant.Constant;
import PageObjects.AlertPage;
import PageObjects.AlertPage.AlertRow;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

/**
 * TC5.08 - TC5.18: Alert List (alerts.html) — hiển thị, search, filter
 */
public class AlertListTest extends BaseTest {

    private AlertPage alertPage;

    @BeforeMethod(alwaysRun = true)
    public void setup() {
        alertPage = new AlertPage();
        // Bước 1: Mở station.html để set đúng domain cho localStorage
        alertPage.navigateToStationPage();
        // Bước 2: Seed dữ liệu alert vào localStorage
        seedAlerts();
    }

    private void seedAlerts() {
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "localStorage.removeItem('evc-alerts-data-v1');" +
            "var d=[" +
            "{id:'ALT-1001',type:'Connection Lost',stationName:'Station 1',occurredAt:'2026-04-08T08:15:00',severity:'critical',status:'open',description:'Station connection lost',suggestion:'Check network',logs:[]}," +
            "{id:'ALT-1002',type:'Charger Overheating',stationName:'Station 3',occurredAt:'2026-04-08T09:40:00',severity:'critical',status:'open',description:'Temperature exceeded',suggestion:'Check cooling',logs:[]}," +
            "{id:'ALT-1003',type:'Charging Port Error',stationName:'Station 2',occurredAt:'2026-04-08T10:05:00',severity:'medium',status:'open',description:'Port error E-24',suggestion:'Reset port',logs:[]}," +
            "{id:'ALT-1004',type:'Abnormal Current',stationName:'Station 4',occurredAt:'2026-04-07T15:20:00',severity:'medium',status:'resolved',description:'Current fluctuation',suggestion:'Monitor supply',logs:[]}," +
            "{id:'ALT-1005',type:'Scheduled Maintenance Reminder',stationName:'Station 5',occurredAt:'2026-04-06T11:30:00',severity:'low',status:'resolved',description:'Maintenance due',suggestion:'Schedule inspection',logs:[]}" +
            "];" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));"
        );
    }

    /** Helper: in debug info của tất cả rows hiện tại */
    private void debugRows(String context) {
        List<AlertRow> rows = alertPage.getAlertRows();
        System.out.println("[DEBUG " + context + "] Số rows: " + rows.size());
        for (int i = 0; i < rows.size(); i++) {
            System.out.println("  Row[" + i + "]: " + rows.get(i));
        }
    }

    // =========================================================
    /**
     * TC5.08 - Alert mới hiển thị trên Alert List
     *
     * Bước 1: Thêm alert mới vào localStorage
     * Bước 2: Mở alerts.html
     * Bước 3: Chờ bảng load xong
     * Bước 4: Assert có ít nhất 1 row
     */
    @Test(description = "TC5.08 - Alert moi hien thi tren Alert List")
    public void TC5_08_NewAlertAppearsInAlertList() {
        // Bước 1: Thêm alert mới
        alertPage.addAlertToLocalStorage("ALT-UI-" + System.currentTimeMillis(),
            "Connection Lost", "Station 1", "critical", "open");

        // Bước 2: Mở alerts.html
        alertPage.navigateToAlertsPage();

        // Bước 3: Chờ bảng load
        alertPage.waitAlertListLoaded();

        // Bước 4: Assert
        Assert.assertTrue(alertPage.isAlertsPageLoaded(),
            "TC5.08 FAIL: Khong load duoc alerts.html. URL=" + Constant.WEBDRIVER.getCurrentUrl());

        List<AlertRow> rows = alertPage.getAlertRows();
        debugRows("TC5.08");

        Assert.assertTrue(rows.size() > 0,
            "TC5.08 FAIL: Bang Active Alerts khong co row nao. PageText: " + alertPage.getPageText());
    }

    // =========================================================
    /**
     * TC5.09 - Alert List hiển thị đúng Error Type "Connection Lost"
     *
     * Bước 1: Mở alerts.html
     * Bước 2: Chờ bảng load
     * Bước 3: Parse rows, tìm row có errorType = "Connection Lost"
     */
    @Test(description = "TC5.09 - Alert List hien thi dung Error Type")
    public void TC5_09_AlertListShowsCorrectErrorType() {
        // Bước 1 & 2: Mở và chờ
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        // Bước 3: Parse và tìm
        List<AlertRow> rows = alertPage.getAlertRows();
        debugRows("TC5.09");

        if (rows.isEmpty()) {
            throw new SkipException("TC5.09 SKIP: Khong co row nao trong bang alert");
        }

        // Tìm bất kỳ row nào có errorType = "Connection Lost"
        boolean found = rows.stream()
            .anyMatch(r -> r.errorType.equalsIgnoreCase("Connection Lost"));

        System.out.println("TC5.09 Tìm 'Connection Lost' trong " + rows.size() + " rows: " + found);

        Assert.assertTrue(found,
            "TC5.09 FAIL: Khong tim thay row co errorType='Connection Lost'. "
            + "Rows: " + alertPage.getAllRowTexts());
    }

    // =========================================================
    /**
     * TC5.10 - Alert List hiển thị đúng Station
     *
     * Bước 1: Mở alerts.html
     * Bước 2: Parse rows, tìm row có station chứa "Station"
     */
    @Test(description = "TC5.10 - Alert List hien thi dung Station")
    public void TC5_10_AlertListShowsCorrectStation() {
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rows = alertPage.getAlertRows();
        debugRows("TC5.10");

        if (rows.isEmpty()) {
            throw new SkipException("TC5.10 SKIP: Khong co row nao");
        }

        boolean found = rows.stream()
            .anyMatch(r -> r.station.contains("Station") || r.fullText.contains("Station"));

        Assert.assertTrue(found,
            "TC5.10 FAIL: Khong tim thay Station trong rows. Rows: " + alertPage.getAllRowTexts());
    }

    // =========================================================
    /**
     * TC5.11 - Alert List hiển thị đúng Timestamp
     *
     * Bước 1: Mở alerts.html
     * Bước 2: Parse rows, kiểm tra timestamp format dd/MM/yyyy, HH:mm
     */
    @Test(description = "TC5.11 - Alert List hien thi dung Timestamp")
    public void TC5_11_AlertListShowsCorrectTimestamp() {
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rows = alertPage.getAlertRows();
        debugRows("TC5.11");

        if (rows.isEmpty()) {
            throw new SkipException("TC5.11 SKIP: Khong co row nao");
        }

        // Tìm bất kỳ row nào có timestamp hợp lệ
        boolean hasValidTimestamp = rows.stream().anyMatch(r -> {
            String ts = r.timestamp;
            System.out.println("TC5.11 timestamp='" + ts + "'");
            return ts.matches("\\d{2}/\\d{2}/\\d{4},?\\s*\\d{1,2}:\\d{2}");
        });

        // Fallback: kiểm tra trong fullText
        if (!hasValidTimestamp) {
            hasValidTimestamp = rows.stream().anyMatch(r ->
                r.fullText.matches("(?s).*\\d{2}/\\d{2}/\\d{4}.*\\d{1,2}:\\d{2}.*"));
        }

        Assert.assertTrue(hasValidTimestamp,
            "TC5.11 FAIL: Khong co timestamp hop le (dd/MM/yyyy, HH:mm). "
            + "Rows: " + alertPage.getAllRowTexts());
    }

    // =========================================================
    /**
     * TC5.12 - Alert List hiển thị đúng Severity
     */
    @Test(description = "TC5.12 - Alert List hien thi dung Severity")
    public void TC5_12_AlertListShowsCorrectSeverity() {
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rows = alertPage.getAlertRows();
        if (rows.isEmpty()) throw new SkipException("TC5.12 SKIP: Khong co row nao");

        boolean found = rows.stream().anyMatch(r ->
            r.severity.equals("Critical") || r.severity.equals("High")
            || r.severity.equals("Medium") || r.severity.equals("Low")
            || r.fullText.contains("Critical") || r.fullText.contains("Medium") || r.fullText.contains("Low"));

        Assert.assertTrue(found,
            "TC5.12 FAIL: Severity badge khong hien thi. Rows: " + alertPage.getAllRowTexts());
    }

    // =========================================================
    /**
     * TC5.13 - Alert List hiển thị đúng Status
     */
    @Test(description = "TC5.13 - Alert List hien thi dung Status")
    public void TC5_13_AlertListShowsCorrectStatus() {
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rows = alertPage.getAlertRows();
        if (rows.isEmpty()) throw new SkipException("TC5.13 SKIP: Khong co row nao");

        boolean found = rows.stream().anyMatch(r ->
            r.status.equals("Unresolved") || r.status.equals("Resolved")
            || r.fullText.contains("Unresolved") || r.fullText.contains("Resolved"));

        Assert.assertTrue(found,
            "TC5.13 FAIL: Status khong hien thi. Rows: " + alertPage.getAllRowTexts());
    }

    // =========================================================
    /**
     * TC5.14 - Tìm kiếm lỗi theo từ khóa (partial match)
     *
     * Bước 1: Mở alerts.html, chờ load
     * Bước 2: Reset filter
     * Bước 3: Nhập keyword "Station 1", trigger search
     * Bước 4: Chờ list refresh
     * Bước 5: Assert tất cả visible rows chứa "Station 1"
     *         Nếu filter không hoạt động → log BUG UI
     */
    @Test(description = "TC5.14 - Tim kiem loi theo tu khoa partial match")
    public void TC5_14_SearchAlertByKeyword() {
        // Bước 1: Mở và chờ
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rowsBefore = alertPage.getAlertRows();
        if (rowsBefore.isEmpty()) throw new SkipException("TC5.14 SKIP: Khong co row nao");

        // Bước 2: Reset filter
        alertPage.resetFilters();

        // Bước 3: Nhập keyword
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("searchInput")));
        searchInput.clear();
        searchInput.sendKeys("Station 1");

        // Trigger input event để web nhận
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el = document.getElementById('searchInput');" +
            "if (el) el.dispatchEvent(new Event('input', {bubbles:true}));"
        );

        // Bước 4: Chờ list refresh
        alertPage.waitFilterApplied();

        // Bước 5: Kiểm tra kết quả
        List<AlertRow> rowsAfter = alertPage.getAlertRows();
        debugRows("TC5.14 after search 'Station 1'");

        Assert.assertTrue(rowsAfter.size() > 0,
            "TC5.14 FAIL: Khong co ket qua nao khi search 'Station 1'");

        // Kiểm tra tất cả rows phải chứa "Station 1"
        boolean allMatch = rowsAfter.stream()
            .allMatch(r -> r.fullText.contains("Station 1"));

        if (!allMatch) {
            // Log BUG UI rõ ràng
            StringBuilder bugMsg = new StringBuilder(
                "TC5.14 BUG UI: Search 'Station 1' không filter đúng. Visible rows:\n");
            for (AlertRow r : rowsAfter) {
                bugMsg.append("  - ").append(r.errorType).append(" | ").append(r.station).append("\n");
            }
            Assert.fail(bugMsg.toString());
        }

        System.out.println("TC5.14 PASS: " + rowsAfter.size() + " rows đều chứa 'Station 1'");
    }

    // =========================================================
    /**
     * TC5.15 - Filter theo Severity hoạt động đúng
     *
     * Bước 1: Mở alerts.html, chờ load
     * Bước 2: Reset filter
     * Bước 3: Chọn severity = "medium"
     * Bước 4: Chờ list refresh
     * Bước 5: Assert tất cả visible rows có severity = "Medium"
     */
    @Test(description = "TC5.15 - Filter theo Severity hoat dong dung")
    public void TC5_15_FilterBySeverity() {
        // Bước 1: Mở và chờ
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rowsBefore = alertPage.getAlertRows();
        if (rowsBefore.isEmpty()) throw new SkipException("TC5.15 SKIP: Khong co row nao");

        // Bước 2: Reset filter
        alertPage.resetFilters();

        // Bước 3: Chọn severity = medium
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        new Select(wait.until(ExpectedConditions.presenceOfElementLocated(By.id("severityFilter"))))
            .selectByValue("medium");

        // Trigger change event
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el = document.getElementById('severityFilter');" +
            "if (el) el.dispatchEvent(new Event('change', {bubbles:true}));"
        );

        // Bước 4: Chờ list refresh
        alertPage.waitFilterApplied();

        // Bước 5: Kiểm tra
        List<AlertRow> rowsAfter = alertPage.getAlertRows();
        debugRows("TC5.15 after filter severity=medium");

        Assert.assertTrue(rowsAfter.size() > 0,
            "TC5.15 FAIL: Khong co alert nao sau khi filter severity=medium");

        boolean allMedium = rowsAfter.stream()
            .allMatch(r -> r.severity.equalsIgnoreCase("Medium")
                || r.fullText.contains("Medium"));

        if (!allMedium) {
            StringBuilder bugMsg = new StringBuilder(
                "TC5.15 BUG UI: Filter severity=medium không hoạt động. Visible rows:\n");
            for (AlertRow r : rowsAfter) {
                bugMsg.append("  - ").append(r.errorType).append(" | severity=").append(r.severity).append("\n");
            }
            Assert.fail(bugMsg.toString());
        }

        System.out.println("TC5.15 PASS: " + rowsAfter.size() + " rows đều là Medium");
    }

    // =========================================================
    /**
     * TC5.16 - Filter theo Status hoạt động đúng
     *
     * Bước 1: Mở alerts.html, chờ load
     * Bước 2: Reset filter
     * Bước 3: Chọn status = "open" (Unresolved)
     * Bước 4: Chờ list refresh
     * Bước 5: Assert tất cả visible rows có status = "Unresolved"
     */
    @Test(description = "TC5.16 - Filter theo Status hoat dong dung")
    public void TC5_16_FilterByStatus() {
        // Bước 1: Mở và chờ
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> rowsBefore = alertPage.getAlertRows();
        if (rowsBefore.isEmpty()) throw new SkipException("TC5.16 SKIP: Khong co row nao");

        // Bước 2: Reset filter
        alertPage.resetFilters();

        // Bước 3: Chọn status = open
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        new Select(wait.until(ExpectedConditions.presenceOfElementLocated(By.id("statusFilter"))))
            .selectByValue("open");

        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el = document.getElementById('statusFilter');" +
            "if (el) el.dispatchEvent(new Event('change', {bubbles:true}));"
        );

        // Bước 4: Chờ list refresh
        alertPage.waitFilterApplied();

        // Bước 5: Kiểm tra
        List<AlertRow> rowsAfter = alertPage.getAlertRows();
        debugRows("TC5.16 after filter status=open");

        Assert.assertTrue(rowsAfter.size() > 0,
            "TC5.16 FAIL: Khong co alert nao sau khi filter status=open");

        boolean allUnresolved = rowsAfter.stream()
            .allMatch(r -> r.status.equalsIgnoreCase("Unresolved")
                || r.fullText.contains("Unresolved"));

        if (!allUnresolved) {
            StringBuilder bugMsg = new StringBuilder(
                "TC5.16 BUG UI: Filter status=open không hoạt động. Visible rows:\n");
            for (AlertRow r : rowsAfter) {
                bugMsg.append("  - ").append(r.errorType).append(" | status=").append(r.status).append("\n");
            }
            Assert.fail(bugMsg.toString());
        }

        System.out.println("TC5.16 PASS: " + rowsAfter.size() + " rows đều là Unresolved");
    }

    // =========================================================
    /**
     * TC5.17 - Kết hợp Search + Filter hoạt động đúng
     *
     * Bước 1: Mở alerts.html, chờ load
     * Bước 2: Reset filter
     * Bước 3: Xác định keyword từ data thật (tìm row có severity=critical + status=open)
     * Bước 4: Apply search + severity=critical + status=open
     * Bước 5: Chờ list refresh
     * Bước 6: Assert tất cả visible rows thỏa điều kiện
     */
    @Test(description = "TC5.17 - Ket hop Search + Filter hoat dong dung")
    public void TC5_17_CombineSearchAndFilter() {
        // Bước 1: Mở và chờ
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        List<AlertRow> allRows = alertPage.getAlertRows();
        if (allRows.isEmpty()) throw new SkipException("TC5.17 SKIP: Khong co row nao");

        // Bước 3: Tìm keyword từ data thật — lấy station của row đầu tiên có critical + open
        String keyword = allRows.stream()
            .filter(r -> (r.severity.equalsIgnoreCase("Critical") || r.fullText.contains("Critical"))
                && (r.status.equalsIgnoreCase("Unresolved") || r.fullText.contains("Unresolved")))
            .map(r -> r.station.isEmpty() ? "Station" : r.station)
            .findFirst()
            .orElse("Station");

        System.out.println("TC5.17 Keyword từ data thật: '" + keyword + "'");

        // Bước 2: Reset filter
        alertPage.resetFilters();

        // Bước 4: Apply search
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("searchInput")));
        searchInput.clear();
        searchInput.sendKeys(keyword);
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el=document.getElementById('searchInput');" +
            "if(el) el.dispatchEvent(new Event('input',{bubbles:true}));"
        );

        // Apply severity = critical
        new Select(Constant.WEBDRIVER.findElement(By.id("severityFilter"))).selectByValue("critical");
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el=document.getElementById('severityFilter');" +
            "if(el) el.dispatchEvent(new Event('change',{bubbles:true}));"
        );

        // Apply status = open
        new Select(Constant.WEBDRIVER.findElement(By.id("statusFilter"))).selectByValue("open");
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el=document.getElementById('statusFilter');" +
            "if(el) el.dispatchEvent(new Event('change',{bubbles:true}));"
        );

        // Bước 5: Chờ list refresh
        alertPage.waitFilterApplied();

        // Bước 6: Kiểm tra
        List<AlertRow> rowsAfter = alertPage.getAlertRows();
        debugRows("TC5.17 after combine filter");

        Assert.assertTrue(rowsAfter.size() > 0,
            "TC5.17 FAIL: Khong co row nao sau combine filter. keyword='" + keyword + "'");

        boolean allMatch = rowsAfter.stream().allMatch(r ->
            (r.fullText.contains(keyword) || keyword.equals("Station"))
            && (r.severity.equalsIgnoreCase("Critical") || r.fullText.contains("Critical"))
            && (r.status.equalsIgnoreCase("Unresolved") || r.fullText.contains("Unresolved"))
        );

        if (!allMatch) {
            StringBuilder bugMsg = new StringBuilder(
                "TC5.17 BUG UI: Combine filter không hoạt động đúng. Visible rows:\n");
            for (AlertRow r : rowsAfter) {
                bugMsg.append("  - ").append(r.errorType)
                    .append(" | station=").append(r.station)
                    .append(" | severity=").append(r.severity)
                    .append(" | status=").append(r.status).append("\n");
            }
            Assert.fail(bugMsg.toString());
        }

        System.out.println("TC5.17 PASS: " + rowsAfter.size() + " rows thỏa combine filter");
    }

    // =========================================================
    /**
     * TC5.18 - Click vào alert mở đúng Alert Detail
     */
    @Test(description = "TC5.18 - Click vao alert mo dung Alert Detail")
    public void TC5_18_ClickAlertOpensDetail() {
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        WebElement firstRow = wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("#alertsTableBody tr:first-child")));
        String alertId = firstRow.getAttribute("data-alert-id");
        System.out.println("TC5.18 Clicking alert id=" + alertId);

        firstRow.click();
        wait.until(d -> d.getCurrentUrl().contains("alert-detail.html"));

        String url = Constant.WEBDRIVER.getCurrentUrl();
        Assert.assertTrue(url.contains("alert-detail.html"),
            "TC5.18 FAIL: Khong redirect sang alert-detail.html. URL=" + url);
        Assert.assertTrue(url.contains(alertId),
            "TC5.18 FAIL: URL khong chua alertId. URL=" + url);
    }
}
