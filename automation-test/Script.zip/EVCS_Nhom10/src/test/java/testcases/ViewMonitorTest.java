package testcases;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.Listeners;
import listeners.TestListener;


import java.time.Duration;
import java.util.List;
@Listeners(TestListener.class)

public class ViewMonitorTest extends BaseTest {

    private final String MONITOR_URL = "https://evsc-production.up.railway.app/monitor.html";

    private WebDriverWait getWait() {
        return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(40));
    }

    private String getBodyText() {
        return Constant.WEBDRIVER.findElement(By.tagName("body")).getText();
    }

    private void waitForMonitorLoaded() {
        WebDriverWait wait = getWait();

        // Step 1: Đợi body xuất hiện
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

        // Step 2: Đợi đúng URL monitor
        wait.until(ExpectedConditions.urlContains("monitor.html"));

        // Step 3: Đợi text chính của màn Monitor xuất hiện
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Monitor")
                    || body.contains("Monitor Status")
                    || body.contains("Station:");
        });

        // Step 4: Đợi search/filter/button render xong
        wait.until(driver -> {
            List<WebElement> inputs = driver.findElements(By.xpath("//input"));
            List<WebElement> selects = driver.findElements(By.xpath("//select"));
            List<WebElement> buttons = driver.findElements(By.xpath("//button"));

            return inputs.size() > 0 || selects.size() > 0 || buttons.size() > 0;
        });

        // Step 5: Đợi dữ liệu động render xong
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();

            boolean hasKpiOrData =
                    body.contains("Online")
                            || body.contains("Offline")
                            || body.contains("Available")
                            || body.contains("Charging")
                            || body.contains("Connector")
                            || body.contains("Station")
                            || body.contains("Address")
                            || body.contains("No data");

            return hasKpiOrData;
        });

        // Step 6: Cho UI thêm chút thời gian ổn định
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void openMonitor() {
        // Step 1: Mở thẳng URL đúng màn Monitor
        Constant.WEBDRIVER.get(MONITOR_URL);

        // Step 2: Đợi web load xong
        waitForMonitorLoaded();
    }

    @Test
    public void TC3_01_OpenMonitor() {
        // Step 1: Mở màn hình Monitor
        openMonitor();

        // Step 2: Lấy actual data từ web
        String actualUrl = Constant.WEBDRIVER.getCurrentUrl();
        String actualMessage = getBodyText();

        // Step 3: Verify
        Assert.assertTrue(actualUrl.contains("monitor.html"), "URL không đúng Monitor. Actual: " + actualUrl);

        Assert.assertTrue(
                actualMessage.contains("Monitor")
                        || actualMessage.contains("Monitor Status"),
                "Không thấy tiêu đề Monitor. Actual: " + actualMessage
        );

        Assert.assertTrue(
                actualMessage.contains("Station")
                        || actualMessage.contains("Search")
                        || actualMessage.contains("Reset")
                        || actualMessage.contains("Region")
                        || actualMessage.contains("Status"),
                "Không thấy filter/search/reset. Actual: " + actualMessage
        );
    }

    @Test
    public void TC3_02_KPI() {
        // Step 1: Mở màn hình Monitor
        openMonitor();

        // Step 2: Lấy actual data từ web
        String actualMessage = getBodyText();

        // Step 3: Verify KPI theo keyword thực tế
        boolean hasKpi =
                actualMessage.contains("Online")
                        || actualMessage.contains("Offline")
                        || actualMessage.contains("Idle")
                        || actualMessage.contains("Charging")
                        || actualMessage.contains("Alert")
                        || actualMessage.contains("Connector");

        Assert.assertTrue(hasKpi, "Không thấy KPI tổng quan. Actual: " + actualMessage);
    }

    @Test
    public void TC3_03_StationCards() {
        // Step 1: Mở màn hình Monitor
        openMonitor();

        // Step 2: Lấy actual data từ web
        String actualMessage = getBodyText();

        // Step 3: Verify danh sách trạm hoặc No data
        boolean hasStationData =
                actualMessage.contains("Station")
                        || actualMessage.contains("Address")
                        || actualMessage.contains("Region")
                        || actualMessage.contains("Connector")
                        || actualMessage.contains("No data");

        Assert.assertTrue(
                hasStationData,
                "Không thấy danh sách trạm hoặc No data. Actual: " + actualMessage
        );
    }

    @Test
    public void TC3_04_Status() {
        // Step 1: Mở màn hình Monitor
        openMonitor();

        // Step 2: Lấy actual data từ web
        String actualMessage = getBodyText();

        // Step 3: Verify status
        boolean hasValidStatus =
                actualMessage.contains("Online")
                        || actualMessage.contains("Offline")
                        || actualMessage.contains("Available")
                        || actualMessage.contains("In Use")
                        || actualMessage.contains("Fault")
                        || actualMessage.contains("Charging")
                        || actualMessage.contains("Idle")
                        || actualMessage.contains("No data");

        Assert.assertTrue(hasValidStatus, "Không thấy status hợp lệ. Actual: " + actualMessage);
    }

    @Test
    public void TC3_05_NoData() {
        // Step 1: Mở màn hình Monitor
        openMonitor();

        WebDriverWait wait = getWait();

        // Step 2: Tìm ô search
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[contains(@placeholder,'Search') or contains(@placeholder,'search') or @type='text']")
        ));

        // Step 3: Search keyword không tồn tại
        String keywordNotExist = "zzzz_no_station_99999";
        searchBox.clear();
        searchBox.sendKeys(keywordNotExist);
        searchBox.sendKeys(Keys.ENTER);

        // Step 4: Đợi kết quả filter cập nhật
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();

            return body.contains("No data")
                    || body.contains("No data available")
                    || body.contains("Không có dữ liệu");
        });

        // Step 5: Lấy actual message sau khi filter
        String actualMessage = getBodyText();

        // Step 6: Verify message
        Assert.assertTrue(
                actualMessage.contains("No data")
                        || actualMessage.contains("No data available")
                        || actualMessage.contains("Không có dữ liệu"),
                "Không thấy No data sau khi search. Actual: " + actualMessage
        );
    }
}