package testcases;

import PageObjects.StationPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * KÍCH HOẠT TRẠM SẠC: TC1.33 → TC1.36
 *
 * Toggle UI: mỗi row có button "ON" (deactivate) và "OFF" (activate).
 * - Click "OFF" trong row Inactive → mở popup → Confirm → trạm thành Active.
 *
 * Prerequisite: Cần có trạm đang ở trạng thái Inactive.
 *   DB: ST004, ST005, ST006 đang Inactive.
 */
public class ActivateStationTest extends BaseTest {

    private StationPage stationPage;

    @BeforeMethod(alwaysRun = true)
    public void openStationPage() {
        stationPage = homePage.openStation();
        stationPage.waitStationTableLoaded();
    }

    // =========================================================
    /**
     * TC1.33 - Kích hoạt trạm sạc thành công
     * Bước 1: Truy cập trang Station Management
     * Bước 2: Tìm trạm đang Inactive, nhấn "OFF"
     * Bước 3: Nhấn Confirm
     * Expected: Trạng thái trạm thành "Active"
     */
    @Test(description = "TC1.33 - Kich hoat tram sac thanh cong")
    public void TC1_33_ActivateStationSuccessfully() {
        // Tìm trạm Inactive đầu tiên
        String stationName = stationPage.findFirstStationByStatus("Inactive");
        Assert.assertNotNull(stationName,
            "TC1.33 SKIP: Không có trạm Inactive nào trong bảng");

        System.out.println("TC1.33 Activate trạm: " + stationName);

        // Bước 2: Click OFF (activate) trong row của trạm Inactive đầu tiên
        stationPage.clickActiveFirstInactiveStation();

        // Verify: Popup xác nhận hiển thị
        Assert.assertTrue(stationPage.isDeactivatePopupDisplayed(),
            "TC1.33 SETUP: Popup xác nhận không hiển thị sau khi click OFF");

        // Bước 3: Nhấn Confirm
        stationPage.confirmDeactivate();

        // Chờ status đổi
        stationPage.waitStatusChanged(stationName, "Active");

        // Verify: Trạng thái đổi thành Active
        String status = stationPage.getStationStatusByName(stationName);
        System.out.println("TC1.33 Status sau activate: '" + status + "'");
        Assert.assertTrue(
            status.toLowerCase().contains("active"),
            "TC1.33 FAIL: Trạng thái không đổi thành Active. Actual: '" + status + "'"
        );
    }

    // =========================================================
    /**
     * TC1.34 - Hiển thị popup xác nhận khi kích hoạt
     * Bước 1: Tìm trạm Inactive
     * Bước 2: Nhấn "OFF"
     * Expected: Popup xác nhận kích hoạt hiển thị
     */
    @Test(description = "TC1.34 - Hien thi popup xac nhan khi kich hoat")
    public void TC1_34_ShowConfirmPopupOnActivate() {
        // Tìm trạm Inactive đầu tiên
        String stationName = stationPage.findFirstStationByStatus("Inactive");
        Assert.assertNotNull(stationName,
            "TC1.34 SKIP: Không có trạm Inactive nào trong bảng");

        System.out.println("TC1.34 Kiểm tra popup cho trạm: " + stationName);

        // Bước 2: Click OFF (activate)
        stationPage.clickActiveFirstInactiveStation();

        // Verify: Popup hiển thị
        Assert.assertTrue(
            stationPage.isDeactivatePopupDisplayed(),
            "TC1.34 FAIL: Popup xác nhận không hiển thị sau khi nhấn OFF"
        );

        // Cleanup: hủy để không ảnh hưởng data
        stationPage.cancelDeactivate();
    }

    // =========================================================
    /**
     * TC1.35 - Hủy thao tác kích hoạt
     * Bước 1: Tìm trạm Inactive
     * Bước 2: Nhấn "OFF"
     * Bước 3: Nhấn Cancel
     * Expected: Trạng thái không thay đổi (vẫn Inactive)
     */
    @Test(description = "TC1.35 - Huy thao tac kich hoat")
    public void TC1_35_CancelActivate() {
        // Tìm trạm Inactive đầu tiên
        String stationName = stationPage.findFirstStationByStatus("Inactive");
        Assert.assertNotNull(stationName,
            "TC1.35 SKIP: Không có trạm Inactive nào trong bảng");

        // Ghi nhận trạng thái trước
        String statusBefore = stationPage.getStationStatusByName(stationName);
        System.out.println("TC1.35 Trạm: " + stationName + ", status trước: " + statusBefore);

        // Bước 2: Click OFF (activate)
        stationPage.clickActiveFirstInactiveStation();
        Assert.assertTrue(stationPage.isDeactivatePopupDisplayed(),
            "TC1.35 SETUP: Popup xác nhận không hiển thị");

        // Bước 3: Nhấn Cancel
        stationPage.cancelDeactivate();

        // Verify: Popup đóng
        Assert.assertFalse(
            stationPage.isDeactivatePopupDisplayed(),
            "TC1.35 FAIL: Popup vẫn hiển thị sau khi nhấn Cancel"
        );

        // Verify: Trạng thái không đổi
        String statusAfter = stationPage.getStationStatusByName(stationName);
        System.out.println("TC1.35 Status sau cancel: '" + statusAfter + "'");
        Assert.assertEquals(
            statusAfter, statusBefore,
            "TC1.35 FAIL: Trạng thái thay đổi sau khi hủy "
            + "(trước='" + statusBefore + "', sau='" + statusAfter + "')"
        );
    }

    // =========================================================
    /**
     * TC1.36 - Trạng thái trạm thay đổi đúng sau khi kích hoạt
     * Bước 1: Kích hoạt trạm Inactive thành công
     * Bước 2: Xem lại trạng thái trong bảng
     * Expected: Trạng thái hiển thị là "Active"
     */
    @Test(description = "TC1.36 - Trang thai tram thay doi dung sau khi kich hoat")
    public void TC1_36_VerifyStatusAfterActivate() {
        // Tìm trạm Inactive đầu tiên
        String stationName = stationPage.findFirstStationByStatus("Inactive");
        Assert.assertNotNull(stationName,
            "TC1.36 SKIP: Không có trạm Inactive nào trong bảng");

        System.out.println("TC1.36 Activate trạm: " + stationName);

        // Bước 1: Kích hoạt trạm
        stationPage.clickActiveFirstInactiveStation();
        Assert.assertTrue(stationPage.isDeactivatePopupDisplayed(),
            "TC1.36 SETUP: Popup xác nhận không hiển thị");
        stationPage.confirmDeactivate();

        // Chờ status đổi
        stationPage.waitStatusChanged(stationName, "Active");

        // Bước 2: Xem lại trạng thái trong bảng
        String status = stationPage.getStationStatusByName(stationName);
        System.out.println("TC1.36 Status sau activate: '" + status + "'");

        // Verify: Trạng thái là Active
        Assert.assertTrue(
            status.toLowerCase().contains("active"),
            "TC1.36 FAIL: Trạng thái không hiển thị 'Active' sau khi kích hoạt. "
            + "Actual: '" + status + "'"
        );
    }
}
