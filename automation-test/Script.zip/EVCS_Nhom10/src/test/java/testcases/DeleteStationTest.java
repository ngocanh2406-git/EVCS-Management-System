package testcases;

import Constant.Constant;
import PageObjects.StationPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

/**
 * XÓA TRẠM SẠC: TC1.21 → TC1.25
 *
 * Sheet:
 *   TC1.21 - Xóa trạm sạc thành công (popup hiển thị)
 *   TC1.22 - Hiển thị popup xác nhận khi xóa
 *   TC1.23 - Hủy xóa tại popup
 *   TC1.24 - Không cho xóa khi trạm có giao dịch đang hoạt động
 *   TC1.25 - Trạm bị xóa không còn hiển thị trong danh sách
 */
public class DeleteStationTest extends BaseTest {

    private StationPage stationPage;

    private static final String STATION_WITH_ONGOING_SESSION = Constant.STATION_WITH_ONGOING_SESSION;

    @BeforeMethod(alwaysRun = true)
    public void openStationPage() {
        stationPage = homePage.openStation();
        stationPage.waitStationTableLoaded();
        System.out.println("[BeforeMethod] Trang Station đã load xong.");
    }

    // =========================================================
    /**
     * TC1.21 - Xóa trạm sạc thành công
     *
     * Bước 1: Click station đầu tiên trong bảng
     * Bước 2: Nhấn Delete
     * Bước 3: Popup xác nhận hiển thị = thao tác xóa được kích hoạt thành công
     *
     * Expected: Popup xác nhận xóa hiển thị
     */
    @Test(description = "TC1.21 - Xoa tram sac thanh cong")
    public void TC1_21_DeleteStationSuccessfully() {
        // Bước 1: Click station đầu tiên
        System.out.println("TC1.21 Bước 1 - Click station đầu tiên...");
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.21 SETUP: Detail panel không mở được");

        // Bước 2: Nhấn Delete
        System.out.println("TC1.21 Bước 2 - Click Delete...");
        stationPage.clickDelete();

        // Bước 3: Popup hiển thị = xóa được kích hoạt thành công
        boolean popupShown = stationPage.isDeleteConfirmPopupDisplayed();
        System.out.println("TC1.21 Popup xác nhận hiển thị: " + popupShown);
        Assert.assertTrue(popupShown,
            "TC1.21 FAIL: Popup xác nhận xóa không hiển thị");
        System.out.println("TC1.21 PASS - Popup xác nhận xóa đã hiển thị.");
    }

    // =========================================================
    /**
     * TC1.22 - Hiển thị popup xác nhận khi xóa
     *
     * Bước 1: Click station đầu tiên trong bảng
     * Bước 2: Nhấn Delete
     * Bước 3: Kiểm tra popup xác nhận hiển thị
     */
    @Test(description = "TC1.22 - Hien thi popup xac nhan khi xoa")
    public void TC1_22_ShowConfirmPopupOnDelete() {
        // Bước 1: Click station đầu tiên
        System.out.println("TC1.22 Bước 1 - Click station đầu tiên...");
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.22 SETUP: Detail panel không mở được");

        // Bước 2: Nhấn Delete
        System.out.println("TC1.22 Bước 2 - Click Delete...");
        stationPage.clickDelete();

        // Bước 3: Kiểm tra popup
        boolean popupShown = stationPage.isDeleteConfirmPopupDisplayed();
        System.out.println("TC1.22 Popup hiển thị: " + popupShown);
        Assert.assertTrue(popupShown, "TC1.22 FAIL: Popup xác nhận xóa không hiển thị");
        System.out.println("TC1.22 PASS.");
    }

    // =========================================================
    /**
     * TC1.23 - Hủy xóa tại popup
     *
     * Bước 1: Lấy số station trước (sau waitStationTableLoaded)
     * Bước 2: Click station → Delete → popup hiện
     * Bước 3: Click Cancel
     * Bước 4: Reload, lấy số station sau
     * Bước 5: Assert số trước == sau
     */
    @Test(description = "TC1.23 - Huy xoa tai popup")
    public void TC1_23_CancelDeleteAtPopup() {
        // Bước 1: Lấy số station TRƯỚC — sau waitStationTableLoaded
        System.out.println("TC1.23 Bước 1 - Lấy số station trước...");
        int countBefore = stationPage.getStationCount();
        System.out.println("TC1.23 Số station trước: " + countBefore);

        if (countBefore == 0) {
            throw new SkipException("TC1.23 SKIP: Bảng không có station nào.");
        }

        // Bước 2: Click station → Delete
        System.out.println("TC1.23 Bước 2 - Click station đầu tiên...");
        stationPage.clickFirstStation();
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.23 SETUP: Detail panel không mở được");

        stationPage.clickDelete();
        Assert.assertTrue(stationPage.isDeleteConfirmPopupDisplayed(),
            "TC1.23 SETUP: Popup xác nhận không hiển thị");

        // Bước 3: Click Cancel
        System.out.println("TC1.23 Bước 3 - Click Cancel...");
        stationPage.cancelDelete();

        Assert.assertFalse(stationPage.isDeleteConfirmPopupDisplayed(),
            "TC1.23 FAIL: Popup vẫn hiển thị sau Cancel");

        // Bước 4: Reload và lấy số station sau
        System.out.println("TC1.23 Bước 4 - Reload page...");
        stationPage.navigateToStationPage();
        stationPage.waitStationTableLoaded();

        int countAfter = stationPage.getStationCount();
        System.out.println("TC1.23 Số station sau: " + countAfter);

        // Bước 5: Assert
        Assert.assertEquals(countAfter, countBefore,
            "TC1.23 FAIL: Số station thay đổi sau khi hủy xóa "
            + "(trước=" + countBefore + ", sau=" + countAfter + ")");
        System.out.println("TC1.23 PASS - Số station không đổi: " + countBefore);
    }

    // =========================================================
    /**
     * TC1.24 - Không cho xóa khi trạm có giao dịch đang hoạt động
     *
     * Bước 1: Click row ST001 theo data-id (không dùng tên)
     * Bước 2: Delete → Confirm
     * Bước 3: Reload, kiểm tra ST001 vẫn còn
     *         Log warning nếu web không hiển thị error message
     */
    @Test(description = "TC1.24 - Khong cho xoa tram dang co giao dich")
    public void TC1_24_CannotDeleteStationWithActiveSession() {
        String targetId = STATION_WITH_ONGOING_SESSION; // ST001

        // Bước 1: Kiểm tra ST001 có trong bảng
        System.out.println("TC1.24 Bước 1 - Kiểm tra " + targetId + " trong bảng...");
        if (!stationPage.isStationPresentById(targetId)) {
            throw new SkipException("TC1.24 SKIP: Không tìm thấy " + targetId + " trong bảng.");
        }

        // Click row ST001 theo data-id
        stationPage.clickStationRowById(targetId);
        Assert.assertTrue(stationPage.isDetailPanelDisplayed(),
            "TC1.24 SETUP: Detail panel không mở cho " + targetId);

        // Bước 2: Delete → Confirm
        System.out.println("TC1.24 Bước 2 - Delete → Confirm...");
        stationPage.clickDelete();
        Assert.assertTrue(stationPage.isDeleteConfirmPopupDisplayed(),
            "TC1.24 SETUP: Popup không hiển thị");

        stationPage.confirmDelete();

        // Lấy error message nếu có
        String errorMsg = stationPage.getToastOrAlertMessageOptional();
        System.out.println("TC1.24 Error message: '" + errorMsg + "'");

        // Bước 3: Reload và kiểm tra ST001 vẫn còn
        System.out.println("TC1.24 Bước 3 - Reload và kiểm tra...");
        stationPage.navigateToStationPage();
        stationPage.waitStationTableLoaded();

        boolean stillPresent = stationPage.isStationPresentById(targetId);
        System.out.println("TC1.24 " + targetId + " còn trong bảng: " + stillPresent);

        Assert.assertTrue(stillPresent,
            "TC1.24 FAIL: " + targetId + " bị xóa dù đang có ongoing session!");

        if (errorMsg.isEmpty()) {
            System.out.println("TC1.24 WARNING BUG UI: Web không hiển thị error message khi "
                + "chặn xóa station có ongoing session. "
                + "Expected: 'Cannot delete a station with an ongoing charging session.'");
        }
        System.out.println("TC1.24 PASS - " + targetId + " vẫn còn sau khi cố xóa.");
    }

    // =========================================================
    /**
     * TC1.25 - Trạm bị xóa không còn hiển thị trong danh sách
     *
     * Bước 1: Tạo station mới
     * Bước 2: Deactivate station
     * Bước 3: Xóa station
     * Bước 4: Reload và kiểm tra không còn trong danh sách
     */
    @Test(description = "TC1.25 - Tram bi xoa khong con hien thi trong danh sach")
    public void TC1_25_DeletedStationNotInList() {
        // Bước 1: Tạo station mới
        System.out.println("TC1.25 Bước 1 - Tạo station mới...");
        String stationName = "TempDel_" + System.currentTimeMillis();
        String stationId   = createAndDeactivateStation(stationName);

        Assert.assertNotNull(stationId,
            "TC1.25 SETUP FAIL: Không tạo/deactivate được station test");
        System.out.println("TC1.25 Station ID: " + stationId);

        // Bước 2: Xóa station
        System.out.println("TC1.25 Bước 2 - Xóa station...");
        stationPage.clickStationRowById(stationId);
        stationPage.clickDelete();
        stationPage.confirmDelete();
        acceptAlertAndGetText();

        // Bước 3: Reload và kiểm tra
        System.out.println("TC1.25 Bước 3 - Reload và kiểm tra...");
        stationPage.navigateToStationPage();
        stationPage.waitStationTableLoaded();

        Assert.assertFalse(
            stationPage.isStationPresentById(stationId),
            "TC1.25 FAIL: Station '" + stationName + "' vẫn hiển thị sau khi xóa và reload"
        );
        System.out.println("TC1.25 PASS - Station đã biến mất.");
    }

    // =========================================================
    //  HELPERS
    // =========================================================

    /**
     * Accept native alert nếu có và trả về text.
     * Không throw exception nếu không có alert.
     */
    private String acceptAlertAndGetText() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.alertIsPresent());
            org.openqa.selenium.Alert alert = Constant.WEBDRIVER.switchTo().alert();
            String text = alert.getText();
            alert.accept();
            return text != null ? text : "";
        } catch (Exception ignored) {
            return "";
        }
    }

    /**
     * Xác định Station ID thực tế của station vừa tạo.
     * Tìm theo tên (unique) — xử lý pagination bằng waitForStationInList.
     * Sau khi tìm thấy row trong DOM, đọc data-id từ row đó.
     */
    private String resolveStationId(String stationName, String generatedId) {
        // Bước 1: Chờ station xuất hiện trong list (xử lý pagination)
        System.out.println("[resolveStationId] Chờ station '" + stationName + "' xuất hiện...");
        boolean found = stationPage.waitForStationInList(stationName);
        System.out.println("[resolveStationId] waitForStationInList: " + found);

        if (!found) {
            // Log tất cả rows hiện tại để debug
            String allRows = (String) ((org.openqa.selenium.JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript(
                    "var rows = document.querySelectorAll('table tbody tr');" +
                    "var result = 'Total rows: ' + rows.length + '\\n';" +
                    "for (var i = 0; i < rows.length; i++) {" +
                    "  result += 'Row[' + i + '] data-id=' + (rows[i].getAttribute('data-id')||'?')" +
                    "    + ' text=' + rows[i].innerText.replace(/\\n/g,' ').substring(0,80) + '\\n';" +
                    "}" +
                    "return result;"
                );
            System.out.println("[resolveStationId] DOM rows:\n" + allRows);
            // Fallback: dùng generatedId nếu có
            return generatedId != null ? generatedId : "";
        }

        // Bước 2: Tìm row chứa tên station trong DOM hiện tại, đọc data-id
        try {
            WebElement row = Constant.WEBDRIVER.findElement(
                By.xpath("//table//tbody//tr[.//td[normalize-space()='" + stationName + "']]")
            );
            String dataId = row.getAttribute("data-id");
            if (dataId != null && !dataId.isEmpty()) {
                System.out.println("[resolveStationId] Tìm thấy data-id='" + dataId + "' cho '" + stationName + "'");
                return dataId;
            }
        } catch (Exception e) {
            System.out.println("[resolveStationId] Không đọc được data-id từ row: " + e.getMessage());
        }

        // Fallback: dùng generatedId
        System.out.println("[resolveStationId] Fallback generatedId='" + generatedId + "'");
        return generatedId != null ? generatedId : "";
    }

    /**
     * Tạo station mới và deactivate nó (web chỉ cho xóa Inactive).
     * Trả về Station ID thực tế, hoặc null nếu thất bại.
     *
     * Bước 1: Mở form Create, điền thông tin, Save
     * Bước 2: Chờ station xuất hiện trong list (tìm theo tên, xử lý pagination)
     * Bước 3: Đọc Station ID thực tế từ row
     * Bước 4: Navigate đến trang chứa row đó (nếu cần)
     * Bước 5: Deactivate station (web chỉ cho xóa Inactive)
     */
    private String createAndDeactivateStation(String stationName) {
        System.out.println("[createAndDeactivateStation] Tạo: " + stationName);

        // Bước 1: Mở form Create
        stationPage.openCreateStationForm();
        if (!stationPage.isCreateFormDisplayed()) {
            System.out.println("[createAndDeactivateStation] Form không mở được");
            return null;
        }

        // Điền thông tin
        stationPage.fillStationName(stationName);
        stationPage.fillLatitude("10.762622");
        stationPage.fillLongitude("106.660172");
        stationPage.fillAddress("456 Le Van Luong, Q7, HCMC");

        // Log ID auto-gen (chỉ để tham khảo, không dùng làm nguồn chính)
        String generatedId = stationPage.getGeneratedStationId();
        System.out.println("[createAndDeactivateStation] ID auto-gen (tham khảo): " + generatedId);

        // Click Save và accept alert nếu có
        stationPage.clickSave();
        String saveAlert = acceptAlertAndGetText();
        System.out.println("[createAndDeactivateStation] Save alert: '" + saveAlert + "'");

        if (saveAlert.toLowerCase().contains("error") || saveAlert.toLowerCase().contains("fail")) {
            System.out.println("[createAndDeactivateStation] SETUP FAIL: Save trả về lỗi: " + saveAlert);
            return null;
        }

        // Bước 2: Reload và chờ station xuất hiện theo tên (xử lý pagination)
        stationPage.navigateToStationPage();
        stationPage.waitStationTableLoaded();

        // Bước 3: Xác định Station ID thực tế từ row (tìm theo tên)
        String stationId = resolveStationId(stationName, generatedId);
        System.out.println("[createAndDeactivateStation] Station ID thực tế: " + stationId);

        if (stationId.isEmpty()) {
            System.out.println("[createAndDeactivateStation] SETUP FAIL: "
                + "Station created alert was success but row not found after reload. "
                + "stationName='" + stationName + "'");
            return null;
        }

        // Bước 4: Đảm bảo row visible trong DOM hiện tại
        // waitForStationInList đã navigate đến đúng trang, row phải có trong DOM
        boolean rowVisible = stationPage.isStationPresentById(stationId);
        System.out.println("[createAndDeactivateStation] Row " + stationId + " visible: " + rowVisible);

        if (!rowVisible) {
            // Thử reload lại — đôi khi pagination cần thêm thời gian
            System.out.println("[createAndDeactivateStation] Reload lần 2 để tìm row...");
            stationPage.navigateToStationPage();
            stationPage.waitStationTableLoaded();
            // Tìm lại theo tên để navigate đến đúng trang
            stationPage.waitForStationInList(stationName);
            rowVisible = stationPage.isStationPresentById(stationId);
            System.out.println("[createAndDeactivateStation] Row visible sau reload 2: " + rowVisible);
        }

        if (!rowVisible) {
            System.out.println("[createAndDeactivateStation] SETUP FAIL: "
                + "Row " + stationId + " không tìm thấy trong DOM sau 2 lần reload");
            return null;
        }

        // Bước 5: Deactivate station (web chỉ cho xóa Inactive)
        System.out.println("[createAndDeactivateStation] Deactivate station " + stationId + "...");
        boolean deactivated = stationPage.tryDeactivateStationById(stationId);

        if (!deactivated) {
            System.out.println("[createAndDeactivateStation] Không deactivate được " + stationId);
            return null;
        }

        String status = stationPage.getStationStatusById(stationId);
        System.out.println("[createAndDeactivateStation] Status sau deactivate: " + status);

        if (!status.equalsIgnoreCase("Inactive")) {
            System.out.println("[createAndDeactivateStation] Status không đổi thành Inactive: " + status);
            return null;
        }

        return stationId;
    }
}
