package testcases;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * LICH SU SU DUNG TRAM SAC - TC4.01 den TC4.09
 *
 * @Listeners khong can khai bao lai — da co tren BaseTest
 */
public class HistoryTest extends BaseTest {

    private static final String HISTORY_URL = Constant.HISTORY_URL;

    // ===================================================================
    //  HELPERS
    // ===================================================================

    private WebDriverWait getWait() {
        return new WebDriverWait(Constant.WEBDRIVER, java.time.Duration.ofSeconds(40));
    }

    private String getBodyText() {
        return Constant.WEBDRIVER.findElement(By.tagName("body")).getText();
    }

    private void slow() {
        try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void openHistory() {
        WebDriverWait wait = getWait();
        Constant.WEBDRIVER.get(HISTORY_URL);
        slow();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("History") || body.contains("Session") || body.contains("Export");
        });
        slow();
    }

    /**
     * Chon ngay tren custom calendar cua History page.
     * triggerBtnId: "historyDateFromTrigger" hoac "historyDateToTrigger"
     * dateValue: "yyyy-MM-dd" (phai co trong calendar hien tai)
     */
    private void pickDate(String triggerBtnId, String dateValue) {
        WebDriverWait wait = getWait();

        // 1. Click trigger de mo calendar
        WebElement trigger = wait.until(ExpectedConditions.elementToBeClickable(
            By.id(triggerBtnId)
        ));
        trigger.click();
        slow();

        // 2. Cho calendar mo (popover visible)
        wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.id("historyDatePopover")
        ));

        // 3. Dieu huong den thang/nam chua ngay can chon
        for (int attempt = 0; attempt < 24; attempt++) {
            By dayBtn = By.cssSelector("button[data-history-day='" + dateValue + "']");
            List<WebElement> days = Constant.WEBDRIVER.findElements(dayBtn);
            if (!days.isEmpty() && days.get(0).isDisplayed()) {
                days.get(0).click();
                slow();
                break;
            }
            List<WebElement> allDays = Constant.WEBDRIVER.findElements(
                By.cssSelector("#historyDateGrid button[data-history-day]")
            );
            if (!allDays.isEmpty()) {
                String firstDay = allDays.get(0).getAttribute("data-history-day");
                if (dateValue.compareTo(firstDay) < 0) {
                    Constant.WEBDRIVER.findElement(By.id("historyDatePrevMonth")).click();
                } else {
                    Constant.WEBDRIVER.findElement(By.id("historyDateNextMonth")).click();
                }
                try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
        }

        // 4. Nhan Done de xac nhan
        try {
            WebElement done = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("historyDateDone")
            ));
            done.click();
            slow();
        } catch (Exception ignored) { }
    }

    // ===================================================================
    //  TC4.01 - Truy cap man hinh History
    // ===================================================================

    /**
     * TC4.01 - Nguoi dung co the truy cap man hinh lich su su dung tram sac
     *
     * Steps: 1. Truy cap trang History
     * Expected: Hien thi man hinh "Station Usage History" gom:
     *   - Nut "Export File"
     *   - Bo loc: From Date, To Date, Station, Connector, Status, Chart View
     *   - Nut "Reset"
     *   - Bieu do Usage Trend
     *   - Khu vuc Summary
     *   - Bang Charging Sessions
     */
    @Test(description = "TC4.01 - Truy cap man hinh lich su su dung tram sac")
    public void TC4_01_OpenHistory() {
        openHistory();
        String body = getBodyText();

        Assert.assertTrue(
            body.contains("Station Usage History") || body.contains("History"),
            "TC4.01 FAIL: Khong thay tieu de 'Station Usage History'. Body: " + body
        );

        boolean hasExport = !Constant.WEBDRIVER.findElements(
            By.xpath("//button[contains(text(),'Export') or contains(@class,'export')]")
        ).isEmpty() || body.contains("Export");
        Assert.assertTrue(hasExport,
            "TC4.01 FAIL: Khong thay nut 'Export File'. Body: " + body);

        boolean hasDateFilter = body.contains("From Date") || body.contains("To Date")
            || body.contains("From") || body.contains("Select date");
        Assert.assertTrue(hasDateFilter,
            "TC4.01 FAIL: Khong thay bo loc From Date / To Date. Body: " + body);

        Assert.assertTrue(body.contains("Station"),
            "TC4.01 FAIL: Khong thay bo loc Station. Body: " + body);

        boolean hasStatus = body.contains("Status") || body.contains("Session Status");
        Assert.assertTrue(hasStatus,
            "TC4.01 FAIL: Khong thay bo loc Status. Body: " + body);

        boolean hasChartView = body.contains("Chart View") || body.contains("By Day") || body.contains("By Week");
        Assert.assertTrue(hasChartView,
            "TC4.01 FAIL: Khong thay bo loc Chart View. Body: " + body);

        boolean hasReset = !Constant.WEBDRIVER.findElements(
            By.xpath("//button[contains(text(),'Reset') or contains(@class,'reset')]")
        ).isEmpty() || body.contains("Reset");
        Assert.assertTrue(hasReset,
            "TC4.01 FAIL: Khong thay nut Reset. Body: " + body);

        Assert.assertTrue(body.contains("Usage Trend"),
            "TC4.01 FAIL: Khong thay bieu do 'Usage Trend'. Body: " + body);

        boolean hasSummary = body.contains("Summary") || body.contains("Total Sessions");
        Assert.assertTrue(hasSummary,
            "TC4.01 FAIL: Khong thay khu vuc Summary. Body: " + body);

        boolean hasTable = body.contains("Charging Sessions") || body.contains("Session ID");
        Assert.assertTrue(hasTable,
            "TC4.01 FAIL: Khong thay bang 'Charging Sessions'. Body: " + body);
    }

    // ===================================================================
    //  TC4.02 - Loc lich su phien sac voi du lieu hop le
    // ===================================================================

    /**
     * TC4.02 - Nguoi dung co the loc lich su phien sac voi du lieu hop le
     */
    @Test(description = "TC4.02 - Loc lich su phien sac voi du lieu hop le")
    public void TC4_02_FilterWithValidData() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> {
            List<WebElement> selects = driver.findElements(By.tagName("select"));
            for (WebElement sel : selects) {
                if (sel.findElements(By.tagName("option")).size() > 2) return true;
            }
            return false;
        });
        slow();

        String fromDate = LocalDate.now().minusMonths(1)
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String toDate = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        pickDate("historyDateFromTrigger", fromDate);
        pickDate("historyDateToTrigger",   toDate);

        try {
            WebElement stationSel = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("historyStationFilter")));
            List<WebElement> opts = stationSel.findElements(By.tagName("option"));
            if (opts.size() > 1) { opts.get(1).click(); slow(); }
        } catch (Exception ignored) { }

        try {
            WebElement poleSel = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("historyConnectorFilter")));
            List<WebElement> opts = poleSel.findElements(By.tagName("option"));
            if (opts.size() > 1) { opts.get(1).click(); slow(); }
        } catch (Exception ignored) { }

        try {
            WebElement statusSel = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("historyStatusFilter")));
            List<WebElement> opts = statusSel.findElements(By.tagName("option"));
            if (opts.size() > 1) { opts.get(1).click(); slow(); }
        } catch (Exception ignored) { }

        try {
            WebElement chartSel = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("historyChartMode")));
            List<WebElement> opts = chartSel.findElements(By.tagName("option"));
            if (opts.size() > 1) { opts.get(1).click(); slow(); }
        } catch (Exception ignored) { }

        slow();
        String body = getBodyText();

        boolean hasResult = body.contains("Charging Sessions") || body.contains("Session")
            || body.contains("results") || body.contains("No results");
        Assert.assertTrue(hasResult,
            "TC4.02 FAIL: Bang Charging Sessions khong hien thi sau khi loc. Body: " + body);

        Assert.assertTrue(body.contains("Usage Trend"),
            "TC4.02 FAIL: Bieu do Usage Trend khong hien thi. Body: " + body);

        Assert.assertTrue(body.contains("Total Sessions") || body.contains("Total"),
            "TC4.02 FAIL: Summary khong hien thi 'Total Sessions'. Body: " + body);
        Assert.assertTrue(body.contains("Energy Delivered") || body.contains("Energy") || body.contains("kWh"),
            "TC4.02 FAIL: Summary khong hien thi 'Energy Delivered'. Body: " + body);
        Assert.assertTrue(body.contains("Average Duration") || body.contains("Duration"),
            "TC4.02 FAIL: Summary khong hien thi 'Average Duration'. Body: " + body);
    }

    // ===================================================================
    //  TC4.03 - Khong the loc khi khoang ngay khong hop le
    // ===================================================================

    /**
     * TC4.03 - Nguoi dung khong the loc khi khoang ngay khong hop le
     */
    @Test(description = "TC4.03 - Khong the loc khi khoang ngay khong hop le")
    public void TC4_03_InvalidDateRange() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> {
            List<WebElement> selects = driver.findElements(By.tagName("select"));
            for (WebElement sel : selects) {
                if (sel.findElements(By.tagName("option")).size() > 2) return true;
            }
            return false;
        });
        slow();

        String fromDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String toDate   = LocalDate.now().minusMonths(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        pickDate("historyDateFromTrigger", fromDate);
        pickDate("historyDateToTrigger",   toDate);
        slow();

        String body = getBodyText();

        Assert.assertTrue(
            body.contains("Invalid date range") || body.contains("Invalid"),
            "TC4.03 FAIL: Khong hien thi 'Invalid date range'. Body: " + body
        );
        Assert.assertTrue(
            body.contains("No chart data available"),
            "TC4.03 FAIL: Khong hien thi 'No chart data available'. Body: " + body
        );
        Assert.assertTrue(
            body.contains("No results found") || body.contains("0 results"),
            "TC4.03 FAIL: Khong hien thi 'No results found'. Body: " + body
        );
    }

    // ===================================================================
    //  TC4.04 - Chuyen doi che do bieu do
    // ===================================================================

    /**
     * TC4.04 - Nguoi dung co the chuyen doi che do bieu do
     */
    @Test(description = "TC4.04 - Chuyen doi che do bieu do")
    public void TC4_04_SwitchChartView() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> driver.findElement(By.tagName("body"))
            .getText().contains("Usage Trend"));
        slow();

        WebElement chartSel = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("historyChartMode")));

        for (WebElement opt : chartSel.findElements(By.tagName("option"))) {
            if (opt.getText().trim().equalsIgnoreCase("By Day")) {
                opt.click(); slow(); break;
            }
        }
        Assert.assertTrue(getBodyText().contains("Usage Trend"),
            "TC4.04 FAIL: Bieu do Usage Trend khong hien thi khi chon By Day.");

        chartSel = wait.until(ExpectedConditions.elementToBeClickable(By.id("historyChartMode")));
        for (WebElement opt : chartSel.findElements(By.tagName("option"))) {
            if (opt.getText().trim().equalsIgnoreCase("By Week")) {
                opt.click(); slow(); break;
            }
        }
        Assert.assertTrue(getBodyText().contains("Usage Trend"),
            "TC4.04 FAIL: Bieu do Usage Trend khong hien thi khi chon By Week.");
    }

    // ===================================================================
    //  TC4.05 - Xem so lieu tong hop (Summary)
    // ===================================================================

    /**
     * TC4.05 - Nguoi dung co the xem so lieu tong hop
     */
    @Test(description = "TC4.05 - Xem so lieu tong hop Summary")
    public void TC4_05_ViewSummary() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> driver.findElement(By.tagName("body"))
            .getText().contains("Summary"));
        slow();

        String fromDate = LocalDate.now().minusMonths(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String toDate   = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        pickDate("historyDateFromTrigger", fromDate);
        pickDate("historyDateToTrigger",   toDate);

        try {
            WebElement stationSel = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("historyStationFilter")));
            List<WebElement> opts = stationSel.findElements(By.tagName("option"));
            if (opts.size() > 1) { opts.get(1).click(); slow(); }
        } catch (Exception ignored) { }

        slow();

        WebElement totalSessions = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.id("historyMetricSessions")));
        Assert.assertFalse(totalSessions.getText().trim().isEmpty(),
            "TC4.05 FAIL: 'Total Sessions' khong co gia tri.");

        WebElement energy = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.id("historyMetricEnergy")));
        Assert.assertFalse(energy.getText().trim().isEmpty(),
            "TC4.05 FAIL: 'Energy Delivered' khong co gia tri.");

        WebElement duration = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.id("historyMetricDuration")));
        Assert.assertFalse(duration.getText().trim().isEmpty(),
            "TC4.05 FAIL: 'Average Duration' khong co gia tri.");
    }

    // ===================================================================
    //  TC4.06 - Xem danh sach phien sac
    // ===================================================================

    /**
     * TC4.06 - Nguoi dung co the xem danh sach phien sac
     */
    @Test(description = "TC4.06 - Xem danh sach phien sac")
    public void TC4_06_ViewSessionList() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> {
            String b = driver.findElement(By.tagName("body")).getText();
            return b.contains("Charging Sessions") || b.contains("Session ID");
        });
        slow();

        String body = getBodyText();

        Assert.assertTrue(
            body.contains("Charging Sessions"),
            "TC4.06 FAIL: Khong thay bang 'Charging Sessions'. Body: " + body
        );

        Assert.assertTrue(body.contains("Session ID") || body.contains("Session"),
            "TC4.06 FAIL: Khong thay cot 'Session ID'. Body: " + body);
        Assert.assertTrue(body.contains("Station"),
            "TC4.06 FAIL: Khong thay cot 'Station'. Body: " + body);
        Assert.assertTrue(body.contains("Pole") || body.contains("Connector"),
            "TC4.06 FAIL: Khong thay cot 'Pole/Connector'. Body: " + body);
        Assert.assertTrue(body.contains("Start"),
            "TC4.06 FAIL: Khong thay cot 'Start'. Body: " + body);
        Assert.assertTrue(body.contains("End"),
            "TC4.06 FAIL: Khong thay cot 'End'. Body: " + body);
        Assert.assertTrue(body.contains("kWh"),
            "TC4.06 FAIL: Khong thay cot 'kWh'. Body: " + body);
        Assert.assertTrue(body.contains("Duration"),
            "TC4.06 FAIL: Khong thay cot 'Duration'. Body: " + body);
        Assert.assertTrue(body.contains("Status"),
            "TC4.06 FAIL: Khong thay cot 'Status'. Body: " + body);
    }

    // ===================================================================
    //  TC4.07 - Xem chi tiet phien sac
    // ===================================================================

    /**
     * TC4.07 - Nguoi dung co the xem chi tiet phien sac
     */
    @Test(description = "TC4.07 - Xem chi tiet phien sac")
    public void TC4_07_ViewSessionDetail() {
        WebDriverWait wait = getWait();
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        openHistory();

        wait.until(driver -> {
            String b = driver.findElement(By.tagName("body")).getText();
            return b.contains("Completed") || b.contains("Failed")
                || b.contains("Cancelled") || b.contains("charging");
        });
        slow();

        Boolean clicked = (Boolean) js.executeScript(
            "var rows = document.querySelectorAll('table tbody tr');" +
            "for (var i = 0; i < rows.length; i++) {" +
            "  var btns = rows[i].querySelectorAll('button');" +
            "  for (var j = 0; j < btns.length; j++) {" +
            "    if (btns[j].textContent.trim() === 'View') {" +
            "      btns[j].click(); return true;" +
            "    }" +
            "  }" +
            "}" +
            "return false;"
        );

        if (!Boolean.TRUE.equals(clicked)) {
            WebElement viewBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//table//tbody//tr[1]//button[normalize-space(text())='View']")
            ));
            viewBtn.click();
        }
        slow();

        wait.until(driver -> {
            WebElement overlay = driver.findElement(By.id("historyDetailOverlay"));
            return "false".equals(overlay.getAttribute("aria-hidden"));
        });

        WebElement overlay = Constant.WEBDRIVER.findElement(By.id("historyDetailOverlay"));
        Assert.assertTrue(overlay.isDisplayed() || "false".equals(overlay.getAttribute("aria-hidden")),
            "TC4.07 FAIL: Popup 'Session Details' khong hien thi");

        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailSessionId")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Session ID' trong popup rong");
        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailStation")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Station' trong popup rong");
        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailConnector")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Pole' trong popup rong");
        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailStatus")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Status' trong popup rong");
        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailStart")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Start Time' trong popup rong");
        Assert.assertNotNull(
            Constant.WEBDRIVER.findElement(By.id("historyDetailEnd")),
            "TC4.07 FAIL: 'End Time' khong co trong popup");
        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailEnergy")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Energy' trong popup rong");
        Assert.assertFalse(
            Constant.WEBDRIVER.findElement(By.id("historyDetailDuration")).getText().trim().isEmpty(),
            "TC4.07 FAIL: 'Duration' trong popup rong");
    }

    // ===================================================================
    //  TC4.08 - Reset bo loc
    // ===================================================================

    /**
     * TC4.08 - Nguoi dung co the reset bo loc
     */
    @Test(description = "TC4.08 - Reset bo loc")
    public void TC4_08_ResetFilter() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> {
            List<WebElement> selects = driver.findElements(By.tagName("select"));
            for (WebElement sel : selects) {
                if (sel.findElements(By.tagName("option")).size() > 2) return true;
            }
            return false;
        });
        slow();

        String fromDate = LocalDate.now().minusMonths(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String toDate   = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        pickDate("historyDateFromTrigger", fromDate);
        pickDate("historyDateToTrigger",   toDate);

        WebElement stationSel = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("historyStationFilter")));
        List<WebElement> stationOpts = stationSel.findElements(By.tagName("option"));
        if (stationOpts.size() > 1) { stationOpts.get(1).click(); slow(); }

        WebElement statusSel = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("historyStatusFilter")));
        List<WebElement> statusOpts = statusSel.findElements(By.tagName("option"));
        if (statusOpts.size() > 1) { statusOpts.get(1).click(); slow(); }

        WebElement resetBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("historyResetFilters")));
        resetBtn.click();
        slow();
        slow();

        WebElement stationAfter = Constant.WEBDRIVER.findElement(By.id("historyStationFilter"));
        String stationVal = stationAfter.findElements(By.tagName("option")).get(0).getAttribute("value");
        String stationSelected = stationAfter.getAttribute("value");
        Assert.assertEquals(stationSelected, stationVal,
            "TC4.08 FAIL: Station chua ve mac dinh sau khi Reset. Value: " + stationSelected);

        WebElement statusAfter = Constant.WEBDRIVER.findElement(By.id("historyStatusFilter"));
        String statusVal = statusAfter.findElements(By.tagName("option")).get(0).getAttribute("value");
        String statusSelected = statusAfter.getAttribute("value");
        Assert.assertEquals(statusSelected, statusVal,
            "TC4.08 FAIL: Status chua ve mac dinh sau khi Reset. Value: " + statusSelected);

        WebElement fromTrigger = Constant.WEBDRIVER.findElement(By.id("historyDateFromTrigger"));
        WebElement toTrigger   = Constant.WEBDRIVER.findElement(By.id("historyDateToTrigger"));
        String fromText = fromTrigger.getText().trim();
        String toText   = toTrigger.getText().trim();
        Assert.assertTrue(
            fromText.contains("Select date") || fromText.isEmpty(),
            "TC4.08 FAIL: From Date chua ve 'Select date' sau khi Reset. Text: " + fromText);
        Assert.assertTrue(
            toText.contains("Select date") || toText.isEmpty(),
            "TC4.08 FAIL: To Date chua ve 'Select date' sau khi Reset. Text: " + toText);
    }

    // ===================================================================
    //  TC4.09 - Xuat du lieu lich su
    // ===================================================================

    /**
     * TC4.09 - Nguoi dung co the xuat du lieu lich su
     */
    @Test(description = "TC4.09 - Xuat du lieu lich su")
    public void TC4_09_ExportData() {
        WebDriverWait wait = getWait();
        openHistory();

        wait.until(driver -> driver.findElement(By.tagName("body"))
            .getText().contains("Charging Sessions"));
        slow();

        WebElement exportBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("historyExportTrigger")));
        exportBtn.click();
        slow();

        wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.id("historyExportOptions")));

        WebElement csvBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("button[data-export-type='csv']")));
        csvBtn.click();
        slow();
        slow();

        WebElement feedback = Constant.WEBDRIVER.findElement(By.id("historyExportFeedback"));
        String feedbackText = feedback.getText().trim();

        Assert.assertTrue(
            feedbackText.contains("Export completed successfully")
            || feedbackText.contains("successfully")
            || feedbackText.contains("Success")
            || feedbackText.contains("completed"),
            "TC4.09 FAIL: Khong hien thi thong bao 'Export completed successfully'. " +
            "Feedback: " + feedbackText
        );
    }
}
