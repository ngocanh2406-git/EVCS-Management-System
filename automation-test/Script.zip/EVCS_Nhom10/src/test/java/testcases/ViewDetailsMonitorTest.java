package testcases;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

/**
 * XEM CHI TIẾT TRẠM TRÊN MONITOR - TC3.11 đến TC3.14
 *
 * Luồng chính:
 *   - Mở Monitor → click card trạm (hoặc nút "View details")
 *   - Panel chi tiết trượt ra bên phải, đè lên màn hình Monitor
 *   - Panel có: tên trạm, Station Information, Connectors, Statistics
 *   - Đóng bằng nút "X" hoặc nút "Return"
 *
 * Extends BaseTest để dùng chung setUp/tearDown (ChromeDriver) và
 * TestListener (@Listeners đã khai báo trên BaseTest — không khai báo lại).
 */
public class ViewDetailsMonitorTest extends BaseTest {

    private static final String MONITOR_URL = "https://evsc-production.up.railway.app/monitor.html";

    // ===================================================================
    //  LOCATORS - detail panel
    // ===================================================================

    // Panel chi tiết (drawer bên phải)
    private static final By DETAIL_PANEL = By.xpath(
        "//*[contains(@class,'detail') or contains(@class,'drawer') or contains(@class,'side-panel')" +
        " or contains(@id,'detail') or contains(@id,'drawer')]" +
        "[not(contains(@style,'display: none')) and not(contains(@style,'display:none'))]"
    );

    // Tiêu đề panel (tên trạm)
    private static final By DETAIL_TITLE = By.xpath(
        "//*[contains(@class,'detail')]//*[contains(@class,'title') or contains(@class,'name') or self::h2 or self::h3 or self::h4]" +
        " | //*[contains(@class,'drawer')]//*[contains(@class,'title') or self::h2 or self::h3]"
    );

    // Nút X đóng panel
    private static final By BTN_CLOSE = By.xpath(
        "//*[contains(@class,'detail') or contains(@class,'drawer')]//" +
        "button[contains(@class,'close') or @aria-label='Close' or normalize-space()='×' or normalize-space()='X']" +
        " | //button[@aria-label='Close']" +
        " | //button[contains(@class,'btn-close')]"
    );

    // Nút Return
    private static final By BTN_RETURN = By.xpath(
        "//button[contains(text(),'Return') or contains(text(),'return') or contains(text(),'Back')]" +
        " | //a[contains(text(),'Return') or contains(text(),'Back')]"
    );

    // Station Information section
    private static final By SECTION_STATION_INFO = By.xpath(
        "//*[contains(text(),'Station Information') or contains(text(),'Station Info')]"
    );

    // Connectors section
    private static final By SECTION_CONNECTORS = By.xpath(
        "//*[contains(text(),'Connector') or contains(text(),'connector')]"
    );

    // Statistics section
    private static final By SECTION_STATISTICS = By.xpath(
        "//*[contains(text(),'Statistics') or contains(text(),'statistics')" +
        " or contains(text(),'Total sessions') or contains(text(),'Uptime')" +
        " or contains(text(),'Delivered energy') or contains(text(),'Energy')]"
    );

    // ===================================================================
    //  SETUP
    // ===================================================================

    @BeforeMethod(alwaysRun = true)
    @Override
    public void setUp() {
        // Gọi setUp của BaseTest để khởi tạo ChromeDriver
        super.setUp();
    }

    // ===================================================================
    //  HELPERS
    // ===================================================================

    private WebDriverWait getWait() {
        return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(40));
    }

    private String getBodyText() {
        return Constant.WEBDRIVER.findElement(By.tagName("body")).getText();
    }

    /** Chờ ngắn để animation/render hoàn tất — dùng WebDriverWait thay Thread.sleep khi có thể */
    private void waitRender() {
        try { Thread.sleep(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    /**
     * Mở Monitor và chờ dữ liệu render xong.
     */
    private void openMonitor() {
        WebDriverWait wait = getWait();
        Constant.WEBDRIVER.get(MONITOR_URL);
        waitRender();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
        wait.until(driver -> {
            String body = driver.findElement(By.tagName("body")).getText();
            return body.contains("Monitor") || body.contains("Station") || body.contains("No data");
        });
        waitRender();
    }

    /**
     * Click vào card trạm đầu tiên hoặc nút "View details" đầu tiên.
     * Ưu tiên: nút "View details" → card trạm → row table.
     */
    private void clickFirstStationOrViewDetails() {
        WebDriverWait wait = getWait();

        // Ưu tiên 1: nút "View details" / "View Details"
        By btnViewDetails = By.xpath(
            "//button[contains(text(),'View details') or contains(text(),'View Details') or contains(text(),'Details')]" +
            " | //a[contains(text(),'View details') or contains(text(),'View Details')]"
        );
        List<WebElement> viewBtns = Constant.WEBDRIVER.findElements(btnViewDetails);
        if (!viewBtns.isEmpty()) {
            scrollToElement(viewBtns.get(0));
            viewBtns.get(0).click();
            waitRender();
            return;
        }

        // Ưu tiên 2: station card có class chứa "station" hoặc "card"
        By[] cardLocators = {
            By.cssSelector(".station-card"),
            By.cssSelector("[class*='station-card']"),
            By.cssSelector("[class*='card-station']"),
            By.cssSelector(".card[data-id]"),
            By.xpath("//div[contains(@class,'station') and contains(@class,'card')]"),
            By.xpath("//div[contains(@class,'card')][.//*[contains(text(),'Station') or contains(text(),'Online') or contains(text(),'Offline')]]"),
            By.xpath("//table/tbody/tr[1]/td[1]")
        };

        for (By loc : cardLocators) {
            List<WebElement> els = Constant.WEBDRIVER.findElements(loc);
            if (!els.isEmpty()) {
                try {
                    WebElement el = wait.until(ExpectedConditions.elementToBeClickable(els.get(0)));
                    scrollToElement(el);
                    el.click();
                    waitRender();
                    return;
                } catch (Exception ignored) { }
            }
        }

        Assert.fail("TC SETUP: Không tìm thấy station card hoặc nút 'View details' trên Monitor");
    }

    /**
     * Kiểm tra panel chi tiết đang hiển thị dựa trên DOM element thực sự.
     */
    private boolean isDetailPanelVisible() {
        // Tìm element có class detail/drawer đang visible trong DOM
        List<WebElement> panels = Constant.WEBDRIVER.findElements(DETAIL_PANEL);
        for (WebElement p : panels) {
            try {
                if (p.isDisplayed()) return true;
            } catch (Exception ignored) { }
        }

        // Kiểm tra thêm: nút Return chỉ xuất hiện khi panel mở
        List<WebElement> returnBtns = Constant.WEBDRIVER.findElements(BTN_RETURN);
        for (WebElement btn : returnBtns) {
            try {
                if (btn.isDisplayed()) return true;
            } catch (Exception ignored) { }
        }

        // Kiểm tra: "Station Information" section chỉ có trong panel chi tiết
        List<WebElement> infoSections = Constant.WEBDRIVER.findElements(SECTION_STATION_INFO);
        for (WebElement sec : infoSections) {
            try {
                if (sec.isDisplayed()) return true;
            } catch (Exception ignored) { }
        }

        return false;
    }

    /** Scroll element vào view — dùng JS để tránh xung đột với scrollIntoView của GeneralPage */
    private void scrollToElement(WebElement el) {
        try {
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].scrollIntoView({block:'center'});", el);
        } catch (Exception ignored) { }
    }

    private boolean tryClickClose(By locator) {
        try {
            List<WebElement> els = Constant.WEBDRIVER.findElements(locator);
            for (WebElement el : els) {
                if (el.isDisplayed()) {
                    scrollToElement(el);
                    el.click();
                    return true;
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void tryEscape() {
        try {
            Constant.WEBDRIVER.findElement(By.tagName("body")).sendKeys(Keys.ESCAPE);
        } catch (Exception ignored) { }
    }

    // ===================================================================
    //  TC3.11 - Mở màn hình chi tiết trạm từ card Monitor
    // ===================================================================

    /**
     * TC3.11 - Mở màn hình chi tiết trạm từ card Monitor
     *
     * Steps:
     *   1. Mở màn hình Monitor
     *   2. Chọn "View details" tại một trạm hoặc nhấn vào card trạm cần xem
     *
     * Expected:
     *   - Hệ thống hiển thị panel/drawer chi tiết của trạm đã chọn
     *   - Tiêu đề panel hiển thị đúng tên trạm
     *   - Panel chi tiết hiển thị bên phải đè trên màn hình Monitor hiện tại
     *   - Hiển thị nút "Return" và nút "X"
     */
    @Test(description = "TC3.11 - Mo man hinh chi tiet tram tu card Monitor")
    public void TC3_11_OpenStationDetail() {
        WebDriverWait wait = getWait();

        // Step 1: Mở Monitor
        openMonitor();

        // Step 2: Click card trạm hoặc nút View details
        clickFirstStationOrViewDetails();

        // Chờ panel chi tiết render
        wait.until(driver -> isDetailPanelVisible()
                || getBodyText().contains("Station Information")
                || getBodyText().contains("Return")
                || getBodyText().contains("Connector"));

        String body = getBodyText();

        // Verify 1: Panel chi tiết hiển thị
        Assert.assertTrue(
            isDetailPanelVisible(),
            "TC3.11 FAIL: Panel chi tiết trạm không hiển thị sau khi click. Body: " + body
        );

        // Verify 2: Tiêu đề panel có tên trạm
        boolean hasPanelTitle = !Constant.WEBDRIVER.findElements(DETAIL_TITLE).isEmpty()
                || body.contains("Station");
        Assert.assertTrue(hasPanelTitle,
            "TC3.11 FAIL: Tiêu đề panel không hiển thị tên trạm. Body: " + body);

        // Verify 3: Có nút Return hoặc nút X
        boolean hasCloseControl =
                !Constant.WEBDRIVER.findElements(BTN_RETURN).isEmpty()
                || !Constant.WEBDRIVER.findElements(BTN_CLOSE).isEmpty()
                || body.contains("Return");
        Assert.assertTrue(hasCloseControl,
            "TC3.11 FAIL: Không tìm thấy nút 'Return' hoặc nút 'X' trên panel chi tiết. Body: " + body);
    }

    // ===================================================================
    //  TC3.12 - Hiển thị đúng thông tin chi tiết trạm
    // ===================================================================

    /**
     * TC3.12 - Hiển thị đúng thông tin chi tiết trạm
     *
     * Steps:
     *   1. Nhấn View details của một trạm
     *   2. Quan sát phần Station Information
     *
     * Expected:
     *   - Panel/drawer chi tiết của trạm hiển thị
     *   - Tiêu đề panel hiển thị đúng tên trạm
     *   - Phần Station Information hiển thị: tên trạm, địa chỉ, trạng thái
     */
    @Test(description = "TC3.12 - Hien thi dung thong tin chi tiet tram")
    public void TC3_12_StationInformation() {
        WebDriverWait wait = getWait();

        // Step 1: Mở Monitor + click View details
        openMonitor();
        clickFirstStationOrViewDetails();

        wait.until(driver -> isDetailPanelVisible()
                || getBodyText().contains("Station Information")
                || getBodyText().contains("Address"));

        String body = getBodyText();

        // Verify 1: Panel chi tiết hiển thị
        Assert.assertTrue(isDetailPanelVisible(),
            "TC3.12 FAIL: Panel chi tiết không hiển thị. Body: " + body);

        // Verify 2: Có section Station Information
        boolean hasInfoSection =
                !Constant.WEBDRIVER.findElements(SECTION_STATION_INFO).isEmpty()
                || body.contains("Station Information")
                || body.contains("Station Info");
        Assert.assertTrue(hasInfoSection,
            "TC3.12 FAIL: Không thấy phần 'Station Information'. Body: " + body);

        // Verify 3: Có tên trạm
        boolean hasName = body.contains("Station") && (body.contains("Name") || body.contains("ST"));
        Assert.assertTrue(hasName,
            "TC3.12 FAIL: Không thấy tên trạm trong panel chi tiết. Body: " + body);

        // Verify 4: Có địa chỉ
        boolean hasAddress = body.contains("Address") || body.contains("address")
                || body.contains("District") || body.contains("Street");
        Assert.assertTrue(hasAddress,
            "TC3.12 FAIL: Không thấy địa chỉ trạm trong panel chi tiết. Body: " + body);

        // Verify 5: Có trạng thái trạm
        boolean hasStatus = body.contains("Online") || body.contains("Offline")
                || body.contains("Status") || body.contains("Active");
        Assert.assertTrue(hasStatus,
            "TC3.12 FAIL: Không thấy trạng thái trạm trong panel chi tiết. Body: " + body);
    }

    // ===================================================================
    //  TC3.13 - Hiển thị đúng danh sách connector và statistics
    // ===================================================================

    /**
     * TC3.13 - Hiển thị đúng danh sách connector và statistics
     *
     * Steps:
     *   1. Mở panel chi tiết của một trạm
     *   2. Quan sát phần Connectors và Statistics
     *
     * Expected:
     *   - Phần Connectors: danh sách connector, mỗi connector có tên/mã và trạng thái
     *     (Available / In Use / Fault)
     *   - Phần Statistics: Total sessions, Delivered energy, Uptime
     *   - Dữ liệu đúng định dạng và đúng theo trạm đã chọn
     */
    @Test(description = "TC3.13 - Hien thi dung danh sach connector va statistics")
    public void TC3_13_ConnectorsAndStatistics() {
        WebDriverWait wait = getWait();

        // Step 1: Mở Monitor + mở panel chi tiết
        openMonitor();
        clickFirstStationOrViewDetails();

        wait.until(driver -> isDetailPanelVisible()
                || getBodyText().contains("Connector")
                || getBodyText().contains("Statistics"));

        String body = getBodyText();

        // Verify 1: Panel chi tiết hiển thị
        Assert.assertTrue(isDetailPanelVisible(),
            "TC3.13 FAIL: Panel chi tiết không hiển thị. Body: " + body);

        // Verify 2: Có phần Connectors
        boolean hasConnectors =
                !Constant.WEBDRIVER.findElements(SECTION_CONNECTORS).isEmpty()
                || body.contains("Connector");
        Assert.assertTrue(hasConnectors,
            "TC3.13 FAIL: Không thấy phần Connectors trong panel chi tiết. Body: " + body);

        // Verify 3: Connector có trạng thái (Available / In Use / Fault)
        boolean hasConnectorStatus =
                body.contains("Available") || body.contains("In Use")
                || body.contains("Fault") || body.contains("Idle")
                || body.contains("Charging") || body.contains("Online");
        Assert.assertTrue(hasConnectorStatus,
            "TC3.13 FAIL: Connector không hiển thị trạng thái (Available/In Use/Fault). Body: " + body);

        // Verify 4: Có phần Statistics
        boolean hasStatistics =
                !Constant.WEBDRIVER.findElements(SECTION_STATISTICS).isEmpty()
                || body.contains("Statistics") || body.contains("Total sessions")
                || body.contains("Delivered energy") || body.contains("Uptime")
                || body.contains("Energy") || body.contains("Session");
        Assert.assertTrue(hasStatistics,
            "TC3.13 FAIL: Không thấy phần Statistics (Total sessions / Delivered energy / Uptime). Body: " + body);
    }

    // ===================================================================
    //  TC3.14 - Đóng màn hình chi tiết và quay lại danh sách
    // ===================================================================

    /**
     * TC3.14 - Đóng màn hình chi tiết và quay lại danh sách
     *
     * Steps:
     *   1. Mở panel chi tiết trạm
     *   2. Nhấn nút "X" hoặc nút "Return" hoặc nhấn vùng ngoài panel chi tiết
     *
     * Expected:
     *   - Panel chi tiết được đóng
     *   - Hệ thống quay lại màn hình Monitor
     *   - Danh sách trạm và trạng thái tìm kiếm/lọc trước đó vẫn được giữ nguyên
     */
    @Test(description = "TC3.14 - Dong man hinh chi tiet va quay lai danh sach")
    public void TC3_14_CloseStationDetail() {
        WebDriverWait wait = getWait();

        // Step 1: Mở Monitor + mở panel chi tiết
        openMonitor();
        clickFirstStationOrViewDetails();

        // Chờ panel mở
        wait.until(driver -> isDetailPanelVisible()
                || getBodyText().contains("Return")
                || getBodyText().contains("Station Information"));

        Assert.assertTrue(isDetailPanelVisible(),
            "TC3.14 SETUP: Panel chi tiết không mở được để test đóng");

        // Step 2: Thử đóng bằng nút Return trước, sau đó nút X, cuối cùng Escape
        tryClickClose(BTN_RETURN);

        // Nếu Return không đóng được, thử nút X
        waitRender();
        if (isDetailPanelVisible()) {
            tryClickClose(BTN_CLOSE);
            waitRender();
        }

        // Nếu vẫn còn, thử Escape
        if (isDetailPanelVisible()) {
            tryEscape();
            waitRender();
        }

        String bodyAfter = getBodyText();

        // Verify 1: Panel chi tiết đã đóng
        boolean panelClosed = !isDetailPanelVisible();
        Assert.assertTrue(panelClosed,
            "TC3.14 FAIL: Panel chi tiết vẫn còn hiển thị sau khi nhấn đóng. Body: " + bodyAfter);

        // Verify 2: Quay lại màn hình Monitor
        boolean backToMonitor =
                Constant.WEBDRIVER.getCurrentUrl().contains("monitor")
                || bodyAfter.contains("Search")
                || bodyAfter.contains("Reset")
                || bodyAfter.contains("Monitor");
        Assert.assertTrue(backToMonitor,
            "TC3.14 FAIL: Không quay lại màn hình Monitor sau khi đóng panel. Body: " + bodyAfter);
    }
}
