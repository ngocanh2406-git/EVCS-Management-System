package testcases;

import Constant.Constant;
import PageObjects.PolePage;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * NGUNG HOAT DONG TRU SAC (DEACTIVATE POLE): TC2.19 -> TC2.22
 *
 *   TC2.19 - Ngung hoat dong tru sac thanh cong
 *   TC2.20 - Hien thi popup xac nhan khi ngung hoat dong
 *   TC2.21 - Huy thao tac ngung hoat dong
 *   TC2.22 - Loi he thong khi cap nhat trang thai
 */
public class DeactivatePoleTest extends BaseTest {

    private PolePage polePage;

    @BeforeMethod(alwaysRun = true)
    public void openPolePage() {
        polePage = new PolePage();
        polePage.acceptAlertIfPresent();
        homePage.openPole();
        polePage.waitForPolePageReady();
        polePage.waitPoleTableLoaded();
        System.out.println("[BeforeMethod] Trang Pole da load xong.");
    }

    // =========================================================
    /**
     * TC2.19 - Ngung hoat dong tru sac thanh cong
     *
     * Buoc 1: Truy cap trang Pole Management
     * Buoc 2: Tim tru dang Active, click toggle (chuyen sang OFF)
     * Buoc 3: Nhan "Confirm" trong popup
     * Expected: He thong cap nhat trang thai tru thanh "Inactive"
     */
    @Test(description = "TC2.19 - Ngung hoat dong tru sac thanh cong")
    public void TC2_19_DeactivatePoleSuccessfully() {
        System.out.println("\n========== TC2.19: Ngung hoat dong tru sac ==========");

        // Buoc 2: Tim tru dang Active
        WebElement activeRow = polePage.findFirstPoleRowByStatus("Active");
        if (activeRow == null) {
            throw new SkipException("TC2.19 SKIP: Khong co pole Active nao trong bang.");
        }
        String poleName = polePage.getPoleNameFromRow(activeRow);
        System.out.println("TC2.19 Tru se deactivate: '" + poleName + "'");

        // Click toggle
        polePage.clickToggleInPoleRow(activeRow);
        polePage.debugDumpVisiblePopups();

        // Buoc 3: Xu ly popup
        boolean popupShown = polePage.isConfirmPopupDisplayed();
        System.out.println("TC2.19 Popup hien thi: " + popupShown);
        Assert.assertTrue(popupShown,
            "TC2.19 FAIL: Popup xac nhan khong hien thi sau khi click toggle");

        String popupTitle = polePage.getConfirmPopupTitle();
        System.out.println("TC2.19 Popup title: '" + popupTitle + "'");

        polePage.confirmActivate(); // dung confirmActivate() de accept popup

        // Cho status doi thanh Inactive
        boolean changed = polePage.waitPoleStatusChanged(poleName, "Inactive");
        System.out.println("TC2.19 Status da doi: " + changed);

        // Reload va verify
        polePage.navigateToPolePage();
        polePage.waitPoleTableLoaded();

        String statusAfter = polePage.getPoleStatusByName(poleName);
        System.out.println("TC2.19 Status sau deactivate: '" + statusAfter + "'");
        Assert.assertEquals(statusAfter, "Inactive",
            "TC2.19 FAIL: Status khong doi thanh Inactive. Actual='" + statusAfter + "'");
        System.out.println("TC2.19 PASS: Tru '" + poleName + "' da chuyen sang Inactive.");
        System.out.println("========== TC2.19: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.20 - Hien thi popup xac nhan khi ngung hoat dong
     *
     * Buoc 1: Tim tru dang Active, click toggle (chuyen sang OFF)
     * Expected: He thong hien thi popup xac nhan ngung hoat dong
     */
    @Test(description = "TC2.20 - Hien thi popup xac nhan khi ngung hoat dong")
    public void TC2_20_ShowConfirmPopupOnDeactivate() {
        System.out.println("\n========== TC2.20: Hien thi popup xac nhan ==========");

        WebElement activeRow = polePage.findFirstPoleRowByStatus("Active");
        if (activeRow == null) {
            throw new SkipException("TC2.20 SKIP: Khong co pole Active nao trong bang.");
        }
        String poleName = polePage.getPoleNameFromRow(activeRow);
        System.out.println("TC2.20 Tru: '" + poleName + "'");

        // Buoc 1: Click toggle
        polePage.clickToggleInPoleRow(activeRow);

        // Verify 1: popup hien thi
        Assert.assertTrue(polePage.isConfirmPopupDisplayed(),
            "TC2.20 FAIL: Popup xac nhan khong hien thi sau khi click toggle");
        System.out.println("TC2.20 Popup da hien thi.");

        // Verify 2: kiem tra noi dung popup hoac nut xac nhan
        String popupText = polePage.getConfirmPopupText();
        System.out.println("TC2.20 Popup text: '" + popupText + "'");

        boolean hasContent = popupText.toLowerCase().contains("confirm")
            || popupText.toLowerCase().contains("are you sure")
            || popupText.toLowerCase().contains("deactivate")
            || popupText.toLowerCase().contains("ngung")
            || popupText.toLowerCase().contains("xac nhan");

        if (hasContent) {
            System.out.println("TC2.20 PASS: Popup co noi dung xac nhan.");
        } else {
            // Popup khong co text ro rang — verify bang nut Confirm/Cancel
            boolean hasConfirmBtn = polePage.isConfirmButtonDisplayed();
            boolean hasCancelBtn  = polePage.isCancelButtonDisplayed();
            System.out.println("TC2.20 Confirm button: " + hasConfirmBtn + ", Cancel button: " + hasCancelBtn);
            Assert.assertTrue(hasConfirmBtn || hasCancelBtn,
                "TC2.20 FAIL: Popup khong co noi dung va khong co nut xac nhan/huy");
            System.out.println("TC2.20 PASS: Popup co nut xac nhan.");
        }

        // Huy de khong thay doi data
        polePage.cancelActivate();
        System.out.println("TC2.20 PASS: Popup xac nhan da hien thi dung.");
        System.out.println("========== TC2.20: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.21 - Huy thao tac ngung hoat dong
     *
     * Buoc 1: Tim tru dang Active, ghi nhan status ban dau
     * Buoc 2: Click toggle (chuyen sang OFF)
     * Buoc 3: Nhan "Cancel" tai popup
     * Expected: He thong khong thay doi trang thai, toggle van o muc ON (Active)
     */
    @Test(description = "TC2.21 - Huy thao tac ngung hoat dong")
    public void TC2_21_CancelDeactivatePole() {
        System.out.println("\n========== TC2.21: Huy ngung hoat dong ==========");

        WebElement activeRow = polePage.findFirstPoleRowByStatus("Active");
        if (activeRow == null) {
            throw new SkipException("TC2.21 SKIP: Khong co pole Active nao trong bang.");
        }
        String poleName = polePage.getPoleNameFromRow(activeRow);
        String originalStatus = polePage.getPoleStatusFromRow(activeRow);
        System.out.println("TC2.21 Status ban dau: '" + originalStatus + "', ten: '" + poleName + "'");

        // Buoc 2: Click toggle
        polePage.clickToggleInPoleRow(activeRow);
        Assert.assertTrue(polePage.isConfirmPopupDisplayed(),
            "TC2.21 SETUP: Popup khong hien thi");

        // Buoc 3: Click Cancel
        polePage.cancelActivate();

        // Verify: popup da dong
        Assert.assertFalse(polePage.isConfirmPopupDisplayed(),
            "TC2.21 FAIL: Popup van con hien thi sau khi nhan Cancel");
        System.out.println("TC2.21 Popup da dong.");

        // Reload va verify status khong thay doi
        polePage.navigateToPolePage();
        polePage.waitPoleTableLoaded();

        String currentStatus = polePage.getPoleStatusByName(poleName);
        System.out.println("TC2.21 Status sau cancel + reload: '" + currentStatus + "'");
        Assert.assertEquals(currentStatus, originalStatus,
            "TC2.21 FAIL: Status da thay doi du da nhan Cancel. Before='"
            + originalStatus + "', After='" + currentStatus + "'");
        System.out.println("TC2.21 PASS: Status khong thay doi sau khi huy.");
        System.out.println("========== TC2.21: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.22 - Loi he thong khi cap nhat trang thai
     *
     * Buoc 1: Tim tru dang Active, click toggle
     * Buoc 2: Nhan "Confirm" khi he thong loi (simulate API error)
     * Expected: He thong hien thi loi va khong thay doi trang thai
     */
    @Test(description = "TC2.22 - Loi he thong khi cap nhat trang thai")
    public void TC2_22_SystemErrorOnDeactivate() {
        System.out.println("\n========== TC2.22: Loi he thong khi cap nhat trang thai ==========");

        WebElement activeRow = polePage.findFirstPoleRowByStatus("Active");
        if (activeRow == null) {
            throw new SkipException("TC2.22 SKIP: Khong co pole Active nao trong bang.");
        }
        String poleName = polePage.getPoleNameFromRow(activeRow);
        String originalStatus = polePage.getPoleStatusFromRow(activeRow);
        System.out.println("TC2.22 Status ban dau: '" + originalStatus + "', ten: '" + poleName + "'");

        // Buoc 1: Click toggle
        polePage.clickToggleInPoleRow(activeRow);
        Assert.assertTrue(polePage.isConfirmPopupDisplayed(),
            "TC2.22 SETUP: Popup khong hien thi");

        // Override fetch de simulate loi 500
        ((org.openqa.selenium.JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "window._origFetch = window.fetch;" +
            "window.fetch = function(url, opts) {" +
            "  if (url && (url.toString().includes('/poles') && url.toString().includes('/status'))) {" +
            "    return Promise.resolve({" +
            "      ok: false, status: 500," +
            "      json: function() { return Promise.resolve({message: 'Server Error'}); }" +
            "    });" +
            "  }" +
            "  return window._origFetch.apply(this, arguments);" +
            "};"
        );
        System.out.println("TC2.22 Da override fetch de simulate loi.");

        // Buoc 2: Click Confirm
        polePage.confirmActivate();
        try { Thread.sleep(1500); } catch (InterruptedException ignored) {}

        // Restore fetch
        ((org.openqa.selenium.JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "if (window._origFetch) window.fetch = window._origFetch;"
        );

        // Verify: co alert loi HOAC status khong thay doi
        boolean hasAlert = polePage.isAlertPresent();
        if (hasAlert) {
            String alertText = polePage.getAlertTextAndAccept();
            System.out.println("TC2.22 Alert: '" + alertText + "'");
            Assert.assertTrue(
                alertText.toLowerCase().contains("error") ||
                alertText.toLowerCase().contains("fail") ||
                alertText.toLowerCase().contains("unable") ||
                alertText.toLowerCase().contains("loi"),
                "TC2.22 FAIL: Alert khong phai thong bao loi. Actual='" + alertText + "'");
        } else {
            // Khong co alert → kiem tra status khong thay doi
            String currentStatus = polePage.getPoleStatusByName(poleName);
            System.out.println("TC2.22 Status sau loi: '" + currentStatus + "'");
            Assert.assertEquals(currentStatus, originalStatus,
                "TC2.22 FAIL: Status da thay doi du co loi. Before='"
                + originalStatus + "', After='" + currentStatus + "'");
        }
        System.out.println("TC2.22 PASS: He thong xu ly loi dung.");
        System.out.println("========== TC2.22: PASSED ==========\n");
    }
}
