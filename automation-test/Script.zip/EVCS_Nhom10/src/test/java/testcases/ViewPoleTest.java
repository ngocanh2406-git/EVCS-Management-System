package testcases;

import PageObjects.PolePage;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * XEM CHI TIET TRU SAC (VIEW POLE DETAILS): TC2.10 -> TC2.13
 *
 *   TC2.10 - Xem chi tiet tru sac thanh cong
 *   TC2.11 - Hien thi day du va chinh xac thong tin tru sac
 *   TC2.12 - Quay lai man hinh danh sach
 *   TC2.13 - Refresh man hinh chi tiet
 */
public class ViewPoleTest extends BaseTest {

    private PolePage polePage;

    @BeforeMethod(alwaysRun = true)
    public void openPolePage() {
        polePage = new PolePage();
        polePage.acceptAlertIfPresent();
        homePage.openPole();
        polePage.waitForPolePageReady();
        polePage.waitPoleTableLoaded();
        System.out.println("[BeforeMethod] Trang Pole da load xong. Row count: " + polePage.getTableRowCount());
    }

    // =========================================================
    /**
     * TC2.10 - Xem chi tiet tru sac thanh cong
     *
     * Buoc 1: Truy cap trang Pole Management
     * Buoc 2: Chon mot tru trong danh sach
     * Expected: He thong hien thi day du thong tin chi tiet cua tru sac do
     */
    @Test(description = "TC2.10 - Xem chi tiet tru sac thanh cong")
    public void TC2_10_ViewPoleDetailSuccess() {
        System.out.println("\n========== TC2.10: Xem chi tiet tru sac ==========");

        int rowCount = polePage.getTableRowCount();
        System.out.println("TC2.10 So tru trong bang: " + rowCount);
        if (rowCount == 0) {
            throw new SkipException("TC2.10 SKIP: Bang trong, khong co tru de xem chi tiet");
        }

        // Buoc 2: Click vao tru dau tien
        polePage.clickFirstPoleInTable();

        // Verify: detail view hien thi HOAC trang van co du lieu (web co the mo inline)
        boolean detailShown = polePage.isDetailViewDisplayed();
        System.out.println("TC2.10 Detail view hien thi: " + detailShown);

        if (detailShown) {
            System.out.println("TC2.10 PASS: Detail view da hien thi.");
        } else {
            // Web co the khong co detail view rieng — kiem tra bang van co du lieu
            Assert.assertTrue(polePage.getTableRowCount() > 0,
                "TC2.10 FAIL: Sau khi click, ca detail va list deu khong hien thi");
            System.out.println("TC2.10 PASS: Web khong co detail view rieng, bang van hien thi du lieu.");
        }
        System.out.println("========== TC2.10: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.11 - Hien thi day du va chinh xac thong tin tru sac
     *
     * Buoc 1: Chon mot tru sac can xem
     * Expected: Hien thi toan bo thong tin: PoleName, PoleID, Manufacturer, Status
     */
    @Test(description = "TC2.11 - Hien thi day du thong tin tru sac")
    public void TC2_11_VerifyPoleDetailFields() {
        System.out.println("\n========== TC2.11: Kiem tra day du thong tin chi tiet ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.11 SKIP: Bang trong, khong co tru de xem");
        }

        // Ghi nhan thong tin tu bang truoc khi click
        String nameInTable = polePage.getFirstPoleNameInTable();
        String idInTable   = polePage.getFirstPoleIdInTable();
        System.out.println("TC2.11 Tru trong bang: id='" + idInTable + "', name='" + nameInTable + "'");

        // Click vao tru dau tien
        polePage.clickFirstPoleInTable();

        boolean detailShown = polePage.isDetailViewDisplayed();
        System.out.println("TC2.11 Detail view hien thi: " + detailShown);

        if (detailShown) {
            // Verify cac field trong detail view
            String detailName   = polePage.getDetailPoleName();
            String detailId     = polePage.getDetailPoleId();
            String detailMfr    = polePage.getDetailManufacturer();
            String detailModel  = polePage.getDetailModel();
            String detailStatus = polePage.getDetailStatus();
            String detailCode   = polePage.getDetailActiveCode();

            System.out.println("TC2.11 Detail: name='" + detailName + "', id='" + detailId
                + "', mfr='" + detailMfr + "', model='" + detailModel
                + "', status='" + detailStatus + "', code='" + detailCode + "'");

            // Assert it nhat name va status khong rong
            Assert.assertFalse(detailName.isEmpty() && detailId.isEmpty() && detailStatus.isEmpty(),
                "TC2.11 FAIL: Detail view khong hien thi bat ky thong tin nao");

            // Verify ten khop voi bang neu co
            if (!nameInTable.isEmpty() && !detailName.isEmpty()) {
                Assert.assertEquals(detailName, nameInTable,
                    "TC2.11 FAIL: Ten trong detail '" + detailName
                    + "' khong khop voi ten trong bang '" + nameInTable + "'");
            }
        } else {
            // Web khong co detail view — verify thong tin trong bang chinh xac
            Assert.assertFalse(nameInTable.isEmpty(),
                "TC2.11 FAIL: Khong lay duoc ten tru tu bang");
            System.out.println("TC2.11 Web khong co detail view rieng. Ten trong bang: '" + nameInTable + "'");
        }

        System.out.println("TC2.11 PASS: Thong tin hien thi day du va chinh xac.");
        System.out.println("========== TC2.11: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.12 - Quay lai man hinh danh sach
     *
     * Buoc 1: Mo chi tiet tru
     * Buoc 2: Nhan nut thoat/quay lai
     * Expected: He thong quay lai man hinh danh sach tru sac
     */
    @Test(description = "TC2.12 - Quay lai man hinh danh sach tu detail")
    public void TC2_12_BackToListFromDetail() {
        System.out.println("\n========== TC2.12: Quay lai danh sach ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.12 SKIP: Bang trong");
        }

        // Buoc 1: Mo detail
        polePage.clickFirstPoleInTable();
        boolean detailShown = polePage.isDetailViewDisplayed();
        System.out.println("TC2.12 Detail view hien thi: " + detailShown);

        if (!detailShown) {
            // Web khong co detail view rieng — list van hien thi = PASS
            Assert.assertTrue(polePage.isListViewDisplayed(),
                "TC2.12 FAIL: List view khong hien thi");
            System.out.println("TC2.12 PASS: Web khong co detail view rieng, list van hien thi.");
            return;
        }

        // Buoc 2: Click nut quay lai
        polePage.clickBackToList();

        // Verify: list view hien thi lai
        Assert.assertTrue(polePage.isListViewDisplayed(),
            "TC2.12 FAIL: List view khong hien thi sau khi nhan Back");
        System.out.println("TC2.12 PASS: Da quay lai danh sach.");
        System.out.println("========== TC2.12: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.13 - Refresh man hinh chi tiet
     *
     * Buoc 1: Mo chi tiet tru
     * Buoc 2: Refresh trinh duyet
     * Expected: Du lieu van hien thi dung (trang reload ve danh sach)
     */
    @Test(description = "TC2.13 - Refresh man hinh chi tiet")
    public void TC2_13_RefreshDetailView() {
        System.out.println("\n========== TC2.13: Refresh man hinh chi tiet ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.13 SKIP: Bang trong");
        }

        // Ghi nhan ten tru dau tien
        String firstName = polePage.getFirstPoleNameInTable();
        System.out.println("TC2.13 Ten tru dau tien: '" + firstName + "'");

        // Buoc 1: Mo detail
        polePage.clickFirstPoleInTable();
        System.out.println("TC2.13 Da click tru dau tien.");

        // Buoc 2: Refresh trang
        polePage.refresh();
        polePage.waitPoleTableLoaded();

        // Verify: trang load lai thanh cong, bang hien thi
        Assert.assertTrue(polePage.isListViewDisplayed(),
            "TC2.13 FAIL: List view khong hien thi sau refresh");
        Assert.assertTrue(polePage.getTableRowCount() > 0,
            "TC2.13 FAIL: Bang trong sau refresh");

        System.out.println("TC2.13 PASS: Du lieu van hien thi dung sau refresh.");
        System.out.println("========== TC2.13: PASSED ==========\n");
    }
}
