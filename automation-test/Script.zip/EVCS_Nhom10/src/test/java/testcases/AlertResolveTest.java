package testcases;

import Constant.Constant;
import PageObjects.AlertPage;
import PageObjects.AlertPage.AlertRow;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

/**
 * TC5.28 - TC5.35: Alert Resolve & Status Update
 */
public class AlertResolveTest extends BaseTest {

    private AlertPage alertPage;
    private static final String DETAIL_BASE =
        "https://evsc-production.up.railway.app/alert-detail.html";

    @BeforeMethod(alwaysRun = true)
    public void setup() {
        alertPage = new AlertPage();
        // Bước 1: Mở station.html để set đúng domain cho localStorage
        alertPage.navigateToStationPage();
        // Bước 2: Seed dữ liệu alert
        seedAlerts();
    }

    private void seedAlerts() {
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "localStorage.removeItem('evc-alerts-data-v1');" +
            "var d=[" +
            "{id:'ALT-1001',type:'Connection Lost',stationName:'Station 1',occurredAt:'2026-04-08T08:15:00',severity:'critical',status:'open',description:'Station connection lost',suggestion:'Check network',logs:[]}," +
            "{id:'ALT-1002',type:'Charger Overheating',stationName:'Station 3',occurredAt:'2026-04-08T09:40:00',severity:'critical',status:'open',description:'Temperature exceeded',suggestion:'Check cooling',logs:[]}," +
            "{id:'ALT-1003',type:'Charging Port Error',stationName:'Station 2',occurredAt:'2026-04-08T10:05:00',severity:'medium',status:'open',description:'Port error E-24',suggestion:'Reset port',logs:[]}," +
            "{id:'ALT-1004',type:'Abnormal Current',stationName:'Station 4',occurredAt:'2026-04-07T15:20:00',severity:'medium',status:'resolved',description:'Current fluctuation',suggestion:'Monitor supply',logs:[]}," +
            "{id:'ALT-1005',type:'Scheduled Maintenance Reminder',stationName:'Station 5',occurredAt:'2026-04-06T11:30:00',severity:'low',status:'resolved',description:'Maintenance due',suggestion:'Schedule inspection',logs:[]}" +
            "];" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));"
        );
    }

    /**
     * Seed localStorage trên trang alert-detail.html (cùng domain).
     * Cần thiết vì alert-detail.html đọc localStorage từ domain của nó.
     */
    private void seedAlertsOnDetailPage(String alertId) {
        // Mở alert-detail.html trước để đúng domain
        Constant.WEBDRIVER.navigate().to(DETAIL_BASE + "?id=" + alertId);
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(d -> ((JavascriptExecutor) d)
                .executeScript("return document.readyState").equals("complete"));
        // Seed lại localStorage trên domain này
        seedAlerts();
        // Reload để trang đọc data mới
        Constant.WEBDRIVER.navigate().refresh();
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(d -> ((JavascriptExecutor) d)
                .executeScript("return document.readyState").equals("complete"));
        // Chờ detailTitle populate
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(d -> {
                    try { return !d.findElement(By.id("detailTitle")).getText().trim().isEmpty(); }
                    catch (Exception e) { return false; }
                });
        } catch (Exception ignored) {}
    }

    private String getStoredStatus(String alertId) {
        return alertPage.getAlertStatusFromStorageOptional(alertId);
    }

    // =========================================================
    /**
     * TC5.28 - Mark as Resolved thành công
     *
     * Bước 1: Seed data trên domain alert-detail.html
     * Bước 2: Mở alert-detail.html?id=ALT-1002
     * Bước 3: Click resolveBtn
     * Bước 4: Chờ status badge đổi thành "Resolved"
     * Bước 5: Assert status = Resolved
     */
    @Test(description = "TC5.28 - Mark as Resolved thanh cong")
    public void TC5_28_MarkAsResolved() {
        // Bước 1 & 2: Seed và mở detail
        seedAlertsOnDetailPage("ALT-1002");

        String statusBefore = Constant.WEBDRIVER.findElement(By.id("detailStatusBadge")).getText().trim();
        System.out.println("TC5.28 Status trước: '" + statusBefore + "'");

        // Bước 3: Click Resolve
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("resolveBtn"))).click();

        // Bước 4: Chờ badge đổi
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(d -> {
                    try { return "Resolved".equals(d.findElement(By.id("detailStatusBadge")).getText().trim()); }
                    catch (Exception e) { return false; }
                });
        } catch (Exception ignored) {}

        String statusAfter = Constant.WEBDRIVER.findElement(By.id("detailStatusBadge")).getText().trim();
        System.out.println("TC5.28 Status sau: '" + statusAfter + "'");

        // Bước 5: Assert
        if (!"Resolved".equals(statusAfter)) {
            // Fallback: check storage
            String stored = getStoredStatus("ALT-1002");
            System.out.println("TC5.28 Storage status: '" + stored + "'");
            Assert.assertEquals(stored, "resolved",
                "TC5.28 FAIL: Status không đổi. DOM='" + statusAfter + "', Storage='" + stored + "'");
        } else {
            Assert.assertEquals(statusAfter, "Resolved",
                "TC5.28 FAIL: Badge sai. Actual='" + statusAfter + "'");
        }
        System.out.println("TC5.28 PASS");
    }

    // =========================================================
    /**
     * TC5.29 - Mark as Resolved thành công - verify qua UI sau reload
     *
     * Bước 1: Seed data trên domain alert-detail.html
     * Bước 2: Mở alert-detail.html?id=ALT-1003
     * Bước 3: Click resolveBtn
     * Bước 4: Chờ status badge đổi
     * Bước 5: Reload trang
     * Bước 6: Assert status vẫn là Resolved sau reload (persistence)
     *
     * Note: Không verify localStorage vì web có thể lưu ở backend/state khác.
     *       Verify qua UI behavior: reload vẫn giữ Resolved.
     */
    @Test(description = "TC5.29 - Mark as Resolved thanh cong - verify UI sau reload")
    public void TC5_29_MarkAsResolvedVerifyStorage() {
        // Bước 1 & 2: Seed và mở detail
        seedAlertsOnDetailPage("ALT-1003");

        // Log storage optional (không dùng để assert)
        String storageBefore = getStoredStatus("ALT-1003");
        System.out.println("TC5.29 Storage trước (optional): '" + storageBefore + "'");

        // Bước 3: Click Resolve
        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("resolveBtn"))).click();

        // Bước 4: Chờ badge đổi
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(d -> {
                    try { return "Resolved".equals(d.findElement(By.id("detailStatusBadge")).getText().trim()); }
                    catch (Exception e) { return false; }
                });
        } catch (Exception ignored) {}

        String statusAfterClick = Constant.WEBDRIVER.findElement(By.id("detailStatusBadge")).getText().trim();
        System.out.println("TC5.29 Status sau click: '" + statusAfterClick + "'");

        // Log storage sau click (optional)
        String storageAfter = getStoredStatus("ALT-1003");
        System.out.println("TC5.29 Storage sau click (optional): '" + storageAfter + "'");

        // Bước 5: Reload trang
        Constant.WEBDRIVER.navigate().refresh();
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(d -> ((JavascriptExecutor) d)
                .executeScript("return document.readyState").equals("complete"));
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(d -> {
                    try { return !d.findElement(By.id("detailTitle")).getText().trim().isEmpty(); }
                    catch (Exception e) { return false; }
                });
        } catch (Exception ignored) {}

        // Bước 6: Assert status sau reload
        String statusAfterReload = Constant.WEBDRIVER.findElement(By.id("detailStatusBadge")).getText().trim();
        System.out.println("TC5.29 Status sau reload: '" + statusAfterReload + "'");

        Assert.assertEquals(statusAfterReload, "Resolved",
            "TC5.29 FAIL: Status không giữ 'Resolved' sau reload. "
            + "Sau click='" + statusAfterClick + "', Sau reload='" + statusAfterReload + "'");
        System.out.println("TC5.29 PASS - Status vẫn Resolved sau reload");
    }

    // =========================================================
    /**
     * TC5.30 - Trạng thái alert được cập nhật sau khi resolved
     */
    @Test(description = "TC5.30 - Trang thai alert cap nhat sau khi resolved")
    public void TC5_30_AlertStatusUpdatedAfterResolved() {
        seedAlertsOnDetailPage("ALT-1001");

        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("resolveBtn"))).click();
        try { Thread.sleep(800); } catch (Exception ignored) {}

        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();
        alertPage.applyStatusFilter("resolved");
        alertPage.waitUntilAllVisibleRowsHaveStatus("Resolved");

        String pageText = alertPage.getPageText();
        System.out.println("TC5.30 Page contains 'Connection Lost': " + pageText.contains("Connection Lost"));

        Assert.assertTrue(pageText.contains("Connection Lost"),
            "TC5.30 FAIL: 'Connection Lost' không xuất hiện trong filter Resolved");
    }

    // =========================================================
    /**
     * TC5.31 - Reload vẫn giữ trạng thái Resolved
     */
    @Test(description = "TC5.31 - Reload van giu trang thai Resolved")
    public void TC5_31_ReloadKeepsResolvedStatus() {
        // Resolve ALT-1001 trực tiếp trong localStorage
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "try{var d=JSON.parse(localStorage.getItem('evc-alerts-data-v1')||'[]');" +
            "d=d.map(function(a){return a.id==='ALT-1001'?Object.assign({},a,{status:'resolved'}):a;});" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));}catch(e){}");

        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();
        alertPage.applyStatusFilter("resolved");
        alertPage.waitUntilAllVisibleRowsHaveStatus("Resolved");

        String pageText = alertPage.getPageText();
        System.out.println("TC5.31 Page contains 'Connection Lost': " + pageText.contains("Connection Lost"));

        Assert.assertTrue(pageText.contains("Connection Lost"),
            "TC5.31 FAIL: 'Connection Lost' không hiển thị sau reload với filter Resolved");
    }

    // =========================================================
    /**
     * TC5.32 - Alert resolved không còn xuất hiện khi filter Unresolved
     *
     * Bước 1: Seed data, resolve ALT-1001 trong localStorage
     * Bước 2: Mở alerts.html
     * Bước 3: Reset filter
     * Bước 4: Apply filter Status = Unresolved (open)
     * Bước 5: Chờ list refresh
     * Bước 6: Assert ALT-1001 KHÔNG còn trong visible rows
     */
    @Test(description = "TC5.32 - Alert resolved khong hien thi khi filter Unresolved")
    public void TC5_32_ResolvedAlertNotInUnresolvedFilter() {
        // Bước 1: Resolve ALT-1001 trong localStorage
        System.out.println("TC5.32 Bước 1 - Resolve ALT-1001 trong localStorage...");
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "try{var d=JSON.parse(localStorage.getItem('evc-alerts-data-v1')||'[]');" +
            "d=d.map(function(a){return a.id==='ALT-1001'?Object.assign({},a,{status:'resolved'}):a;});" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));}catch(e){}");

        // Bước 2: Mở alerts.html
        System.out.println("TC5.32 Bước 2 - Mở alerts.html...");
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        // Bước 3: Reset filter
        System.out.println("TC5.32 Bước 3 - Reset filter...");
        alertPage.resetFilters();

        // Bước 4: Apply filter Status = open (Unresolved)
        System.out.println("TC5.32 Bước 4 - Apply filter Unresolved...");
        alertPage.applyStatusFilter("open");

        // Bước 5: Chờ list refresh — chờ ALT-1001 biến mất
        System.out.println("TC5.32 Bước 5 - Chờ ALT-1001 biến mất...");
        alertPage.waitUntilRowDisappears("ALT-1001");
        alertPage.waitUntilAllVisibleRowsHaveStatus("Unresolved");

        // Bước 6: Kiểm tra
        List<AlertRow> rows = alertPage.getAlertRows();
        System.out.println("TC5.32 Bước 6 - Số rows sau filter Unresolved: " + rows.size());
        for (AlertRow r : rows) {
            System.out.println("  Row: " + r);
        }

        // Assert ALT-1001 không còn trong bảng
        boolean alt1001Present = rows.stream()
            .anyMatch(r -> r.alertId.equals("ALT-1001") || r.fullText.contains("ALT-1001"));

        if (alt1001Present) {
            StringBuilder bugMsg = new StringBuilder(
                "TC5.32 BUG UI: Resolved alert ALT-1001 vẫn xuất hiện khi filter Unresolved. Visible rows:\n");
            for (AlertRow r : rows) {
                bugMsg.append("  - ").append(r.alertId).append(" | status=").append(r.status).append("\n");
            }
            Assert.fail(bugMsg.toString());
        }

        System.out.println("TC5.32 PASS - ALT-1001 không còn trong filter Unresolved");
    }

    // =========================================================
    /**
     * TC5.33 - Alert resolved hiển thị đúng khi filter Resolved
     *
     * Bước 1: Seed data, resolve ALT-1001 trong localStorage
     * Bước 2: Mở alerts.html
     * Bước 3: Reset filter
     * Bước 4: Apply filter Status = Resolved
     * Bước 5: Chờ list refresh
     * Bước 6: Assert ALT-1001 xuất hiện và tất cả rows là Resolved
     */
    @Test(description = "TC5.33 - Alert resolved hien thi dung khi filter Resolved")
    public void TC5_33_ResolvedAlertAppearsInResolvedFilter() {
        // Bước 1: Resolve ALT-1001 trong localStorage
        System.out.println("TC5.33 Bước 1 - Resolve ALT-1001 trong localStorage...");
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "try{var d=JSON.parse(localStorage.getItem('evc-alerts-data-v1')||'[]');" +
            "d=d.map(function(a){return a.id==='ALT-1001'?Object.assign({},a,{status:'resolved'}):a;});" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));}catch(e){}");

        // Bước 2: Mở alerts.html
        System.out.println("TC5.33 Bước 2 - Mở alerts.html...");
        alertPage.navigateToAlertsPage();
        alertPage.waitAlertListLoaded();

        // Bước 3: Reset filter
        System.out.println("TC5.33 Bước 3 - Reset filter...");
        alertPage.resetFilters();

        // Bước 4: Apply filter Status = resolved
        System.out.println("TC5.33 Bước 4 - Apply filter Resolved...");
        alertPage.applyStatusFilter("resolved");

        // Bước 5: Chờ ALT-1001 xuất hiện và tất cả rows là Resolved
        System.out.println("TC5.33 Bước 5 - Chờ ALT-1001 xuất hiện...");
        alertPage.waitUntilRowAppears("ALT-1001");
        alertPage.waitUntilAllVisibleRowsHaveStatus("Resolved");

        // Bước 6: Kiểm tra
        List<AlertRow> rows = alertPage.getAlertRows();
        System.out.println("TC5.33 Bước 6 - Số rows sau filter Resolved: " + rows.size());
        for (AlertRow r : rows) {
            System.out.println("  Row: " + r);
        }

        Assert.assertTrue(rows.size() > 0,
            "TC5.33 FAIL: Không có alert nào trong filter Resolved");

        // Assert ALT-1001 xuất hiện
        boolean alt1001Found = rows.stream()
            .anyMatch(r -> r.alertId.equals("ALT-1001") || r.fullText.contains("ALT-1001"));
        Assert.assertTrue(alt1001Found,
            "TC5.33 FAIL: ALT-1001 không xuất hiện trong filter Resolved. Rows: " + alertPage.getAllRowTexts());

        // Assert tất cả rows đều là Resolved
        boolean allResolved = rows.stream()
            .allMatch(r -> r.status.equalsIgnoreCase("Resolved") || r.fullText.contains("Resolved"));

        if (!allResolved) {
            StringBuilder bugMsg = new StringBuilder(
                "TC5.33 BUG UI: Filter Resolved vẫn hiển thị row Unresolved. Visible rows:\n");
            for (AlertRow r : rows) {
                bugMsg.append("  - ").append(r.alertId).append(" | status=").append(r.status).append("\n");
            }
            Assert.fail(bugMsg.toString());
        }

        System.out.println("TC5.33 PASS - " + rows.size() + " rows đều là Resolved, ALT-1001 có mặt");
    }

    // =========================================================
    /**
     * TC5.34 - Hệ thống xử lý đúng khi id không tồn tại
     */
    @Test(description = "TC5.34 - He thong xu ly dung khi id khong ton tai")
    public void TC5_34_InvalidAlertIdShowsNotFound() {
        Constant.WEBDRIVER.navigate().to(DETAIL_BASE + "?id=INVALID-99999");
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(d -> ((JavascriptExecutor) d).executeScript("return document.readyState").equals("complete"));
        try { Thread.sleep(1500); } catch (Exception ignored) {}
        WebElement notFound = Constant.WEBDRIVER.findElement(By.id("notFoundState"));
        String cls = notFound.getAttribute("class");
        String pageText = alertPage.getPageText();
        System.out.println("TC5.34 notFoundState class='" + cls + "'");
        Assert.assertTrue(!cls.contains("hidden") || pageText.toLowerCase().contains("not found"),
            "TC5.34 FAIL: Không hiển thị 'not found' khi id không tồn tại");
    }

    // =========================================================
    /**
     * TC5.35 - Frontend hiển thị lỗi khi không tải được alert detail
     */
    @Test(description = "TC5.35 - FE hien thi loi khi khong tai duoc alert detail")
    public void TC5_35_MissingAlertIdShowsErrorState() {
        Constant.WEBDRIVER.navigate().to(DETAIL_BASE);
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(d -> ((JavascriptExecutor) d).executeScript("return document.readyState").equals("complete"));
        try { Thread.sleep(1500); } catch (Exception ignored) {}
        WebElement notFound = Constant.WEBDRIVER.findElement(By.id("notFoundState"));
        String cls = notFound.getAttribute("class");
        String pageText = alertPage.getPageText();
        System.out.println("TC5.35 notFoundState class='" + cls + "'");
        Assert.assertTrue(!cls.contains("hidden") || pageText.toLowerCase().contains("not found")
            || pageText.toLowerCase().contains("invalid"),
            "TC5.35 FAIL: FE không hiển thị trạng thái lỗi khi thiếu alert id");
    }
}
