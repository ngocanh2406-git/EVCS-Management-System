package testcases;

import Constant.Constant;
import PageObjects.AlertPage;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * TC5.01 - TC5.06: Alert Storage & Badge
 */
public class AlertStorageTest extends BaseTest {

    private AlertPage alertPage;

    private static final String TEST_ALERT_ID    = "ALT-TEST-001";
    private static final String TEST_ERROR_TYPE  = "Connection Lost";
    private static final String TEST_STATION     = "Station 1";
    private static final String TEST_SEVERITY    = "critical";
    private static final String TEST_STATUS      = "open";

    @BeforeMethod(alwaysRun = true)
    public void setup() {
        alertPage = new AlertPage();
        alertPage.navigateToStationPage();
        seedAlerts();
    }

    private void seedAlerts() {
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "localStorage.removeItem('evc-alerts-data-v1');" +
            "var d=[" +
            "{id:'ALT-1001',type:'Connection Lost',stationName:'Station 1',occurredAt:'2026-04-08T08:15:00',severity:'critical',status:'open',description:'Station connection lost',suggestion:'Check network',logs:[]}," +
            "{id:'ALT-1002',type:'Charger Overheating',stationName:'Station 3',occurredAt:'2026-04-08T09:40:00',severity:'critical',status:'open',description:'Temperature exceeded',suggestion:'Check cooling',logs:[]}," +
            "{id:'ALT-1003',type:'Charging Port Error',stationName:'Station 2',occurredAt:'2026-04-08T10:05:00',severity:'medium',status:'open',description:'Port error E-24',suggestion:'Reset port',logs:[]}," +
            "{id:'ALT-1004',type:'Abnormal Current',stationName:'Station 4',occurredAt:'2026-04-07T15:20:00',severity:'medium',status:'resolved',description:'Current fluctuation',suggestion:'Monitor supply',logs:[]}," +
            "{id:'ALT-1005',type:'Scheduled Maintenance Reminder',stationName:'Station 5',occurredAt:'2026-04-06T11:30:00',severity:'low',status:'resolved',description:'Maintenance due',suggestion:'Schedule inspection',logs:[]}" +
            "];" +
            "localStorage.setItem('evc-alerts-data-v1',JSON.stringify(d));"
        );
    }

    @Test(description = "TC5.01 - Tao canh bao moi thanh cong")
    public void TC5_01_CreateAlertSuccess() {
        alertPage.addAlertToLocalStorage(TEST_ALERT_ID, TEST_ERROR_TYPE, TEST_STATION, TEST_SEVERITY, TEST_STATUS);
        String stored = alertPage.getAlertsFromLocalStorage();
        Assert.assertTrue(stored.contains(TEST_ALERT_ID), "TC5.01 FAIL: Alert khong duoc luu");
    }

    @Test(description = "TC5.02 - Alert luu vao storage voi dung du lieu")
    public void TC5_02_AlertSavedWithCorrectData() {
        alertPage.addAlertToLocalStorage(TEST_ALERT_ID, TEST_ERROR_TYPE, TEST_STATION, TEST_SEVERITY, TEST_STATUS);
        String stored = alertPage.getAlertsFromLocalStorage();
        Assert.assertTrue(stored.contains(TEST_ALERT_ID),    "TC5.02 FAIL: Khong co id");
        Assert.assertTrue(stored.contains(TEST_ERROR_TYPE),  "TC5.02 FAIL: Khong co type");
        Assert.assertTrue(stored.contains(TEST_STATION),     "TC5.02 FAIL: Khong co stationName");
        Assert.assertTrue(stored.contains(TEST_SEVERITY),    "TC5.02 FAIL: Khong co severity");
        Assert.assertTrue(stored.contains(TEST_STATUS),      "TC5.02 FAIL: Khong co status");
    }

    @Test(description = "TC5.03 - Alert moi xuat hien trong danh sach")
    public void TC5_03_NewAlertAppearsInList() {
        alertPage.addAlertToLocalStorage(TEST_ALERT_ID, TEST_ERROR_TYPE, TEST_STATION, TEST_SEVERITY, TEST_STATUS);
        String stored = alertPage.getAlertsFromLocalStorage();
        Assert.assertFalse(stored.isEmpty(), "TC5.03 FAIL: Danh sach rong");
        Assert.assertTrue(stored.contains(TEST_ALERT_ID), "TC5.03 FAIL: Alert moi khong co trong list");
    }

    @Test(description = "TC5.04 - Tra dung thong tin alert moi tao")
    public void TC5_04_AlertHasCorrectInfo() {
        alertPage.addAlertToLocalStorage(TEST_ALERT_ID, TEST_ERROR_TYPE, TEST_STATION, TEST_SEVERITY, TEST_STATUS);
        String stored = alertPage.getAlertsFromLocalStorage();
        Assert.assertTrue(stored.contains(TEST_ERROR_TYPE), "TC5.04 FAIL: Khong co errorType");
        Assert.assertTrue(stored.contains(TEST_STATION),    "TC5.04 FAIL: Khong co stationName");
        Assert.assertTrue(stored.contains(TEST_SEVERITY),   "TC5.04 FAIL: Khong co severity");
        Assert.assertTrue(stored.contains(TEST_STATUS),     "TC5.04 FAIL: Khong co status");
        Assert.assertTrue(stored.matches("(?s).*\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}.*"),
            "TC5.04 FAIL: Khong co timestamp ISO format");
    }

    @Test(description = "TC5.05 - Danh sach alert dung thu tu moi nhat truoc")
    public void TC5_05_AlertListOrderedByTimeDesc() throws Exception {
        alertPage.addAlertToLocalStorage("ALT-ORDER-001", "Connection Lost",    "Station 1", "critical", "open");
        Thread.sleep(100);
        alertPage.addAlertToLocalStorage("ALT-ORDER-002", "Charger Overheating","Station 2", "medium",   "open");
        String stored = alertPage.getAlertsFromLocalStorage();
        int pos1 = stored.indexOf("ALT-ORDER-001");
        int pos2 = stored.indexOf("ALT-ORDER-002");
        Assert.assertTrue(pos2 < pos1, "TC5.05 FAIL: Alert moi nhat khong o truoc. pos2=" + pos2 + " pos1=" + pos1);
    }

    @Test(description = "TC5.06 - Badge chuong tang khi co alert moi")
    public void TC5_06_BellBadgeIncreasesOnNewAlert() {
        int before = alertPage.getOpenAlertsCountFromStorage();
        alertPage.addAlertToLocalStorage("ALT-BADGE-" + System.currentTimeMillis(),
            "Connection Lost", "Station 1", "critical", "open");
        int after = alertPage.getOpenAlertsCountFromStorage();
        Assert.assertEquals(after, before + 1, "TC5.06 FAIL: So open alert khong tang. Truoc=" + before + " Sau=" + after);
    }

    @Test(description = "TC5.07 - Badge chuong = 0 khi khong co unresolved [KNOWN FAIL R1]")
    public void TC5_07_BellBadgeZeroWhenNoUnresolved() {
        alertPage.refreshStation();
        int count = alertPage.getBellBadgeCount();
        Assert.assertTrue(alertPage.isBellBadgeZeroOrHidden(),
            "TC5.07 FAIL: Badge van hien thi so " + count + " [Known issue R1]");
    }
}
