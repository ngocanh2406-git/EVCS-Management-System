package testcases;

import Constant.Constant;
import PageObjects.PolePage;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * CAP NHAT TRU SAC (UPDATE POLE): TC2.14 -> TC2.18
 *
 *   TC2.14 - Hien thi thong tin hien tai khi mo form Edit
 *   TC2.15 - Cap nhat tru sac thanh cong
 *   TC2.16 - Huy cap nhat
 *   TC2.17 - Khong cho luu khi bo trong du lieu
 *   TC2.18 - Khong cho luu khi du lieu khong hop le
 */
public class UpdatePoleTest extends BaseTest {

    private PolePage polePage;

    private static final String VALID_MANUFACTURER = Constant.POLE_MANUFACTURER_VALID;
    private static final String VALID_MODEL        = Constant.POLE_MODEL_VALID;
    private static final String VALID_CONNECTOR    = Constant.POLE_CONNECTOR_2;

    @BeforeMethod(alwaysRun = true)
    public void openPolePage() {
        polePage = new PolePage();
        polePage.acceptAlertIfPresent();
        homePage.openPole();
        polePage.waitForPolePageReady();
        polePage.waitPoleTableLoaded();
        System.out.println("[BeforeMethod] Trang Pole da load xong. Row count: " + polePage.getTableRowCount());
    }

    // =========================================================
    /**
     * TC2.14 - Hien thi thong tin hien tai khi mo form Edit
     *
     * Buoc 1: Truy cap trang Pole Management
     * Buoc 2: Chon nut "Edit" o mot tru sac
     * Expected: He thong hien thi man hinh chinh sua voi day du thong tin da luu
     */
    @Test(description = "TC2.14 - Hien thi thong tin hien tai khi mo form Edit")
    public void TC2_14_EditFormShowsCurrentData() {
        System.out.println("\n========== TC2.14: Mo form Edit kiem tra du lieu hien tai ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.14 SKIP: Bang trong, khong co tru de edit");
        }

        // Ghi nhan ten tru dau tien tu bang
        String nameInTable = polePage.getFirstPoleNameInTable();
        System.out.println("TC2.14 Ten tru trong bang: '" + nameInTable + "'");

        // Buoc 2: Click Edit tru dau tien
        polePage.clickEditFirstPole();

        // Verify: form mo
        Assert.assertTrue(polePage.isCreateFormDisplayed(),
            "TC2.14 FAIL: Form Edit khong mo");

        // Verify: field Pole Name da duoc dien san
        String nameInForm = polePage.getPoleNameFieldValue();
        System.out.println("TC2.14 Ten trong form: '" + nameInForm + "'");
        Assert.assertFalse(nameInForm.isEmpty(),
            "TC2.14 FAIL: Field Pole Name trong form Edit bi trong");

        // Verify: ten trong form khop voi ten trong bang
        if (!nameInTable.isEmpty()) {
            Assert.assertEquals(nameInForm, nameInTable,
                "TC2.14 FAIL: Ten trong form '" + nameInForm
                + "' khong khop voi ten trong bang '" + nameInTable + "'");
        }

        System.out.println("TC2.14 PASS: Form Edit hien thi dung thong tin hien tai.");
        System.out.println("========== TC2.14: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.15 - Cap nhat tru sac thanh cong
     *
     * Buoc 1: Chon nut "Edit" cua mot tru sac
     * Buoc 2: Chinh sua thong tin hop le
     * Buoc 3: Nhan "Save/Update"
     * Expected: He thong luu thanh cong va hien thi thong bao thanh cong
     */
    @Test(description = "TC2.15 - Cap nhat tru sac thanh cong")
    public void TC2_15_UpdatePoleSuccessfully() {
        System.out.println("\n========== TC2.15: Cap nhat tru sac thanh cong ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.15 SKIP: Bang trong");
        }

        // Buoc 1: Click Edit
        polePage.clickEditFirstPole();
        Assert.assertTrue(polePage.isCreateFormDisplayed(), "TC2.15 SETUP: Form Edit khong mo");

        // Buoc 2: Chinh sua ten
        String updatedName = "Updated_" + System.currentTimeMillis();
        polePage.enterPoleName(updatedName);
        polePage.enterManufacturer(VALID_MANUFACTURER);
        polePage.enterModel(VALID_MODEL);
        polePage.selectStationByIndex(1);
        polePage.selectConnectorList(VALID_CONNECTOR);

        // Buoc 3: Nhan Save/Update
        polePage.clickSave();
        String result = polePage.getAlertTextAndAccept();
        System.out.println("TC2.15 Update result: '" + result + "'");

        // Verify: thong bao thanh cong
        Assert.assertTrue(
            result.toLowerCase().contains("success") ||
            result.toLowerCase().contains("updated") ||
            result.toLowerCase().contains("cap nhat") ||
            result.toLowerCase().contains("thanh cong"),
            "TC2.15 FAIL: Khong co thong bao thanh cong. Result='" + result + "'");
        System.out.println("TC2.15 PASS: Thong bao cap nhat thanh cong = '" + result + "'");

        // Reload va kiem tra ten moi trong bang
        polePage.navigateToPolePage();
        Assert.assertTrue(polePage.waitForPoleInTable(updatedName),
            "TC2.15 FAIL: Ten moi '" + updatedName + "' khong xuat hien trong bang");
        System.out.println("TC2.15 PASS: Ten moi '" + updatedName + "' da xuat hien trong bang.");
        System.out.println("========== TC2.15: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.16 - Huy cap nhat
     *
     * Buoc 1: Chon nut "Edit" cua mot tru sac
     * Buoc 2: Nhan "Cancel"
     * Expected: He thong quay lai man hinh danh sach, khong luu du lieu
     */
    @Test(description = "TC2.16 - Huy cap nhat tru sac")
    public void TC2_16_CancelUpdatePole() {
        System.out.println("\n========== TC2.16: Huy cap nhat ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.16 SKIP: Bang trong");
        }

        // Ghi nhan ten goc
        String originalName = polePage.getFirstPoleNameInTable();
        System.out.println("TC2.16 Ten goc: '" + originalName + "'");

        // Buoc 1: Click Edit
        polePage.clickEditFirstPole();
        Assert.assertTrue(polePage.isCreateFormDisplayed(), "TC2.16 SETUP: Form Edit khong mo");

        // Thay doi ten nhung se cancel
        polePage.enterPoleName("SHOULD_NOT_SAVE_" + System.currentTimeMillis());

        // Buoc 2: Click Cancel
        polePage.clickCancel();

        // Verify 1: Form da dong
        Assert.assertFalse(polePage.isCreateFormDisplayed(),
            "TC2.16 FAIL: Form van hien thi sau khi nhan Cancel");
        System.out.println("TC2.16 PASS: Form da dong.");

        // Verify 2: Ten goc van con trong bang
        if (!originalName.isEmpty()) {
            Assert.assertTrue(polePage.isPoleInTable(originalName),
                "TC2.16 FAIL: Ten goc '" + originalName + "' khong con trong bang");
            System.out.println("TC2.16 PASS: Ten goc van con trong bang.");
        }
        System.out.println("========== TC2.16: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.17 - Khong cho luu khi bo trong du lieu
     *
     * Buoc 1: Chon nut "Edit"
     * Buoc 2: Xoa du lieu cac truong bat buoc
     * Buoc 3: Nhan "Save/Update"
     * Expected: Hien thi loi bat buoc nhap va khong cho luu
     */
    @Test(description = "TC2.17 - Khong cho luu khi bo trong du lieu khi cap nhat")
    public void TC2_17_UpdatePoleWithEmptyFields() {
        System.out.println("\n========== TC2.17: Cap nhat voi truong trong ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.17 SKIP: Bang trong");
        }

        // Buoc 1: Click Edit
        polePage.clickEditFirstPole();
        Assert.assertTrue(polePage.isCreateFormDisplayed(), "TC2.17 SETUP: Form Edit khong mo");

        // Buoc 2: Xoa cac field bat buoc
        polePage.clearPoleName();
        polePage.clearManufacturer();
        polePage.clearModel();

        // Buoc 3: Click Save/Update
        polePage.clickSave();
        polePage.acceptAlertIfPresent();

        // Verify: loi hien thi HOAC form van con mo
        String errorText = polePage.waitForFormError();
        boolean formStillOpen = polePage.isCreateFormDisplayed();
        System.out.println("TC2.17 errorText='" + errorText + "', formStillOpen=" + formStillOpen);

        Assert.assertTrue(!errorText.isEmpty() || formStillOpen,
            "TC2.17 FAIL: He thong cho luu khi bo trong truong bat buoc");
        System.out.println("TC2.17 PASS: He thong khong cho luu khi bo trong.");
        System.out.println("========== TC2.17: PASSED ==========\n");
    }

    // =========================================================
    /**
     * TC2.18 - Khong cho luu khi du lieu khong hop le
     *
     * Buoc 1: Chon nut "Edit"
     * Buoc 2: Nhap du lieu sai dinh dang (@ ! # $...)
     * Buoc 3: Nhan "Save/Update"
     * Expected: Hien thi loi du lieu khong hop le
     */
    @Test(description = "TC2.18 - Khong cho luu khi du lieu khong hop le khi cap nhat")
    public void TC2_18_UpdatePoleWithInvalidData() {
        System.out.println("\n========== TC2.18: Cap nhat voi du lieu khong hop le ==========");

        if (polePage.getTableRowCount() == 0) {
            throw new SkipException("TC2.18 SKIP: Bang trong");
        }

        // Buoc 1: Click Edit
        polePage.clickEditFirstPole();
        Assert.assertTrue(polePage.isCreateFormDisplayed(), "TC2.18 SETUP: Form Edit khong mo");

        // Buoc 2: Nhap du lieu khong hop le
        String invalidName = "@#$%^&*()!";
        polePage.enterPoleName(invalidName);
        polePage.enterManufacturer("!!!INVALID!!!");
        polePage.enterModel("???");

        // Buoc 3: Click Save/Update
        polePage.clickSave();
        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}

        // Verify: he thong phan hoi (loi HOAC form dong)
        String errorText = polePage.getFormErrorText();
        boolean formStillOpen = polePage.isCreateFormDisplayed();
        boolean hasAlert = polePage.isAlertPresent();
        System.out.println("TC2.18 errorText='" + errorText + "', formStillOpen=" + formStillOpen
            + ", hasAlert=" + hasAlert);

        if (hasAlert) {
            String alertText = polePage.getAlertTextAndAccept();
            System.out.println("TC2.18 Alert: '" + alertText + "'");
            // Neu alert la success thi kiem tra du lieu khong hop le khong duoc luu
            if (alertText.toLowerCase().contains("success") || alertText.toLowerCase().contains("updated")) {
                polePage.navigateToPolePage();
                boolean invalidInTable = polePage.isPoleInTable(invalidName);
                System.out.println("TC2.18 Du lieu khong hop le trong bang: " + invalidInTable);
                Assert.assertFalse(invalidInTable,
                    "TC2.18 FAIL: He thong cho luu du lieu khong hop le '" + invalidName + "'");
            }
            // Alert loi = PASS
        } else {
            // Khong co alert → form van mo hoac co loi = PASS
            Assert.assertTrue(!errorText.isEmpty() || formStillOpen,
                "TC2.18 FAIL: He thong khong phan hoi khi nhap du lieu khong hop le");
        }

        System.out.println("TC2.18 PASS: He thong xu ly du lieu khong hop le dung.");
        System.out.println("========== TC2.18: PASSED ==========\n");
    }
}
