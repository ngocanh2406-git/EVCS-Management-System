package testcases;

import Common.DriverFactory;
import Constant.Constant;
import PageObjects.HomePage;
import listeners.TestListener;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;

/**
 * BaseTest: Setup/Teardown chung cho tất cả test class.
 * @Listeners đảm bảo TestListener chạy dù chạy từ IntelliJ hay Maven.
 */
@Listeners(TestListener.class)
public class BaseTest {

    protected HomePage homePage;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        Constant.WEBDRIVER = DriverFactory.initChromeDriver();
        homePage = new HomePage();
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (Constant.WEBDRIVER != null) {
            Constant.WEBDRIVER.quit();
            Constant.WEBDRIVER = null;
        }
    }
}
