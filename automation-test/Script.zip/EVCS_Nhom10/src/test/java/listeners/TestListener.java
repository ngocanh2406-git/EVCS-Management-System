package listeners;

import Common.ScreenshotHelper;
import Constant.Constant;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

/**
 * TestNG Listener:
 * - onStart      : xóa screenshot cũ trước khi suite chạy
 * - onTestFailure: tự động chụp screenshot khi FAIL
 * - onFinish     : copy HTML report vào Evidence/html-report/
 */
public class TestListener implements ITestListener {

    private static final String SCREENSHOT_DIR      = "screenshots";
    private static final String EVIDENCE_SS_DIR     = "Evidence/screenshots";
    private static final String EVIDENCE_REPORT_DIR = "Evidence/html-report";

    // ===== Chạy 1 lần khi bắt đầu suite =====
    @Override
    public void onStart(ITestContext context) {
        System.out.println("\n========================================");
        System.out.println("Suite bat dau: " + context.getName());
        System.out.println("Xoa screenshot cu...");
        clearPngFiles(SCREENSHOT_DIR);
        clearPngFiles(EVIDENCE_SS_DIR);
        System.out.println("========================================\n");
    }

    // ===== Tự động chụp screenshot khi FAIL =====
    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println("[FAIL] " + result.getName());
        if (Constant.WEBDRIVER != null) {
            ScreenshotHelper.takeScreenshot(result.getName());
            ScreenshotHelper.takeEvidenceScreenshot(result.getName());
        }
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("[PASS] " + result.getName());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("[SKIP] " + result.getName());
    }

    // ===== Chạy 1 lần khi suite kết thúc =====
    @Override
    public void onFinish(ITestContext context) {
        System.out.println("\n========================================");
        System.out.println("Suite ket thuc: " + context.getName());
        System.out.println("Pass : " + context.getPassedTests().size());
        System.out.println("Fail : " + context.getFailedTests().size());
        System.out.println("Skip : " + context.getSkippedTests().size());
        System.out.println("========================================");

        // Copy HTML report vào Evidence/html-report/
        copyHtmlReport();
    }

    // ===================================================================
    //  HELPERS
    // ===================================================================

    /** Xóa toàn bộ .png trong thư mục (tạo thư mục nếu chưa có) */
    private void clearPngFiles(String dirPath) {
        try {
            File dir = new File(dirPath);
            if (!dir.exists()) { dir.mkdirs(); return; }
            File[] files = dir.listFiles((d, name) -> name.endsWith(".png"));
            if (files != null) {
                for (File f : files) f.delete();
                System.out.println("  Xoa " + files.length + " file trong " + dirPath);
            }
        } catch (Exception e) {
            System.err.println("  Loi xoa screenshot: " + e.getMessage());
        }
    }

    /** Copy toàn bộ thư mục HTML report vào Evidence/html-report/ */
    private void copyHtmlReport() {
        // Lay project root tuyet doi - tranh van de relative path khi Maven doi working dir
        // user.dir khi Maven chay = project root (khong phai target/)
        String projectRoot = System.getProperty("user.dir");
        System.out.println("[Report] Project root: " + projectRoot);

        // Tim thu muc report theo thu tu uu tien
        String[] candidates = {
            projectRoot + File.separator + "target" + File.separator + "surefire-reports" + File.separator + "html",
            projectRoot + File.separator + "test-output" + File.separator + "html"
        };

        Path source = null;
        for (String candidate : candidates) {
            Path p = Paths.get(candidate);
            if (Files.exists(p) && new File(candidate).isDirectory()) {
                source = p;
                System.out.println("[Report] Tim thay report tai: " + p.toAbsolutePath());
                break;
            }
        }

        if (source == null) {
            System.out.println("[Report] Chua co HTML report. Da tim tai:");
            for (String c : candidates) System.out.println("  - " + c);
            return;
        }

        final Path finalSource = source;
        final Path target = Paths.get(projectRoot + File.separator + EVIDENCE_REPORT_DIR);

        try {
            if (Files.exists(target)) {
                deleteDirectory(target);
            }
            Files.createDirectories(target);

            Files.walkFileTree(finalSource, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                        throws IOException {
                    Path dest = target.resolve(finalSource.relativize(dir));
                    Files.createDirectories(dest);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                        throws IOException {
                    Path dest = target.resolve(finalSource.relativize(file));
                    Files.copy(file, dest, StandardCopyOption.REPLACE_EXISTING);
                    return FileVisitResult.CONTINUE;
                }
            });

            System.out.println("[Report] HTML report da copy vao: " + target.toAbsolutePath());
            System.out.println("[Report] Mo file: " + target.toAbsolutePath() + File.separator + "index.html");

        } catch (IOException e) {
            System.err.println("[Report] Loi copy HTML report: " + e.getMessage());
        }
    }

    /** Xóa toàn bộ thư mục và nội dung bên trong */
    private void deleteDirectory(Path dir) throws IOException {
        Files.walkFileTree(dir, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path d, IOException exc)
                    throws IOException {
                Files.delete(d);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
