package Constant;

import org.openqa.selenium.WebDriver;

public class Constant {

    public static WebDriver WEBDRIVER;

    // ===== URLs =====
    public static final String BASE_URL        = "https://evsc-production.up.railway.app";
    public static final String STATION_URL     = BASE_URL + "/station.html";
    public static final String POLE_URL        = BASE_URL + "/poles.html";
    public static final String MONITOR_URL     = BASE_URL + "/monitor.html";
    public static final String HISTORY_URL     = BASE_URL + "/history.html";
    public static final String ALERTS_URL      = BASE_URL + "/alerts.html";

    // ===== Timeouts =====
    public static final int SHORT_TIMEOUT      = 10;
    public static final int MEDIUM_TIMEOUT     = 15;

    // ===== Test Data - Station =====
    public static final String STATION_ADDR_VALID   = "123 Nguyen Van Linh, Q7";
    public static final String STATION_LAT_VALID    = "10.7285";
    public static final String STATION_LNG_VALID    = "106.7218";

    // Station có ongoing session (từ DB: ST001 có PL002 ongoing)
    // Dùng cho TC1.29 test không cho xóa khi có session đang chạy
    public static final String STATION_WITH_ONGOING_SESSION = "ST001";

    // Station không có ongoing session (từ DB: ST003, ST004, ST008, ST010 inactive/maintenance)
    // Dùng cho TC1.26 test xóa thành công (tạo mới rồi xóa)
    public static final String STATION_STATUS_ACTIVE    = "Active";
    public static final String STATION_STATUS_INACTIVE  = "Inactive";

    /** Sinh tên trạm unique mỗi lần chạy để tránh trùng */
    public static String uniqueStationName() {
        return "Auto_" + System.currentTimeMillis();
    }

    // GPS invalid
    public static final String GPS_TEXT_INVALID     = "abcxyz";
    public static final String GPS_LAT_OUT_OF_RANGE = "999";
    public static final String GPS_LNG_OUT_OF_RANGE = "999";

    // ===== Test Data - Pole =====
    public static final String POLE_MANUFACTURER_VALID = "ABB";
    public static final String POLE_MODEL_VALID        = "Terra 54";
    public static final String POLE_CONNECTOR_1        = "1 connector";
    public static final String POLE_CONNECTOR_2        = "2 connectors";

    // ===== Screenshot folder =====
    public static final String SCREENSHOT_DIR  = "screenshots/";

    // ===== Evidence folder =====
    public static final String EVIDENCE_DIR    = "Evidence/";
}
