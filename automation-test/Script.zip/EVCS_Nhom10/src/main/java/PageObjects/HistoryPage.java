package PageObjects;

import org.openqa.selenium.By;

public class HistoryPage extends GeneralPage {

    private final By lblTitle = By.xpath("//*[text()='Station Usage History']");
    private final By btnExport = By.xpath("//*[contains(text(),'Export')]");

    public boolean isHistoryVisible() {
        return isDisplayed(lblTitle);
    }

    public void clickExport() {
        click(btnExport);
    }
}