package PageObjects;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * AlertPage - Page Object cho Alert Management
 * URLs:
 *   - alerts.html       : danh sách alert
 *   - alert-detail.html : chi tiết alert
 *   - station.html      : có bell badge
 *
 * Alert data lưu trong localStorage key "evc-alerts-data-v1"
 * Bảng: #alertsTableBody — cột: Error Type | Station | Timestamp | Severity | Status
 */
public class AlertPage extends GeneralPage {

    // ===================================================================
    //  NAVIGATION
    // ===================================================================

    /** Mở trang station.html (để có đúng domain cho localStorage) */
    public void navigateToStationPage() {
        Constant.WEBDRIVER.navigate().to(Constant.STATION_URL);
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(driver -> ((JavascriptExecutor) driver)
                .executeScript("return document.readyState").equals("complete"));
    }

    /** Mở trang alerts.html và chờ bảng load */
    public void navigateToAlertsPage() {
        Constant.WEBDRIVER.navigate().to(Constant.ALERTS_URL);
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(driver -> ((JavascriptExecutor) driver)
                .executeScript("return document.readyState").equals("complete"));
        // Chờ bảng có ít nhất 1 row HOẶC empty state xuất hiện
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    // Có row trong bảng
                    java.util.List<org.openqa.selenium.WebElement> rows =
                        driver.findElements(By.cssSelector("#alertsTableBody tr"));
                    if (!rows.isEmpty()) return true;
                    // Hoặc trang đã render xong (có text Alert)
                    String body = driver.findElement(By.tagName("body")).getText();
                    return body.contains("Alert") || body.contains("Error Type") || body.contains("No alerts");
                });
        } catch (Exception ignored) {}
    }

    /** Reload station.html */
    public void refreshStation() {
        navigateToStationPage();
    }

    // ===================================================================
    //  LOCALSTORAGE OPERATIONS
    // ===================================================================

    /**
     * Thêm alert mới vào localStorage.
     * Alert được unshift (thêm vào đầu mảng) để mới nhất ở trước.
     */
    public void addAlertToLocalStorage(String id, String type, String stationName,
                                        String severity, String status) {
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "try {" +
            "  var data = JSON.parse(localStorage.getItem('evc-alerts-data-v1') || '[]');" +
            "  var newAlert = {" +
            "    id: arguments[0]," +
            "    type: arguments[1]," +
            "    stationName: arguments[2]," +
            "    occurredAt: new Date().toISOString()," +
            "    severity: arguments[3]," +
            "    status: arguments[4]," +
            "    description: 'Test alert description'," +
            "    suggestion: 'Test suggestion'," +
            "    logs: []" +
            "  };" +
            "  data.unshift(newAlert);" +
            "  localStorage.setItem('evc-alerts-data-v1', JSON.stringify(data));" +
            "} catch(e) { console.error(e); }",
            id, type, stationName, severity, status
        );
    }

    /** Lấy toàn bộ alert JSON từ localStorage */
    public String getAlertsFromLocalStorage() {
        Object result = ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "return localStorage.getItem('evc-alerts-data-v1') || '[]';"
        );
        return result != null ? result.toString() : "[]";
    }

    /** Đếm số alert có status = "open" trong localStorage */
    public int getOpenAlertsCountFromStorage() {
        Object result = ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "try {" +
            "  var data = JSON.parse(localStorage.getItem('evc-alerts-data-v1') || '[]');" +
            "  return data.filter(function(a){ return a.status === 'open'; }).length;" +
            "} catch(e) { return 0; }"
        );
        return result != null ? ((Long) result).intValue() : 0;
    }

    // ===================================================================
    //  BELL BADGE (station.html)
    // ===================================================================

    /**
     * Lấy số hiển thị trên bell badge (.bell-badge).
     * Trả về 0 nếu badge ẩn hoặc không có.
     */
    public int getBellBadgeCount() {
        try {
            List<WebElement> badges = Constant.WEBDRIVER.findElements(By.cssSelector(".bell-badge"));
            if (badges.isEmpty()) return 0;
            WebElement badge = badges.get(0);
            if (!badge.isDisplayed()) return 0;
            String text = badge.getText().trim();
            if (text.isEmpty()) return 0;
            return Integer.parseInt(text);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Kiểm tra bell badge = 0 hoặc ẩn.
     */
    public boolean isBellBadgeZeroOrHidden() {
        try {
            List<WebElement> badges = Constant.WEBDRIVER.findElements(By.cssSelector(".bell-badge"));
            if (badges.isEmpty()) return true;
            WebElement badge = badges.get(0);
            if (!badge.isDisplayed()) return true;
            String text = badge.getText().trim();
            return text.isEmpty() || "0".equals(text);
        } catch (Exception e) {
            return true;
        }
    }

    // ===================================================================
    //  ALERTS PAGE (alerts.html)
    // ===================================================================

    /** Kiểm tra đang ở trang alerts.html */
    public boolean isAlertsPageLoaded() {
        String url = Constant.WEBDRIVER.getCurrentUrl();
        String body = Constant.WEBDRIVER.findElement(By.tagName("body")).getText();
        return url.contains("alerts") || body.contains("Alert") || body.contains("Error Type");
    }

    /** Đếm số row trong bảng #alertsTableBody */
    public int getAlertRowCount() {
        try {
            List<WebElement> rows = Constant.WEBDRIVER.findElements(
                By.cssSelector("#alertsTableBody tr")
            );
            return rows.size();
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Chờ bảng alert load xong — có ít nhất 1 row visible.
     */
    public void waitAlertListLoaded() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    List<WebElement> rows = driver.findElements(By.cssSelector("#alertsTableBody tr"));
                    return !rows.isEmpty();
                });
        } catch (Exception ignored) {}
    }

    /**
     * Model đại diện cho 1 row alert trong bảng.
     * Row text thực tế (từ log):
     *   Connection Lost
     *   ALT-1001
     *   Station 1 08/04/2026, 08:15
     *   Critical
     *   Unresolved
     */
    public static class AlertRow {
        public String errorType  = "";
        public String alertId    = "";
        public String station    = "";
        public String timestamp  = "";
        public String severity   = "";
        public String status     = "";
        public String fullText   = "";

        @Override
        public String toString() {
            return "AlertRow{errorType='" + errorType + "', alertId='" + alertId
                + "', station='" + station + "', timestamp='" + timestamp
                + "', severity='" + severity + "', status='" + status + "'}";
        }
    }

    /**
     * Parse 1 row WebElement thành AlertRow.
     * Row text format (mỗi dòng là 1 phần):
     *   line[0] = Error Type (VD: "Connection Lost")
     *   line[1] = Alert ID   (VD: "ALT-1001")
     *   line[2] = Station + Timestamp (VD: "Station 1 08/04/2026, 08:15")
     *   line[3] = Severity   (VD: "Critical")
     *   line[4] = Status     (VD: "Unresolved")
     */
    private AlertRow parseRow(WebElement row) {
        AlertRow ar = new AlertRow();
        ar.fullText = row.getText().trim();

        // Tách theo newline
        String[] lines = ar.fullText.split("\\n");
        if (lines.length >= 1) ar.errorType = lines[0].trim();
        if (lines.length >= 2) ar.alertId   = lines[1].trim();
        if (lines.length >= 3) {
            // line[2] = "Station 1 08/04/2026, 08:15" — tách station và timestamp
            String line2 = lines[2].trim();
            // Timestamp pattern: dd/MM/yyyy, HH:mm
            java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(\\d{2}/\\d{2}/\\d{4},?\\s*\\d{1,2}:\\d{2})")
                .matcher(line2);
            if (m.find()) {
                ar.timestamp = m.group(1).trim();
                ar.station   = line2.substring(0, m.start()).trim();
            } else {
                ar.station = line2;
            }
        }
        if (lines.length >= 4) ar.severity = lines[3].trim();
        if (lines.length >= 5) ar.status   = lines[4].trim();

        return ar;
    }

    /**
     * Lấy tất cả AlertRow hiện đang visible trong bảng.
     */
    public List<AlertRow> getAlertRows() {
        List<AlertRow> result = new java.util.ArrayList<>();
        try {
            List<WebElement> rows = Constant.WEBDRIVER.findElements(
                By.cssSelector("#alertsTableBody tr")
            );
            for (WebElement row : rows) {
                result.add(parseRow(row));
            }
        } catch (Exception e) {
            System.out.println("[getAlertRows] Lỗi: " + e.getMessage());
        }
        return result;
    }

    /** Lấy AlertRow đầu tiên, hoặc null nếu không có */
    public AlertRow getFirstAlertRow() {
        List<AlertRow> rows = getAlertRows();
        return rows.isEmpty() ? null : rows.get(0);
    }

    /** Kiểm tra có ít nhất 1 row không */
    public boolean hasAnyAlertRow() {
        return !getAlertRows().isEmpty();
    }

    /** Lấy fullText của tất cả rows */
    public List<String> getAllRowTexts() {
        List<String> texts = new java.util.ArrayList<>();
        for (AlertRow r : getAlertRows()) texts.add(r.fullText);
        return texts;
    }

    /**
     * Apply filter status bằng cách thử cả select native và custom dropdown.
     * Trigger change event sau khi chọn.
     * @param statusValue "open" hoặc "resolved"
     */
    public void applyStatusFilter(String statusValue) {
        try {
            // Thử select native trước
            WebElement sel = Constant.WEBDRIVER.findElement(By.id("statusFilter"));
            new org.openqa.selenium.support.ui.Select(sel).selectByValue(statusValue);
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var el=document.getElementById('statusFilter');" +
                "if(el){el.dispatchEvent(new Event('change',{bubbles:true}));" +
                "el.dispatchEvent(new Event('input',{bubbles:true}));}"
            );
        } catch (Exception e) {
            // Fallback: click option text trong custom dropdown
            try {
                String optionText = statusValue.equals("open") ? "Unresolved" : "Resolved";
                WebElement opt = Constant.WEBDRIVER.findElement(
                    By.xpath("//*[@id='statusFilter']//*[contains(text(),'" + optionText + "')]" +
                             " | //option[@value='" + statusValue + "']"));
                opt.click();
            } catch (Exception ignored) {}
        }
        waitFilterApplied();
    }

    /**
     * Chờ tất cả visible rows có status khớp với expectedStatus.
     * @param expectedStatus "Unresolved" hoặc "Resolved"
     */
    public void waitUntilAllVisibleRowsHaveStatus(String expectedStatus) {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    List<AlertRow> rows = getAlertRows();
                    if (rows.isEmpty()) return true; // không có row = filter đã apply
                    return rows.stream().allMatch(r ->
                        r.status.equalsIgnoreCase(expectedStatus)
                        || r.fullText.contains(expectedStatus));
                });
        } catch (Exception ignored) {}
    }

    /**
     * Chờ row có alertId biến mất khỏi bảng.
     */
    public void waitUntilRowDisappears(String alertId) {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    List<WebElement> rows = driver.findElements(
                        By.cssSelector("#alertsTableBody tr[data-alert-id='" + alertId + "']"));
                    return rows.isEmpty();
                });
        } catch (Exception ignored) {}
    }

    /**
     * Chờ row có alertId xuất hiện trong bảng.
     */
    public void waitUntilRowAppears(String alertId) {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    List<WebElement> rows = driver.findElements(
                        By.cssSelector("#alertsTableBody tr[data-alert-id='" + alertId + "']"));
                    return !rows.isEmpty();
                });
        } catch (Exception ignored) {}
    }

    /**
     * Lấy AlertRow theo alertId.
     */
    public AlertRow getAlertRowById(String alertId) {
        try {
            WebElement row = Constant.WEBDRIVER.findElement(
                By.cssSelector("#alertsTableBody tr[data-alert-id='" + alertId + "']"));
            return parseRow(row);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Lấy status của alert theo alertId từ bảng UI.
     */
    public String getAlertStatusById(String alertId) {
        AlertRow row = getAlertRowById(alertId);
        return row != null ? row.status : "";
    }

    /**
     * Mở alert-detail.html?id=alertId.
     * Seed localStorage trước khi mở để đảm bảo data có sẵn.
     */
    public void openAlertById(String alertId) {
        Constant.WEBDRIVER.navigate().to(
            Constant.ALERTS_URL.replace("alerts.html", "alert-detail.html") + "?id=" + alertId);
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(d -> ((JavascriptExecutor) d)
                .executeScript("return document.readyState").equals("complete"));
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(d -> {
                    try { return !d.findElement(By.id("detailTitle")).getText().trim().isEmpty(); }
                    catch (Exception e) { return false; }
                });
        } catch (Exception ignored) {}
    }

    /**
     * Click nút Resolve trên alert-detail.html và chờ status đổi.
     */
    public void markAlertAsResolved() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(org.openqa.selenium.support.ui.ExpectedConditions
                    .elementToBeClickable(By.id("resolveBtn")))
                .click();
            // Chờ status badge đổi thành Resolved
            try {
                new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                    .until(d -> {
                        try {
                            String t = d.findElement(By.id("detailStatusBadge")).getText().trim();
                            return "Resolved".equals(t);
                        } catch (Exception e) { return false; }
                    });
            } catch (Exception ignored) {}
            try { Thread.sleep(500); } catch (Exception ignored) {}
        } catch (Exception e) {
            System.out.println("[markAlertAsResolved] Lỗi: " + e.getMessage());
        }
    }

    /**
     * Kiểm tra alert đã Resolved sau khi reload alerts.html.
     * Mở alerts.html → filter Resolved → tìm alertId trong bảng.
     */
    public boolean isAlertResolvedAfterReload(String alertId) {
        navigateToAlertsPage();
        waitAlertListLoaded();
        applyStatusFilter("resolved");
        waitUntilAllVisibleRowsHaveStatus("Resolved");
        AlertRow row = getAlertRowById(alertId);
        if (row != null) {
            System.out.println("[isAlertResolvedAfterReload] " + alertId + " status='" + row.status + "'");
            return row.status.equalsIgnoreCase("Resolved") || row.fullText.contains("Resolved");
        }
        // Không tìm thấy trong filter Resolved → chưa resolved
        System.out.println("[isAlertResolvedAfterReload] " + alertId + " không tìm thấy trong filter Resolved");
        return false;
    }

    /**
     * Lấy status từ localStorage (optional, chỉ dùng để log).
     * Không dùng để assert chính.
     */
    public String getAlertStatusFromStorageOptional(String alertId) {
        try {
            Object result = ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "try{var d=JSON.parse(localStorage.getItem('evc-alerts-data-v1')||'[]');" +
                "var a=d.find(function(x){return x.id===arguments[0];});" +
                "return a?a.status:'not found';}catch(e){return 'error';}", alertId);
            return result != null ? result.toString() : "null";
        } catch (Exception e) {
            return "error";
        }
    }

    /**
     * Chờ sau khi apply filter — đợi ổn định (không thay đổi trong 500ms).
     */
    public void waitFilterApplied() {
        try { Thread.sleep(800); } catch (Exception ignored) {}
    }

    /**
     * Reset tất cả filter về mặc định.
     * Clear search input + reset severity/status dropdown về All.
     */
    public void resetFilters() {
        try {
            WebElement search = Constant.WEBDRIVER.findElement(By.id("searchInput"));
            search.clear();
            // Trigger input event để web nhận
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var el = document.getElementById('searchInput');" +
                "if (el) { el.value=''; el.dispatchEvent(new Event('input',{bubbles:true})); }"
            );
        } catch (Exception ignored) {}

        try {
            new org.openqa.selenium.support.ui.Select(
                Constant.WEBDRIVER.findElement(By.id("severityFilter"))
            ).selectByIndex(0);
        } catch (Exception ignored) {}

        try {
            new org.openqa.selenium.support.ui.Select(
                Constant.WEBDRIVER.findElement(By.id("statusFilter"))
            ).selectByIndex(0);
        } catch (Exception ignored) {}

        waitFilterApplied();
    }

    /**
     * Lấy text của cell theo cột (0-based) trong row đầu tiên.
     * Cột: 0=Error Type, 1=Station, 2=Timestamp, 3=Severity, 4=Status
     * @deprecated Dùng getFirstAlertRow() thay thế
     */
    public String getFirstRowCellText(int colIndex) {
        AlertRow first = getFirstAlertRow();
        if (first == null) return "";
        switch (colIndex) {
            case 0: return first.errorType;
            case 1: return first.station;
            case 2: return first.timestamp;
            case 3: return first.severity;
            case 4: return first.status;
            default: return first.fullText;
        }
    }

    /** Lấy toàn bộ text của trang hiện tại */
    public String getPageText() {
        try {
            return Constant.WEBDRIVER.findElement(By.tagName("body")).getText();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Kiểm tra có timestamp hợp lệ trong trang không.
     * Format: "dd/MM/yyyy, HH:mm" hoặc ISO format
     */
    public boolean isTimestampInPage() {
        String pageText = getPageText();
        // Kiểm tra format dd/MM/yyyy hoặc yyyy-MM-dd
        return pageText.matches("(?s).*\\d{2}/\\d{2}/\\d{4}.*")
            || pageText.matches("(?s).*\\d{4}-\\d{2}-\\d{2}.*")
            || pageText.matches("(?s).*\\d{2}:\\d{2}.*");
    }

    // ===================================================================
    //  LEGACY METHODS (giữ lại để không break code cũ)
    // ===================================================================

    private final By lblAlertList  = By.xpath("//*[contains(text(),'Alerts') or contains(text(),'Alert')]");
    private final By lblErrorType  = By.xpath("//*[contains(text(),'Type')]");
    private final By lblTime       = By.xpath("//*[contains(text(),'Time')]");
    private final By lblStation    = By.xpath("//*[contains(text(),'Station')]");
    private final By lblSeverity   = By.xpath("//*[contains(text(),'Severity')]");
    private final By btnViewDetail = By.xpath("//*[contains(text(),'Detail')]");
    private final By btnResolve    = By.xpath("//*[contains(text(),'Resolve') or contains(text(),'Fix')]");

    public boolean isAlertListDisplayed()  { return isDisplayed(lblAlertList); }
    public boolean isErrorTypeDisplayed()  { return isDisplayed(lblErrorType); }
    public boolean isTimeDisplayed()       { return isDisplayed(lblTime); }
    public boolean isStationDisplayed()    { return isDisplayed(lblStation); }
    public boolean isSeverityDisplayed()   { return isDisplayed(lblSeverity); }
    public void clickViewDetail()          { click(btnViewDetail); }
    public void clickResolve()             { click(btnResolve); }
}
