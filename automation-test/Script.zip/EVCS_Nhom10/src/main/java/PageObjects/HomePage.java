package PageObjects;

import Constant.Constant;

public class HomePage extends GeneralPage {

    public HomePage open() {
        Constant.WEBDRIVER.navigate().to(Constant.BASE_URL);
        return this;
    }

    public StationPage openStation() {
        Constant.WEBDRIVER.navigate().to(Constant.STATION_URL);
        StationPage page = new StationPage();
        page.waitForStationPageReady();
        return page;
    }

    public PolePage openPole() {
        Constant.WEBDRIVER.navigate().to(Constant.POLE_URL);
        return new PolePage();
    }

    public MonitorPage openMonitor() {
        Constant.WEBDRIVER.navigate().to(Constant.MONITOR_URL);
        return new MonitorPage();
    }

    public HistoryPage openHistory() {
        Constant.WEBDRIVER.navigate().to(Constant.HISTORY_URL);
        return new HistoryPage();
    }
}
