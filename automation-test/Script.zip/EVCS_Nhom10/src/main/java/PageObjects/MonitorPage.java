package PageObjects;

import org.openqa.selenium.By;

public class MonitorPage extends GeneralPage {

    private final By lblOnline = By.xpath("//*[contains(text(),'Online Stations')]");
    private final By lblAlerts = By.xpath("//*[contains(text(),'Alerts')]");

    public boolean isOnlineDisplayed() {
        return isDisplayed(lblOnline);
    }

    public boolean isAlertDisplayed() {
        return isDisplayed(lblAlerts);
    }
}