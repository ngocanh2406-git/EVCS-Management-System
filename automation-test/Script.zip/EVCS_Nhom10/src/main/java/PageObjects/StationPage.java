package PageObjects;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * StationPage - Page Object cho Station Management
 * URL: https://evsc-production.up.railway.app/station.html
 *
 * Input IDs xác nhận từ DevTools Console:
 *   #createStationName  (name="stationName",  placeholder="Input Name")
 *   #createLatitude     (name="latitude",     placeholder="Input Name")
 *   #createLongitude    (name="longitude",    placeholder="Input Name")
 *   #createAddress      (name="address",      placeholder="Find address")
 *   #searchInput        (search box - không dùng trong form)
 *
 * Edit form dùng cùng id hoặc id khác (cần xác nhận thêm).
 * Edit button: button.edit-btn[data-action='edit']
 * Popup xác nhận: SweetAlert2 (.swal2-popup)
 */
public class StationPage extends GeneralPage {

    // ===================================================================
    //  LOCATORS - XÁC NHẬN TỪ DEVTOOLS
    // ===================================================================

    // Header
    private final By btnCreateNew       = By.xpath("//button[normalize-space()='Create new']");

    // Table
    private final By tableRows          = By.cssSelector("table tbody tr");

    // CREATE FORM inputs (id xác nhận từ DevTools)
    private final By inputStationName   = By.id("createStationName");
    private final By inputLatitude      = By.id("createLatitude");
    private final By inputLongitude     = By.id("createLongitude");
    private final By inputAddress       = By.id("createAddress");

    // Station ID field (read-only, auto-generated) - tìm theo vị trí
    private final By inputStationId     = By.xpath(
        "//input[@id='createStationId' or @name='stationId' or @id='stationId']"
    );

    // Form buttons — ID xác nhận từ DevTools
    private final By btnSaveInForm      = By.id("createStationSaveBtn");
    private final By btnCancelInForm    = By.id("createStationCancelBtn");
    private final By btnCloseForm       = By.id("createStationCloseBtn");
    private final By btnUpdateInForm    = By.xpath(
        "//button[normalize-space()='Update'][not(ancestor::table)]"
    );

    // Edit button
    private final By btnEditFirst       = By.cssSelector("button.edit-btn[data-action='edit']");

    // Detail panel
    private final By btnDelete          = By.id("detailDeleteBtn");
    private final By btnBack            = By.id("backIconBtn");

    // Delete confirm popup — ID xác nhận từ DevTools
    private final By confirmPopup       = By.cssSelector(".confirm-modal, .swal2-popup");
    private final By btnConfirmYes      = By.id("deleteConfirmYesBtn");
    private final By btnConfirmNo       = By.id("deleteConfirmNoBtn");

    // Deactivate/Activate confirm popup
    private final By btnDeactivateConfirm = By.id("deactivateStationConfirmBtn");
    private final By btnDeactivateCancel  = By.id("deactivateStationCancelBtn");
    private final By deactivateOverlay    = By.id("deactivateStationOverlay");

    // Toggle buttons trong bảng — dùng text-only, KHÔNG dùng class vì class thay đổi theo UI.
    // Mỗi row có 2 button: "ON" (để deactivate trạm đang Active)
    //                  và "OFF" (để activate trạm đang Inactive).
    // Locator tìm button đầu tiên trong row của trạm Active/Inactive tương ứng.
    //
    // Cấu trúc row (xác nhận từ rendered page):
    //   <tr>
    //     <td>ST001</td><td>Name</td>...<td>Active</td>
    //     <td><button>ON</button><button>OFF</button></td>
    //   </tr>
    //
    // Để deactivate: tìm row có status "Active" → click button "ON" trong row đó.
    // Để activate:   tìm row có status "Inactive" → click button "OFF" trong row đó.

    // Button "ON" trong row đầu tiên có trạm Active (dùng để DEACTIVATE)
    private final By btnDeactivateToggle  = By.xpath(
        "(//tr[.//td[normalize-space()='Active']][1]//button[normalize-space()='ON'])[1]"
    );

    // Button "OFF" trong row đầu tiên có trạm Inactive (dùng để ACTIVATE)
    private final By btnActivateToggle    = By.xpath(
        "(//tr[.//td[normalize-space()='Inactive']][1]//button[normalize-space()='OFF'])[1]"
    );

    // SweetAlert2 fallback
    private final By swal2Popup         = By.cssSelector(".swal2-popup");
    private final By swal2Confirm       = By.cssSelector(".swal2-confirm");
    private final By swal2Cancel        = By.cssSelector(".swal2-cancel");
    private final By swal2Title         = By.cssSelector(".swal2-title");

    // Toast / notification
    private final By toastAny           = By.xpath(
        "//*[contains(@class,'swal2') or contains(@class,'toast') "
        + "or contains(@class,'notification') or contains(@class,'alert-success') "
        + "or contains(@class,'alert-danger')][string-length(normalize-space(.))>0]"
    );

    // Validation error
    private final By validationMsg      = By.xpath(
        "//*[contains(@class,'error') or contains(@class,'invalid') "
        + "or contains(@class,'text-danger') or contains(@class,'alert-danger')]"
        + "[string-length(normalize-space(.))>0]"
    );

    // ===================================================================
    //  NAVIGATION & PAGE LOAD
    // ===================================================================

    public void navigateToStationPage() {
        Constant.WEBDRIVER.navigate().to(Constant.STATION_URL);
        waitForStationPageReady();
    }

    public void waitForStationPageReady() {
        // Chờ document.readyState = complete
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(driver -> ((JavascriptExecutor) driver)
                .executeScript("return document.readyState").equals("complete"));

        // Chờ nút Create new visible = trang đã render xong
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.elementToBeClickable(btnCreateNew));
        } catch (Exception ignored) {}
    }

    public void refresh() {
        refreshPage();
        waitForStationPageReady();
    }

    // ===================================================================
    //  CREATE FORM
    // ===================================================================

    /**
     * Locator cho panel drawer tạo trạm — dùng để chờ visible/invisible.
     * Drawer là right-side panel, ẩn bằng CSS transform/class, KHÔNG bị remove khỏi DOM.
     * Ta detect bằng visibility của input bên trong (đáng tin nhất).
     */
    private final By createFormPanel = By.id("createStationPanel");

    /**
     * Mở form Create new station.
     *
     * Chiến lược:
     *   1. Chờ nút "Create new" clickable (trang đã load xong).
     *   2. Scroll vào view + click bằng Selenium thật.
     *   3. Nếu Selenium click không được, retry bằng JS click.
     *   4. Chờ input #createStationName visible = form đã mở hoàn toàn.
     */
    public void openCreateStationForm() {
        System.out.println("[openCreateStationForm] Chờ nút 'Create new' clickable...");

        // Bước 1: Chờ nút clickable
        WebElement createBtn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(ExpectedConditions.elementToBeClickable(btnCreateNew));

        // Bước 2: Scroll vào view
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].scrollIntoView({block:'center'});", createBtn);

        // Bước 3: Click thật
        System.out.println("[openCreateStationForm] Click 'Create new'...");
        try {
            createBtn.click();
        } catch (Exception e) {
            System.out.println("[openCreateStationForm] Selenium click thất bại, thử JS click...");
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].click();", createBtn);
        }

        // Bước 4: Chờ input #createStationName visible = form đã mở
        System.out.println("[openCreateStationForm] Chờ form hiển thị (input visible)...");
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.visibilityOfElementLocated(inputStationName));
            System.out.println("[openCreateStationForm] Form đã mở (input visible).");
            return;
        } catch (Exception e) {
            System.out.println("[openCreateStationForm] Input chưa visible, thử retry click...");
        }

        // Retry: click lại bằng JS nếu lần đầu không ăn
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].click();", createBtn);

        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(ExpectedConditions.visibilityOfElementLocated(inputStationName));
        System.out.println("[openCreateStationForm] Form đã mở sau retry.");
    }

    public void clickCreateNew() {
        openCreateStationForm();
    }

    /**
     * Kiểm tra form Create đang hiển thị hay không.
     *
     * Drawer là right-side panel — KHÔNG bị remove khỏi DOM khi đóng.
     * Dùng ExpectedConditions.visibilityOfElementLocated cho input bên trong,
     * KHÔNG dùng findElement().isDisplayed() vì element vẫn present khi ẩn.
     */
    public boolean isCreateFormDisplayed() {
        System.out.println("[isCreateFormDisplayed] Kiểm tra form...");
        try {
            // Dùng WebDriverWait ngắn để check visibility của input bên trong form
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.visibilityOfElementLocated(inputStationName));
            System.out.println("[isCreateFormDisplayed] => true (input visible)");
            return true;
        } catch (Exception e) {
            System.out.println("[isCreateFormDisplayed] => false (input không visible)");
            return false;
        }
    }

    /**
     * Đóng form bằng nút Cancel bên trong Create form.
     *
     * Locator: By.id("createStationCancelBtn") — nằm TRONG #createStationPanel,
     * không nhầm với Cancel button ở nơi khác.
     *
     * Sau khi click, chờ input #createStationName invisible
     * (drawer slide ra ngoài viewport).
     */
    public void closeCreateFormByCancel() {
        System.out.println("[closeCreateFormByCancel] Tìm nút Cancel trong form...");

        // Tìm Cancel button TRONG createStationPanel để tránh nhầm với button khác
        WebElement cancelBtn = null;
        try {
            // Ưu tiên: tìm theo ID chính xác
            cancelBtn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.elementToBeClickable(btnCancelInForm));
        } catch (Exception e) {
            System.out.println("[closeCreateFormByCancel] Không tìm thấy theo ID, thử XPath trong panel...");
            // Fallback: tìm Cancel button bên trong panel
            try {
                cancelBtn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                    .until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//*[@id='createStationPanel']//button[normalize-space()='Cancel' " +
                                 "or normalize-space()='Hủy' or normalize-space()='cancel']")
                    ));
            } catch (Exception e2) {
                System.out.println("[closeCreateFormByCancel] Fallback XPath cũng thất bại, dùng JS click...");
            }
        }

        if (cancelBtn != null) {
            scrollIntoView(cancelBtn);
            System.out.println("[closeCreateFormByCancel] Click Cancel...");
            try {
                cancelBtn.click();
            } catch (Exception e) {
                System.out.println("[closeCreateFormByCancel] Selenium click thất bại, dùng JS...");
                ((JavascriptExecutor) Constant.WEBDRIVER)
                    .executeScript("arguments[0].click();", cancelBtn);
            }
        } else {
            // Last resort: JS click theo ID
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript(
                    "var btn = document.getElementById('createStationCancelBtn');" +
                    "if (btn) btn.click();"
                );
        }

        acceptAlertIfPresent();

        // Chờ form đóng: input #createStationName phải invisible
        System.out.println("[closeCreateFormByCancel] Chờ form đóng (input invisible)...");
        waitForCreateFormClosed();
        System.out.println("[closeCreateFormByCancel] Form đã đóng.");
    }

    /** Đóng form bằng X, chờ form biến mất */
    public void closeCreateFormByX() {
        System.out.println("[closeCreateFormByX] Click nút X...");
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(btnCloseForm));
            scrollIntoView(btn);
            btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript(
                    "var btn = document.getElementById('createStationCloseBtn');" +
                    "if (btn) btn.click();"
                );
        }
        acceptAlertIfPresent();
        waitForCreateFormClosed();
    }

    /**
     * Chờ form đóng hoàn toàn: input #createStationName phải invisible.
     * Dùng ExpectedConditions.invisibilityOfElementLocated — đúng với drawer pattern.
     */
    private void waitForCreateFormClosed() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.invisibilityOfElementLocated(inputStationName));
            System.out.println("[waitForCreateFormClosed] Form đã đóng hoàn toàn.");
        } catch (Exception e) {
            System.out.println("[waitForCreateFormClosed] Timeout chờ form đóng.");
        }
    }

    /**
     * Lấy Station ID auto-generate từ header form (dạng "ID: ST016").
     * Dùng querySelector tìm element nhỏ chứa text "ID: ST..."
     */
    public String getGeneratedStationId() {
        try {
            String id = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var all = document.querySelectorAll('span, p, div, h1, h2, h3, h4, small, label');" +
                "for (var i = 0; i < all.length; i++) {" +
                "  var t = all[i].innerText;" +
                "  if (t && /ID:\\s*ST\\d+/.test(t) && all[i].children.length < 3) {" +
                "    var m = t.match(/ID:\\s*(ST\\d+)/);" +
                "    if (m) return m[1];" +
                "  }" +
                "}" +
                "return null;"
            );
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}
        return "";
    }

    public void fillStationName(String name) { safeType(inputStationName, name); }
    public void fillLatitude(String lat)     { safeType(inputLatitude, lat); }
    public void fillLongitude(String lng)    { safeType(inputLongitude, lng); }
    public void fillAddress(String address)  { safeType(inputAddress, address); }

    /** Click Save — Selenium click thật */
    public void clickSave() {
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(btnSaveInForm));
            scrollIntoView(btn);
            btn.click();
        } catch (Exception e) {
            jsClick(Constant.WEBDRIVER.findElement(btnSaveInForm));
        }
    }

    /** Accept native browser alert nếu có */
    public void acceptAlertIfPresent() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().accept();
        } catch (Exception ignored) {}
    }

    /**
     * Web dùng browser Notification API (không phải window.alert).
     * Sau Save thành công form sẽ đóng — chờ form đóng và trả về "Created successfully."
     */
    public String getAlertTextAndAccept() {
        // Thử window.alert trước
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            org.openqa.selenium.Alert alert = Constant.WEBDRIVER.switchTo().alert();
            String text = alert.getText();
            alert.accept();
            return text != null ? text : "Created successfully.";
        } catch (Exception ignored) {}
        // Không có alert → chờ form đóng (browser notification)
        waitForCreateFormClosed();
        // Nếu form đã đóng = save thành công
        if (!isCreateFormDisplayed()) {
            return "Created successfully.";
        }
        return "";
    }

    /** Kiểm tra Save button có enabled không */
    public boolean isSaveButtonEnabled() {
        try {
            WebElement btn = Constant.WEBDRIVER.findElement(btnSaveInForm);
            String cls = btn.getAttribute("class");
            return btn.isEnabled() && (cls == null || !cls.contains("disabled"));
        } catch (Exception e) { return false; }
    }

    /** Lấy bất kỳ validation text nào trong form */
    public String getAnyValidationText() {
        try {
            By loc = By.xpath(
                "//*[contains(@class,'error') or contains(@class,'invalid') " +
                "or contains(@class,'required') or contains(@class,'text-danger')]" +
                "[string-length(normalize-space(.))>0]"
            );
            return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.presenceOfElementLocated(loc))
                .getText().trim();
        } catch (Exception e) { return ""; }
    }

    /** Kiểm tra station có trong table không (qua tất cả trang) */
    public boolean isStationDisplayedInTable(String stationName) {
        return waitForStationInList(stationName);
    }

    // ===================================================================
    //  FORM FIELDS
    // ===================================================================

    public void enterStationName(String name) {
        jsSetValueById("createStationName", name);
    }

    public void enterAddress(String address) {
        jsSetValueById("createAddress", address);
    }

    public void enterLatitude(String lat) {
        jsSetValueById("createLatitude", lat);
    }

    public void enterLongitude(String lng) {
        jsSetValueById("createLongitude", lng);
    }

    /** Set value vào input theo id bằng JS + trigger events + sendKeys */
    private void jsSetValueById(String id, String value) {
        // Bước 1: JS set value + trigger events
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var el = document.getElementById(arguments[0]);" +
            "if (el) {" +
            "  el.focus();" +
            "  el.value = '';" +
            "  el.dispatchEvent(new Event('focus', {bubbles:true}));" +
            "}",
            id
        );
        // Bước 2: sendKeys để trigger native input events (validation)
        try {
            WebElement el = Constant.WEBDRIVER.findElement(By.id(id));
            el.clear();
            el.sendKeys(value);
        } catch (Exception e) {
            // Fallback: JS set + trigger
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var el = document.getElementById(arguments[0]);" +
                "if (el) {" +
                "  el.value = arguments[1];" +
                "  el.dispatchEvent(new Event('input',  {bubbles:true}));" +
                "  el.dispatchEvent(new Event('change', {bubbles:true}));" +
                "  el.dispatchEvent(new Event('blur',   {bubbles:true}));" +
                "}",
                id, value
            );
        }
    }

    public void fillCreateForm(String name, String address, String lat, String lng) {
        enterStationName(name);
        enterLatitude(lat);
        enterLongitude(lng);
        enterAddress(address);
    }

    public void clearStationName() {
        jsSetValueById("createStationName", "");
    }

    public String getStationNameValue() {
        try {
            return (String) ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("var el=document.getElementById('createStationName'); return el?el.value:'';");
        } catch (Exception e) { return ""; }
    }

    public boolean isStationIdAutoGenerated() {
        try {
            // Form header hiển thị "ID: ST039" — lấy text của element chứa ID
            String text = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var els = document.querySelectorAll('*');" +
                "for (var i = 0; i < els.length; i++) {" +
                "  var t = els[i].childNodes.length === 1 && els[i].childNodes[0].nodeType === 3" +
                "          ? els[i].textContent.trim() : '';" +
                "  if (/^ID:\\s*ST\\d+/.test(t)) return t;" +
                "}" +
                "return '';"
            );
            return text != null && !text.isEmpty();
        } catch (Exception e) { return false; }
    }

    /** Click Cancel (alias cho closeCreateFormByCancel) */
    public void clickCancel() {
        closeCreateFormByCancel();
    }

    /**
     * Click Update trong edit form.
     * Debug: in outerHTML của tất cả button trong panel để xác định đúng button.
     */
    public void clickUpdate() {
        // Debug: in tất cả button trong panel để xác định ID/class thật
        String btnDebug = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var panel = document.getElementById('createStationPanel');" +
            "if (!panel) return 'PANEL NOT FOUND';" +
            "var btns = panel.querySelectorAll('button');" +
            "var info = 'Total buttons: ' + btns.length + '\\n';" +
            "for (var i = 0; i < btns.length; i++) {" +
            "  info += 'btn[' + i + ']: id=' + btns[i].id" +
            "    + ', class=' + btns[i].className" +
            "    + ', text=' + (btns[i].innerText||'').trim().substring(0,30)" +
            "    + ', data-action=' + (btns[i].getAttribute('data-action')||'')" +
            "    + '\\n';" +
            "}" +
            "return info;"
        );
        System.out.println("[clickUpdate] Buttons trong panel:\n" + btnDebug);

        // Thử click theo thứ tự ưu tiên:
        // 1. Button có data-action="update" hoặc data-action="save"
        // 2. Button có id chứa "save" hoặc "update"
        // 3. Button text "Update" hoặc "Save"
        Boolean clicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var panel = document.getElementById('createStationPanel');" +
            "if (!panel) return false;" +
            "var btns = panel.querySelectorAll('button');" +
            // Ưu tiên 1: data-action="update" hoặc "save"
            "for (var i = 0; i < btns.length; i++) {" +
            "  var action = (btns[i].getAttribute('data-action')||'').toLowerCase();" +
            "  if (action === 'update' || action === 'save') {" +
            "    btns[i].scrollIntoView({block:'center'}); btns[i].click(); return true;" +
            "  }" +
            "}" +
            // Ưu tiên 2: id chứa "save" hoặc "update"
            "for (var i = 0; i < btns.length; i++) {" +
            "  var id = (btns[i].id||'').toLowerCase();" +
            "  if (id.indexOf('save') !== -1 || id.indexOf('update') !== -1) {" +
            "    btns[i].scrollIntoView({block:'center'}); btns[i].click(); return true;" +
            "  }" +
            "}" +
            // Ưu tiên 3: text "Update" hoặc "Save"
            "for (var i = 0; i < btns.length; i++) {" +
            "  var t = (btns[i].innerText||btns[i].textContent||'').trim();" +
            "  if (t === 'Update' || t === 'Save') {" +
            "    btns[i].scrollIntoView({block:'center'}); btns[i].click(); return true;" +
            "  }" +
            "}" +
            "return false;"
        );
        System.out.println("[clickUpdate] Clicked: " + clicked);

        // Chờ tối đa 5s để web xử lý: form đóng HOẶC toast xuất hiện
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(driver -> {
                    // Điều kiện 1: form đóng
                    if (!isCreateFormDisplayed()) return true;
                    // Điều kiện 2: có toast/notification visible trong DOM
                    Boolean hasToast = (Boolean) ((JavascriptExecutor) driver).executeScript(
                        "var els = document.querySelectorAll(" +
                        "  '[class*=\"toast\"], [class*=\"notification\"], [class*=\"snack\"]," +
                        "   [class*=\"alert\"], [class*=\"success\"], .swal2-popup');" +
                        "for (var i = 0; i < els.length; i++) {" +
                        "  var s = window.getComputedStyle(els[i]);" +
                        "  var t = (els[i].innerText||'').toLowerCase();" +
                        "  if (s.display !== 'none' && s.visibility !== 'hidden'" +
                        "      && (t.indexOf('success') !== -1 || t.indexOf('updated') !== -1" +
                        "          || t.indexOf('c\\u1eadp nh\\u1eadt') !== -1)) return true;" +
                        "}" +
                        "return false;"
                    );
                    return Boolean.TRUE.equals(hasToast);
                });
        } catch (Exception ignored) {
            // Nếu không detect được, vẫn tiếp tục
        }
        waitForCreateFormClosed();
    }

    // ===================================================================
    //  EDIT BUTTON
    // ===================================================================

    public void clickEditFirstStation() {
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.presenceOfElementLocated(btnEditFirst));
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", el);
            // Chờ form edit mở
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.visibilityOfElementLocated(inputStationName));
        } catch (Exception e) {
            // Fallback: icon edit_square
            By fallback = By.xpath("(//span[normalize-space()='edit_square'])[1]");
            jsClick(waitForVisible(fallback));
        }
    }

    public void updateStationName(String name) {
        // Clear + sendKeys + trigger JS events để đảm bảo framework reactive nhận giá trị
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.visibilityOfElementLocated(inputStationName));
            // Xóa nội dung cũ
            el.click();
            el.sendKeys(org.openqa.selenium.Keys.chord(org.openqa.selenium.Keys.CONTROL, "a"));
            el.sendKeys(org.openqa.selenium.Keys.DELETE);
            el.clear();
            // Nhập giá trị mới
            el.sendKeys(name);
            // Trigger input/change events để framework reactive nhận
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var el = document.getElementById('createStationName');" +
                "if (el) {" +
                "  el.dispatchEvent(new Event('input',  {bubbles:true}));" +
                "  el.dispatchEvent(new Event('change', {bubbles:true}));" +
                "  el.dispatchEvent(new Event('blur',   {bubbles:true}));" +
                "}"
            );
        } catch (Exception e) {
            // Fallback: JS set value
            jsSetValueById("createStationName", name);
        }
    }
    public void updateAddress(String addr)     { enterAddress(addr); }

    // ===================================================================
    //  VALIDATION
    // ===================================================================

    public boolean isValidationErrorDisplayed() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.visibilityOfElementLocated(validationMsg));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isGpsErrorDisplayed() {
        return isValidationErrorDisplayed();
    }

    public String getValidationErrorText() {
        try { return getText(validationMsg); } catch (Exception e) { return ""; }
    }

    // ===================================================================
    //  TOAST / SUCCESS / ERROR
    // ===================================================================

    public boolean isSuccessToastDisplayed() {
        // Cách 1: form đóng = thành công
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.invisibilityOfElementLocated(inputStationName));
            return true;
        } catch (Exception ignored) {}

        // Cách 2: tìm toast/notification element có text success
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.visibilityOfElementLocated(toastAny));
            String txt = el.getText().toLowerCase();
            return txt.contains("success") || txt.contains("updated")
                || txt.contains("created") || txt.contains("deleted")
                || txt.contains("thành công") || txt.contains("cập nhật");
        } catch (Exception ignored) {}

        // Cách 3: swal2
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.visibilityOfElementLocated(swal2Popup));
            String txt = el.getText().toLowerCase();
            return txt.contains("success") || txt.contains("updated")
                || txt.contains("created") || txt.contains("deleted");
        } catch (Exception ignored) {}

        return false;
    }

    public String getToastMessage() {
        // Dùng JS để tìm bất kỳ element visible nào có text success/error
        try {
            String msg = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var candidates = document.querySelectorAll(" +
                "  '[class*=\"toast\"], [class*=\"notification\"], [class*=\"snack\"]," +
                "   [class*=\"alert\"], [class*=\"success\"], [class*=\"message\"]," +
                "   .swal2-title, .swal2-popup');" +
                "for (var i = 0; i < candidates.length; i++) {" +
                "  var el = candidates[i];" +
                "  var s = window.getComputedStyle(el);" +
                "  var t = (el.innerText || el.textContent || '').trim();" +
                "  if (s.display !== 'none' && s.visibility !== 'hidden' && t.length > 0) {" +
                "    return t;" +
                "  }" +
                "}" +
                "return '';"
            );
            if (msg != null && !msg.isEmpty()) {
                System.out.println("[getToastMessage] JS found: '" + msg + "'");
                return msg;
            }
        } catch (Exception ignored) {}

        // Fallback: WebDriverWait
        By[] candidates = { swal2Title, toastAny };
        for (By loc : candidates) {
            try {
                WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                    .until(ExpectedConditions.visibilityOfElementLocated(loc));
                String txt = el.getText().trim();
                if (!txt.isEmpty()) return txt;
            } catch (Exception ignored) {}
        }
        return "";
    }

    // ===================================================================
    //  DANH SÁCH TRẠM
    // ===================================================================

    public int getStationCount() {
        // Chờ table load trước khi đếm
        waitStationTableLoaded();
        try {
            // Đếm số row thực tế trong tbody (mỗi row có ít nhất 1 td)
            List<WebElement> rows = Constant.WEBDRIVER.findElements(
                By.cssSelector("table tbody tr:has(td)")
            );
            if (!rows.isEmpty()) {
                System.out.println("[getStationCount] Đếm được " + rows.size() + " rows (CSS :has)");
                return rows.size();
            }
            // Fallback: XPath
            rows = Constant.WEBDRIVER.findElements(
                By.xpath("//table//tbody//tr[td]")
            );
            System.out.println("[getStationCount] Đếm được " + rows.size() + " rows (XPath)");
            return rows.size();
        } catch (Exception e) {
            System.out.println("[getStationCount] Lỗi: " + e.getMessage());
            return 0;
        }
    }

    public boolean isStationInList(String name) {
        // Tìm trong trang hiện tại
        try {
            Boolean found = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var rows = document.querySelectorAll('table tbody tr td');" +
                "for (var i = 0; i < rows.length; i++) {" +
                "  if (rows[i].textContent.indexOf(arguments[0]) !== -1) return true;" +
                "}" +
                "return false;",
                name
            );
            if (Boolean.TRUE.equals(found)) return true;

            // Thử click trang cuối nếu có pagination
            java.util.List<WebElement> pages = Constant.WEBDRIVER.findElements(
                By.cssSelector("button.pagination-page")
            );
            if (pages.size() > 1) {
                ((JavascriptExecutor) Constant.WEBDRIVER)
                    .executeScript("arguments[0].click();", pages.get(pages.size() - 1));
                Thread.sleep(500);
                found = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "var rows = document.querySelectorAll('table tbody tr td');" +
                    "for (var i = 0; i < rows.length; i++) {" +
                    "  if (rows[i].textContent.indexOf(arguments[0]) !== -1) return true;" +
                    "}" +
                    "return false;",
                    name
                );
            }
            return Boolean.TRUE.equals(found);
        } catch (Exception e) { return false; }
    }

    /**
     * Chờ tên trạm xuất hiện trong bảng — tìm qua tất cả các trang pagination.
     */
    public boolean waitForStationInList(String name) {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    // Thử tìm trong trang hiện tại trước
                    Boolean found = (Boolean) ((JavascriptExecutor) driver).executeScript(
                        "var rows = document.querySelectorAll('table tbody tr td');" +
                        "for (var i = 0; i < rows.length; i++) {" +
                        "  if (rows[i].textContent.trim().indexOf(arguments[0]) !== -1) return true;" +
                        "}" +
                        "return false;",
                        name
                    );
                    if (Boolean.TRUE.equals(found)) return true;

                    // Nếu không thấy, thử click trang cuối rồi tìm lại
                    try {
                        // Lấy tất cả pagination buttons (số trang)
                        java.util.List<WebElement> pages = driver.findElements(
                            By.cssSelector("button.pagination-page")
                        );
                        if (pages.size() > 1) {
                            // Click trang cuối
                            WebElement lastPage = pages.get(pages.size() - 1);
                            ((JavascriptExecutor) driver).executeScript(
                                "arguments[0].click();", lastPage
                            );
                            // Chờ table update
                            Thread.sleep(500);
                            // Tìm lại
                            found = (Boolean) ((JavascriptExecutor) driver).executeScript(
                                "var rows = document.querySelectorAll('table tbody tr td');" +
                                "for (var i = 0; i < rows.length; i++) {" +
                                "  if (rows[i].textContent.trim().indexOf(arguments[0]) !== -1) return true;" +
                                "}" +
                                "return false;",
                                name
                            );
                        }
                    } catch (Exception ignored) {}

                    return Boolean.TRUE.equals(found);
                });
            return true;
        } catch (Exception e) {
            System.out.println("[waitForStationInList] Timeout - khong tim thay: " + name);
            return false;
        }
    }

    public void clickFirstStation() {
        safeClick(By.cssSelector("table tbody tr:first-child td:nth-child(2)"));
    }

    public void clickFirstActiveStation() {
        try {
            safeClick(By.xpath("//table//tbody//tr[.//td[normalize-space()='Active']][1]//td[2]"));
        } catch (Exception e) { clickFirstStation(); }
    }

    public void clickStationByName(String name) {
        // Dùng JS scroll đến row chứa tên rồi click
        WebElement cell = (WebElement) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var rows = document.querySelectorAll('table tbody tr td');" +
            "for (var i = 0; i < rows.length; i++) {" +
            "  if (rows[i].textContent.indexOf(arguments[0]) !== -1) {" +
            "    rows[i].scrollIntoView({block:'center'});" +
            "    return rows[i];" +
            "  }" +
            "}" +
            "return null;",
            name
        );
        if (cell != null) {
            scrollIntoView(cell);
            jsClick(cell);
        } else {
            throw new RuntimeException("Khong tim thay tram: " + name);
        }
    }

    // ===================================================================
    //  DETAIL PANEL
    // ===================================================================

    public boolean isDetailPanelDisplayed() {
        // Panel chi tiết hiển thị khi nút Delete (detailDeleteBtn) visible
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.visibilityOfElementLocated(btnDelete));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isDeleteButtonDisplayed() {
        return isDisplayed(btnDelete);
    }

    public void closeDetailPanel() {
        // Thử nút X (createStationCloseBtn) hoặc back (backIconBtn)
        try { safeClick(btnCloseForm); return; } catch (Exception ignored) {}
        try { safeClick(btnBack); return; } catch (Exception ignored) {}
        Constant.WEBDRIVER.findElement(By.tagName("body")).sendKeys(Keys.ESCAPE);
    }

    public boolean isCoordinatesSectionDisplayed() {
        return isPresent(By.xpath("//*[normalize-space()='Coordinates']"));
    }

    public boolean isConnectorsSectionDisplayed() {
        By[] candidates = {
            By.xpath("//*[contains(text(),'Poles') and contains(text(),'Pole Status')]"),
            By.xpath("//*[contains(text(),'Charging Connectors')]"),
            By.xpath("//*[contains(@class,'pole') or contains(@class,'connector')][string-length(normalize-space(.))>5]")
        };
        for (By loc : candidates) {
            if (isPresent(loc)) return true;
        }
        return false;
    }

    // ===================================================================
    //  DELETE HELPERS
    // ===================================================================

    /**
     * Thử xóa một station theo Station ID.
     * Click row → click Delete → Confirm → chờ 5s → verify station không còn trong DOM.
     *
     * @return true nếu station đã biến mất sau confirm, false nếu vẫn còn
     */
    public boolean tryDeleteStationById(String stationId) {
        System.out.println("[tryDeleteStationById] Thử xóa: " + stationId);
        try {
            // Click vào row để mở detail panel
            clickStationRowById(stationId);

            if (!isDetailPanelDisplayed()) {
                System.out.println("[tryDeleteStationById] Detail panel không mở cho " + stationId);
                return false;
            }

            // Click Delete
            clickDelete();

            if (!isDeleteConfirmPopupDisplayed()) {
                System.out.println("[tryDeleteStationById] Popup không hiển thị cho " + stationId);
                return false;
            }

            // Confirm
            confirmDelete();

            // Chờ tối đa 5s để station biến mất THẬT SỰ
            // (không chỉ biến mất tạm trong lúc re-render)
            try {
                new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                    .until(driver -> !isStationPresentById(stationId));
                System.out.println("[tryDeleteStationById] " + stationId + " đã xóa thành công.");
                return true;
            } catch (Exception e) {
                // Station vẫn còn sau 5s → web không cho xóa (có ràng buộc)
                String status = getStationStatusById(stationId);
                System.out.println("[tryDeleteStationById] " + stationId
                    + " vẫn còn sau confirm (status='" + status + "'). Web không cho xóa.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("[tryDeleteStationById] Lỗi: " + e.getMessage());
            return false;
        }
    }

    /**
     * Tìm Station ID của trạm có thể xóa được.
     * Bỏ qua các station trong excludedIds (VD: ST001 có ongoing session).
     *
     * Chỉ thử xóa station đang INACTIVE — web chỉ cho phép xóa station Inactive.
     * Nếu thành công thì trả về ID đó. Nếu thất bại, reload và thử tiếp.
     *
     * @param excludedIds  tập Station ID cần bỏ qua
     * @return Station ID đã xóa thành công, hoặc null nếu không có
     */
    public String findDeletableStationId(java.util.Set<String> excludedIds) {
        System.out.println("[findDeletableStationId] Tìm station Inactive có thể xóa...");
        waitStationTableLoaded();

        // Chỉ lấy row có status Inactive
        List<WebElement> inactiveRows = getStationRowsByStatus("Inactive");
        System.out.println("[findDeletableStationId] Số row Inactive: " + inactiveRows.size());

        // Thu thập ID trước để tránh stale element sau reload
        List<String> ids = new java.util.ArrayList<>();
        for (WebElement row : inactiveRows) {
            String id = getStationIdFromRow(row);
            if (id != null && !id.isEmpty()) ids.add(id);
        }
        System.out.println("[findDeletableStationId] Inactive IDs: " + ids);

        for (String stationId : ids) {
            if (excludedIds != null && excludedIds.contains(stationId)) {
                System.out.println("[findDeletableStationId] Bỏ qua: " + stationId);
                continue;
            }

            System.out.println("[findDeletableStationId] Thử xóa Inactive station: " + stationId);
            boolean deleted = tryDeleteStationById(stationId);

            if (deleted) {
                System.out.println("[findDeletableStationId] Xóa thành công: " + stationId);
                return stationId;
            }

            // Thất bại → reload để reset state trước khi thử station tiếp theo
            System.out.println("[findDeletableStationId] " + stationId
                + " không xóa được, reload và thử tiếp...");
            navigateToStationPage();
            waitStationTableLoaded();
        }

        System.out.println("[findDeletableStationId] Không tìm thấy station Inactive nào có thể xóa.");
        return null;
    }

    /**
     * Click vào row của station theo Station ID để mở detail panel.
     * DOM: <tr data-id="ST001"> → click td:nth-child(2) (cột tên)
     */
    public void clickStationRowById(String stationId) {
        System.out.println("[clickStationRowById] Click row: " + stationId);
        By loc = By.cssSelector("tr[data-id='" + stationId + "'] td:nth-child(2)");
        WebElement cell = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
            .until(ExpectedConditions.presenceOfElementLocated(loc));
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", cell);
        System.out.println("[clickStationRowById] Đã click.");
    }

    /**
     * Chờ station biến mất khỏi bảng (sau khi xóa).
     * Dùng Station ID (data-id attribute).
     *
     * @return true nếu station đã biến mất, false nếu timeout
     */
    public boolean waitStationDisappearById(String stationId) {
        System.out.println("[waitStationDisappearById] Chờ " + stationId + " biến mất...");
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.invisibilityOfElementLocated(
                    By.cssSelector("tr[data-id='" + stationId + "']")
                ));
            System.out.println("[waitStationDisappearById] " + stationId + " đã biến mất.");
            return true;
        } catch (Exception e) {
            System.out.println("[waitStationDisappearById] Timeout — " + stationId + " vẫn còn.");
            return false;
        }
    }

    /**
     * Kiểm tra station có còn trong bảng không theo Station ID.
     */
    public boolean isStationPresentById(String stationId) {
        try {
            return !Constant.WEBDRIVER.findElements(
                By.cssSelector("tr[data-id='" + stationId + "']")
            ).isEmpty();
        } catch (Exception e) { return false; }
    }

    // ===================================================================
    //  DELETE POPUP
    // ===================================================================

    public void clickDelete() {
        safeClick(btnDelete);
        // Chờ popup xác nhận hiển thị sau khi click Delete
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.visibilityOfElementLocated(
                    By.id("deleteConfirmModal")
                ));
        } catch (Exception ignored) {}
    }

    public boolean isDeleteConfirmPopupDisplayed() {
        // Popup xóa dùng id="deleteConfirmModal", class="confirm-modal"
        By[] candidates = {
            By.id("deleteConfirmModal"),
            By.cssSelector(".confirm-modal"),
            By.cssSelector(".swal2-popup")
        };
        for (By loc : candidates) {
            try {
                new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                    .until(ExpectedConditions.visibilityOfElementLocated(loc));
                return true;
            } catch (Exception ignored) {}
        }
        return false;
    }

    public void confirmDelete() {
        // Thử native alert trước
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().accept();
            System.out.println("[confirmDelete] Accepted native alert.");
            waitStationTableLoaded();
            return;
        } catch (Exception ignored) {}

        // Custom modal — dùng JS click để bypass interactability
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(btnConfirmYes));
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", btn);
            System.out.println("[confirmDelete] Clicked confirm button.");
        } catch (Exception e) {
            // Fallback: JS click theo ID
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var btn = document.getElementById('deleteConfirmYesBtn');" +
                "if (btn) { btn.click(); return; }" +
                "var swal = document.querySelector('.swal2-confirm');" +
                "if (swal) swal.click();"
            );
            System.out.println("[confirmDelete] JS fallback clicked.");
        }

        // Chờ popup đóng
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.invisibilityOfElementLocated(By.id("deleteConfirmModal")));
        } catch (Exception ignored) {}

        waitStationTableLoaded();
    }

    public void cancelDelete() {
        // Thử native alert trước
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().dismiss();
            System.out.println("[cancelDelete] Dismissed native alert.");
            return;
        } catch (Exception ignored) {}

        // Custom modal — dùng JS click
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(btnConfirmNo));
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", btn);
            System.out.println("[cancelDelete] Clicked cancel button.");
        } catch (Exception e) {
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var btn = document.getElementById('deleteConfirmNoBtn');" +
                "if (btn) { btn.click(); return; }" +
                "var swal = document.querySelector('.swal2-cancel');" +
                "if (swal) swal.click();"
            );
            System.out.println("[cancelDelete] JS fallback clicked.");
        }

        // Chờ popup đóng
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.invisibilityOfElementLocated(By.id("deleteConfirmModal")));
        } catch (Exception ignored) {}
    }

    // ===================================================================
    //  TOGGLE / DEACTIVATE / ACTIVATE  (DOM-accurate từ log thật)
    //
    //  DOM xác nhận từ log:
    //  Active:   <button class="station-toggle is-on" data-action="deactivate" title="ON">
    //  Inactive: <button class="station-toggle"       data-action="deactivate" title="OFF">
    //  Row:      <tr data-id="ST001">
    //  Status:   <span class="status-badge status-badge--active">Active</span>
    // ===================================================================

    /**
     * Chờ bảng station load xong (có ít nhất 1 row).
     */
    public void waitStationTableLoaded() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("table tbody tr td")
                ));
            System.out.println("[waitStationTableLoaded] Bảng đã load.");
        } catch (Exception e) {
            System.out.println("[waitStationTableLoaded] Timeout chờ bảng load.");
        }
    }

    /**
     * Tìm tên trạm đầu tiên có status khớp với expectedStatus.
     * Trả về tên trạm hoặc null nếu không tìm thấy.
     */
    public String findFirstStationByStatus(String expectedStatus) {
        waitStationTableLoaded();
        try {
            By rowLoc = By.xpath(
                "//table//tbody//tr[.//td[normalize-space()='" + expectedStatus + "']]"
            );
            List<WebElement> rows = Constant.WEBDRIVER.findElements(rowLoc);
            if (!rows.isEmpty()) {
                String name = rows.get(0).findElements(By.tagName("td")).get(1).getText().trim();
                System.out.println("[findFirstStationByStatus] Tìm thấy '" + expectedStatus + "': " + name);
                return name;
            }
        } catch (Exception e) {
            System.out.println("[findFirstStationByStatus] Lỗi: " + e.getMessage());
        }
        System.out.println("[findFirstStationByStatus] Không tìm thấy trạm với status: " + expectedStatus);
        return null;
    }

    /**
     * Lấy danh sách tất cả row <tr> có status khớp.
     */
    public List<WebElement> getStationRowsByStatus(String status) {
        waitStationTableLoaded();
        By loc = By.xpath(
            "//table//tbody//tr[.//*[contains(@class,'status-badge') and normalize-space()='" + status + "']]"
        );
        List<WebElement> rows = Constant.WEBDRIVER.findElements(loc);
        System.out.println("[getStationRowsByStatus] '" + status + "': " + rows.size() + " rows");
        return rows;
    }

    /**
     * Lấy Station ID từ row.
     * DOM: <tr data-id="ST001"> hoặc <td class="station-id">ST001</td>
     */
    public String getStationIdFromRow(WebElement row) {
        try {
            String dataId = row.getAttribute("data-id");
            if (dataId != null && !dataId.isEmpty()) return dataId.trim();
            List<WebElement> idCells = row.findElements(By.cssSelector("td.station-id"));
            if (!idCells.isEmpty()) return idCells.get(0).getText().trim();
            return row.findElements(By.tagName("td")).get(0).getText().trim();
        } catch (Exception e) { return ""; }
    }

    /**
     * Lấy Station Name từ row (td[2]).
     */
    public String getStationNameFromRow(WebElement row) {
        try {
            return row.findElements(By.tagName("td")).get(1).getText().trim();
        } catch (Exception e) { return ""; }
    }

    /**
     * Lấy status từ row.
     * DOM: <span class="status-badge status-badge--active">Active</span>
     */
    public String getStationStatusFromRow(WebElement row) {
        try {
            List<WebElement> badges = row.findElements(By.cssSelector(".status-badge"));
            if (!badges.isEmpty()) return badges.get(0).getText().trim();
            List<WebElement> tds = row.findElements(By.tagName("td"));
            if (tds.size() >= 7) return tds.get(6).getText().trim();
        } catch (Exception e) { /* ignore */ }
        return "";
    }

    /**
     * Click nút toggle deactivate trong một row cụ thể.
     * DOM: <button data-action="deactivate" class="station-toggle [is-on]">
     * Dùng JS click để bypass interactability.
     */
    public void clickDeactivateToggleInRow(WebElement row) {
        List<WebElement> toggleBtns = row.findElements(
            By.cssSelector("button[data-action='deactivate']")
        );
        if (toggleBtns.isEmpty()) {
            throw new RuntimeException(
                "[clickDeactivateToggleInRow] Không tìm thấy button[data-action='deactivate'] trong row"
            );
        }
        WebElement btn = toggleBtns.get(0);
        System.out.println("[clickDeactivateToggleInRow] class='" + btn.getAttribute("class")
            + "', title='" + btn.getAttribute("title") + "'");
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", btn);
    }

    /**
     * Lấy status của trạm theo Station ID.
     * Dùng CSS selector tr[data-id='ST001'] — chính xác và nhanh.
     */
    public String getStationStatusById(String stationId) {
        try {
            By rowLoc = By.cssSelector("tr[data-id='" + stationId + "']");
            WebElement row = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(rowLoc));
            return getStationStatusFromRow(row);
        } catch (Exception e) {
            System.out.println("[getStationStatusById] Không tìm thấy row data-id=" + stationId);
            return "";
        }
    }

    /**
     * Lấy status của trạm theo tên hoặc Station ID.
     * Nếu input khớp pattern ST\d+ thì dùng getStationStatusById.
     */
    public String getStationStatusByName(String name) {
        try {
            if (name != null && name.matches("ST\\d+")) {
                String s = getStationStatusById(name);
                if (!s.isEmpty()) return s;
            }
            By loc = By.xpath(
                "//table//tbody//tr[.//td[contains(normalize-space(),'" + name + "')]]"
            );
            List<WebElement> rows = Constant.WEBDRIVER.findElements(loc);
            if (!rows.isEmpty()) return getStationStatusFromRow(rows.get(0));
        } catch (Exception e) {
            System.out.println("[getStationStatusByName] Lỗi: " + e.getMessage());
        }
        return "";
    }

    /**
     * Lấy toast/alert message sau thao tác — không throw exception nếu không có.
     * Thử: native alert → overlay text → swal2 title → toast element.
     */
    public String getToastOrAlertMessageOptional() {
        // 1. Native alert
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            String text = Constant.WEBDRIVER.switchTo().alert().getText();
            Constant.WEBDRIVER.switchTo().alert().accept();
            System.out.println("[getToastOrAlertMessageOptional] Native alert: '" + text + "'");
            return text != null ? text : "";
        } catch (Exception ignored) {}

        // 2. Overlay còn mở với message
        try {
            WebElement overlay = Constant.WEBDRIVER.findElement(deactivateOverlay);
            if (overlay.isDisplayed()) {
                String msg = overlay.getText().trim();
                if (!msg.isEmpty()) {
                    System.out.println("[getToastOrAlertMessageOptional] Overlay: '" + msg + "'");
                    return msg;
                }
            }
        } catch (Exception ignored) {}

        // 3. swal2 title
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.visibilityOfElementLocated(swal2Title));
            String msg = el.getText().trim();
            System.out.println("[getToastOrAlertMessageOptional] swal2: '" + msg + "'");
            return msg;
        } catch (Exception ignored) {}

        // 4. Toast/notification
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.visibilityOfElementLocated(toastAny));
            String msg = el.getText().trim();
            System.out.println("[getToastOrAlertMessageOptional] Toast: '" + msg + "'");
            return msg;
        } catch (Exception ignored) {}

        System.out.println("[getToastOrAlertMessageOptional] Không có message.");
        return "";
    }

    /**
     * Thử deactivate một trạm theo Station ID.
     * Click toggle → Confirm → chờ 5s → đọc lại status.
     *
     * @return true nếu status đổi thành Inactive, false nếu không đổi
     */
    public boolean tryDeactivateStationById(String stationId) {
        System.out.println("[tryDeactivateStationById] Thử deactivate: " + stationId);
        try {
            By rowLoc = By.cssSelector("tr[data-id='" + stationId + "']");
            WebElement row = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(rowLoc));

            // Click toggle deactivate
            clickDeactivateToggleInRow(row);

            // Chờ popup
            if (!isDeactivatePopupDisplayed()) {
                System.out.println("[tryDeactivateStationById] Popup không hiển thị cho " + stationId);
                return false;
            }

            // Confirm
            confirmDeactivate();

            // Sau confirm, bảng reload và station có thể bị đẩy sang trang khác (pagination).
            // Dùng waitForStationInList để navigate đến đúng trang trước khi check status.
            try {
                new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(8))
                    .until(driver -> {
                        // Tìm lại row trong DOM hiện tại
                        java.util.List<WebElement> rows = driver.findElements(
                            By.cssSelector("tr[data-id='" + stationId + "']"));
                        if (!rows.isEmpty()) {
                            String s = getStationStatusFromRow(rows.get(0));
                            return s.equalsIgnoreCase("Inactive");
                        }
                        // Row không có trong trang hiện tại — thử tìm qua pagination
                        // Dùng JS tìm trong tất cả row hiện tại
                        Boolean found = (Boolean) ((JavascriptExecutor) driver).executeScript(
                            "var rows = document.querySelectorAll('table tbody tr');" +
                            "for (var i = 0; i < rows.length; i++) {" +
                            "  if (rows[i].getAttribute('data-id') === arguments[0]) {" +
                            "    var badge = rows[i].querySelector('.status-badge');" +
                            "    if (badge) return badge.textContent.trim().toLowerCase() === 'inactive';" +
                            "  }" +
                            "}" +
                            "return null;", stationId);
                        return Boolean.TRUE.equals(found);
                    });
                System.out.println("[tryDeactivateStationById] " + stationId + " đã Inactive.");
                return true;
            } catch (Exception e) {
                // Timeout — thử navigate đến trang chứa station rồi check lại
                System.out.println("[tryDeactivateStationById] Timeout wait, thử tìm qua pagination...");
                navigateToStationPage();
                waitStationTableLoaded();
                // Tìm station theo ID qua pagination
                boolean inList = waitForStationInList(stationId);
                if (inList) {
                    String current = getStationStatusById(stationId);
                    System.out.println("[tryDeactivateStationById] Status sau navigate: '" + current + "'");
                    if (current.equalsIgnoreCase("Inactive")) {
                        System.out.println("[tryDeactivateStationById] " + stationId + " đã Inactive (sau navigate).");
                        return true;
                    }
                }
                String current = getStationStatusById(stationId);
                System.out.println("[tryDeactivateStationById] " + stationId
                    + " vẫn '" + current + "' sau confirm.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("[tryDeactivateStationById] Lỗi: " + e.getMessage());
            return false;
        }
    }

    /**
     * Tìm Station ID của trạm Active có thể deactivate thành công,
     * bỏ qua các ID trong excludedIds (VD: ST001 có ongoing session).
     *
     * Duyệt từng row Active, thử deactivate, nếu thành công trả về stationId.
     * Nếu thất bại, reload page và thử row tiếp theo.
     *
     * @return Station ID deactivate được, hoặc null nếu không có
     */
    public String findDeactivatableActiveStationId(java.util.Set<String> excludedIds) {
        System.out.println("[findDeactivatableActiveStationId] Tìm trạm Active có thể deactivate...");
        waitStationTableLoaded();

        // Lấy danh sách Station ID của tất cả row Active
        List<WebElement> activeRows = getStationRowsByStatus("Active");
        System.out.println("[findDeactivatableActiveStationId] Số row Active: " + activeRows.size());

        // Thu thập ID trước để tránh stale element sau reload
        List<String> activeIds = new java.util.ArrayList<>();
        for (WebElement row : activeRows) {
            String id = getStationIdFromRow(row);
            if (id != null && !id.isEmpty()) activeIds.add(id);
        }
        System.out.println("[findDeactivatableActiveStationId] Active IDs: " + activeIds);

        for (String stationId : activeIds) {
            if (excludedIds != null && excludedIds.contains(stationId)) {
                System.out.println("[findDeactivatableActiveStationId] Bỏ qua " + stationId);
                continue;
            }

            System.out.println("[findDeactivatableActiveStationId] Thử: " + stationId);
            boolean success = tryDeactivateStationById(stationId);
            if (success) {
                System.out.println("[findDeactivatableActiveStationId] Thành công: " + stationId);
                return stationId;
            }

            // Reload để reset state trước khi thử trạm tiếp theo
            System.out.println("[findDeactivatableActiveStationId] Reload và thử tiếp...");
            navigateToStationPage();
            waitStationTableLoaded();
        }

        System.out.println("[findDeactivatableActiveStationId] Không tìm thấy trạm nào deactivate được.");
        return null;
    }

    /**
     * Click toggle deactivate trong row của trạm Active đầu tiên.
     * Dùng CSS selector chính xác từ DOM thật.
     */
    public void clickInactiveFirstActiveStation() {
        System.out.println("[clickInactiveFirstActiveStation] Tìm row Active, click toggle...");
        waitStationTableLoaded();
        List<WebElement> activeRows = getStationRowsByStatus("Active");
        if (activeRows.isEmpty()) {
            throw new RuntimeException("[clickInactiveFirstActiveStation] Không có row Active nào.");
        }
        clickDeactivateToggleInRow(activeRows.get(0));
        System.out.println("[clickInactiveFirstActiveStation] Đã click.");
    }

    /**
     * Click toggle activate trong row của trạm Inactive đầu tiên.
     */
    public void clickActiveFirstInactiveStation() {
        System.out.println("[clickActiveFirstInactiveStation] Tìm row Inactive, click toggle...");
        waitStationTableLoaded();
        List<WebElement> inactiveRows = getStationRowsByStatus("Inactive");
        if (inactiveRows.isEmpty()) {
            throw new RuntimeException("[clickActiveFirstInactiveStation] Không có row Inactive nào.");
        }
        clickDeactivateToggleInRow(inactiveRows.get(0));
        System.out.println("[clickActiveFirstInactiveStation] Đã click.");
    }

    /**
     * Click toggle trong row chứa stationIdentifier (Station ID hoặc tên).
     * buttonText chỉ dùng để log.
     */
    public void clickToggleByStationName(String stationIdentifier, String buttonText) {
        System.out.println("[clickToggleByStationName] Trạm='" + stationIdentifier
            + "', action='" + buttonText + "'...");
        waitStationTableLoaded();
        debugPrintRowHtml(stationIdentifier);

        WebElement row = null;
        // Ưu tiên tìm theo data-id
        try {
            row = Constant.WEBDRIVER.findElement(
                By.cssSelector("tr[data-id='" + stationIdentifier + "']")
            );
        } catch (Exception e) {
            // Fallback: tìm theo text trong row
            By loc = By.xpath(
                "//table//tbody//tr[.//td[contains(normalize-space(),'" + stationIdentifier + "')]]"
            );
            List<WebElement> rows = Constant.WEBDRIVER.findElements(loc);
            if (!rows.isEmpty()) row = rows.get(0);
        }

        if (row == null) {
            throw new RuntimeException(
                "[clickToggleByStationName] Không tìm thấy row '" + stationIdentifier + "'"
            );
        }
        clickDeactivateToggleInRow(row);
        System.out.println("[clickToggleByStationName] Đã click.");
    }

    /**
     * In outerHTML của row chứa stationIdentifier để debug.
     */
    public void debugPrintRowHtml(String stationIdentifier) {
        String html = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var rows = document.querySelectorAll('table tbody tr');" +
            "for (var i = 0; i < rows.length; i++) {" +
            "  if ((rows[i].innerText || rows[i].textContent || '').indexOf(arguments[0]) !== -1) {" +
            "    return rows[i].outerHTML;" +
            "  }" +
            "}" +
            "return 'ROW NOT FOUND';",
            stationIdentifier
        );
        System.out.println("[debugPrintRowHtml] Row HTML cho '" + stationIdentifier + "':\n" + html);
    }

    public boolean isDeactivateActionAvailable(String stationIdentifier) {
        try {
            By loc = By.cssSelector("tr[data-id='" + stationIdentifier + "'] button[data-action='deactivate']");
            return !Constant.WEBDRIVER.findElements(loc).isEmpty();
        } catch (Exception e) { return false; }
    }

    /**
     * Kiểm tra popup deactivate/activate hiển thị.
     * Thử theo thứ tự: deactivateStationOverlay → native alert → swal2-popup.
     */
    public boolean isDeactivatePopupDisplayed() {
        // Thử overlay ID trước
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.visibilityOfElementLocated(deactivateOverlay));
            System.out.println("[isDeactivatePopupDisplayed] => true (overlay visible)");
            return true;
        } catch (Exception ignored) {}

        // Thử native alert
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            System.out.println("[isDeactivatePopupDisplayed] => true (native alert)");
            return true;
        } catch (Exception ignored) {}

        // Thử swal2
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.visibilityOfElementLocated(swal2Popup));
            System.out.println("[isDeactivatePopupDisplayed] => true (swal2)");
            return true;
        } catch (Exception ignored) {}

        System.out.println("[isDeactivatePopupDisplayed] => false");
        return false;
    }

    /**
     * Nhấn Confirm trong popup deactivate/activate.
     * Xử lý cả native alert và custom modal.
     */
    public void confirmDeactivate() {
        System.out.println("[confirmDeactivate] Xác nhận...");

        // Native alert trước
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().accept();
            System.out.println("[confirmDeactivate] Accepted native alert.");
            waitStationTableLoaded();
            return;
        } catch (Exception ignored) {}

        // Custom overlay confirm button — dùng JS click để bypass interactability
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(btnDeactivateConfirm));
            scrollIntoView(btn);
            try {
                btn.click();
            } catch (Exception ex) {
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript("arguments[0].click();", btn);
            }
            System.out.println("[confirmDeactivate] Clicked overlay confirm button.");
        } catch (Exception e) {
            // Fallback: JS click theo ID
            Boolean jsClicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var btn = document.getElementById('deactivateStationConfirmBtn');" +
                "if (btn) { btn.click(); return true; }" +
                "var swal = document.querySelector('.swal2-confirm');" +
                "if (swal) { swal.click(); return true; }" +
                "return false;"
            );
            System.out.println("[confirmDeactivate] JS fallback clicked: " + jsClicked);
        }

        // Chờ overlay đóng
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.invisibilityOfElementLocated(deactivateOverlay));
        } catch (Exception ignored) {}

        waitStationTableLoaded();
    }

    /**
     * Nhấn Cancel trong popup deactivate/activate.
     * Xử lý cả native alert và custom modal.
     */
    public void cancelDeactivate() {
        System.out.println("[cancelDeactivate] Hủy...");

        // Native alert
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().dismiss();
            System.out.println("[cancelDeactivate] Dismissed native alert.");
            return;
        } catch (Exception ignored) {}

        // Custom overlay cancel button — dùng JS click để bypass interactability
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfElementLocated(btnDeactivateCancel));
            scrollIntoView(btn);
            try {
                btn.click();
            } catch (Exception ex) {
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript("arguments[0].click();", btn);
            }
            System.out.println("[cancelDeactivate] Clicked overlay cancel button.");
        } catch (Exception e) {
            // Fallback: JS click theo ID
            Boolean jsClicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var btn = document.getElementById('deactivateStationCancelBtn');" +
                "if (btn) { btn.click(); return true; }" +
                "var swal = document.querySelector('.swal2-cancel');" +
                "if (swal) { swal.click(); return true; }" +
                "return false;"
            );
            System.out.println("[cancelDeactivate] JS fallback clicked: " + jsClicked);
        }

        // Chờ overlay đóng
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.invisibilityOfElementLocated(deactivateOverlay));
        } catch (Exception ignored) {}
    }

    /**
     * Chờ status của trạm đổi thành expectedStatus.
     * Dùng sau confirmDeactivate/confirmActivate.
     */
    public void waitStatusChanged(String stationName, String expectedStatus) {
        System.out.println("[waitStatusChanged] Chờ '" + stationName + "' → '" + expectedStatus + "'...");
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    String current = getStationStatusByName(stationName);
                    return current.toLowerCase().contains(expectedStatus.toLowerCase());
                });
            System.out.println("[waitStatusChanged] Status đã đổi.");
        } catch (Exception e) {
            System.out.println("[waitStatusChanged] Timeout — status hiện tại: "
                + getStationStatusByName(stationName));
        }
    }

    /** Lấy trạng thái của trạm đầu tiên trong bảng (cột Status) */
    public String getFirstStationStatus() {
        try {
            waitStationTableLoaded();
            return getText(By.cssSelector("table tbody tr:first-child td:nth-child(7)")).trim();
        } catch (Exception e) { return ""; }
    }

    /** Kiểm tra nút Inactive (ON) có hiển thị không */
    public boolean isInactiveButtonDisplayed() {
        return isPresent(btnDeactivateToggle);
    }

    /** Kiểm tra nút Active (OFF) có hiển thị không */
    public boolean isActiveButtonDisplayed() {
        return isPresent(btnActivateToggle);
    }

    /** Kiểm tra một locator bất kỳ có present không (public wrapper) */
    public boolean isLocatorPresent(By locator) {
        return isPresent(locator);
    }
}
