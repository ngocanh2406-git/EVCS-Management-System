package PageObjects;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GeneralPage {

    protected WebDriverWait wait = new WebDriverWait(
            Constant.WEBDRIVER,
            Duration.ofSeconds(Constant.SHORT_TIMEOUT)
    );

    // ===== Core wait helpers =====

    protected WebElement waitForVisible(By locator) {
        return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected WebElement waitForClickable(By locator) {
        return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.elementToBeClickable(locator));
    }

    protected WebElement find(By locator) {
        return waitForVisible(locator);
    }

    // ===== Safe interactions =====

    protected void safeClick(By locator) {
        WebElement el = waitForClickable(locator);
        scrollIntoView(el);
        try {
            el.click();
        } catch (Exception e) {
            jsClick(el);
        }
    }

    protected void click(By locator) {
        safeClick(locator);
    }

    protected void clickJS(By locator) {
        WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.presenceOfElementLocated(locator));
        jsClick(el);
    }

    protected void jsClick(WebElement el) {
        ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", el);
    }

    /**
     * safeType: clear + sendKeys với wait visible.
     * Nếu element không interactable, dùng JS set value + trigger events.
     */
    protected void safeType(By locator, String value) {
        // Chờ element present (không cần visible vì có thể bị overlay animation)
        WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.presenceOfElementLocated(locator));
        scrollIntoView(el);

        // Thử sendKeys trước
        try {
            el.clear();
            el.sendKeys(value);
            return;
        } catch (Exception ignored) {}

        // Fallback: JS focus + set value + trigger events
        jsSetValue(el, value);
    }

    protected void type(By locator, String value) {
        safeType(locator, value);
    }

    /**
     * Set value bằng JS + trigger input/change events.
     * Dùng khi element không interactable qua sendKeys.
     */
    protected void jsSetValue(WebElement el, String value) {
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript(
            "arguments[0].value = arguments[1];" +
            "arguments[0].dispatchEvent(new Event('input',  {bubbles:true}));" +
            "arguments[0].dispatchEvent(new Event('change', {bubbles:true}));" +
            "arguments[0].dispatchEvent(new Event('blur',   {bubbles:true}));",
            el, value
        );
    }

    protected void scrollIntoView(WebElement el) {
        try {
            ((JavascriptExecutor) Constant.WEBDRIVER)
                    .executeScript("arguments[0].scrollIntoView({block:'center', inline:'nearest'});", el);
        } catch (Exception ignored) {}
    }

    // ===== Presence / visibility checks =====

    protected boolean isDisplayed(By locator) {
        try {
            return waitForVisible(locator).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    protected boolean isPresent(By locator) {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                    .until(ExpectedConditions.presenceOfElementLocated(locator));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    protected boolean waitForInvisibility(By locator) {
        try {
            return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                    .until(ExpectedConditions.invisibilityOfElementLocated(locator));
        } catch (Exception e) {
            return false;
        }
    }

    // ===== Text / value =====

    protected String getText(By locator) {
        return find(locator).getText().trim();
    }

    public String getValue(By locator) {
        return find(locator).getAttribute("value");
    }

    // ===== Modal helpers =====

    /**
     * Chờ modal/overlay loading biến mất trước khi tương tác.
     */
    protected void waitForLoadingDisappear() {
        By loading = By.xpath(
            "//*[contains(@class,'loading') or contains(@class,'spinner') or contains(@class,'overlay')]"
            + "[not(contains(@class,'hidden')) and not(contains(@style,'display: none'))]"
        );
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                    .until(ExpectedConditions.invisibilityOfElementLocated(loading));
        } catch (Exception ignored) {}
    }

    /**
     * Chờ modal mở xong (có input visible bên trong).
     */
    protected void waitForModalOpen() {
        By modalInput = By.xpath(
            "//*[contains(@class,'modal') or contains(@class,'dialog') or contains(@class,'panel')]"
            + "//input[not(@type='hidden')]"
        );
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                    .until(ExpectedConditions.visibilityOfElementLocated(modalInput));
        } catch (Exception ignored) {}
    }

    // ===== Navigation =====

    public String getCurrentUrl() {
        return Constant.WEBDRIVER.getCurrentUrl();
    }

    protected String getPageTitle() {
        return Constant.WEBDRIVER.getTitle();
    }

    protected void refreshPage() {
        Constant.WEBDRIVER.navigate().refresh();
    }
}
