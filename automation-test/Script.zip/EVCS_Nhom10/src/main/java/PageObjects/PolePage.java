package PageObjects;

import Constant.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * PolePage - Page Object cho Pole Management
 * URL: https://evsc-production.up.railway.app/poles.html
 *
 * DOM xac nhan tu rendered page:
 *   Row:    <tr data-id="PL008">
 *   Status: <span class="status-badge status-badge--active">Active</span>
 *           <span class="status-badge status-badge--inactive">Inactive</span>
 *   Toggle: <button class="station-toggle is-on" title="ON">  (Active pole)
 *           <button class="station-toggle"        title="OFF"> (Inactive pole)
 *   Cot:    PoleID | Name | Manufacturer | Installed_at | Status | [toggle] | [edit]
 */
public class PolePage extends GeneralPage {

    // ===================================================================
    //  LOCATORS
    // ===================================================================

    private final By btnCreateNew   = By.xpath("//button[normalize-space()='Create New' or normalize-space()='Create new']");
    private final By tableRows      = By.cssSelector("table tbody tr[data-id]");
    private final By searchBox      = By.cssSelector("input[placeholder*='Search'], input[id*='search'], input[id*='Search']");

    // Confirm popup — ID that su tu log: pole-confirm-modal
    private final By poleConfirmModal   = By.id("pole-confirm-modal");
    private final By btnConfirmPopup    = By.cssSelector("#pole-confirm-modal button.btn-confirm, #pole-confirm-modal button[id*='confirm'], #pole-confirm-modal button[class*='confirm']");
    private final By btnCancelPopup     = By.cssSelector("#pole-confirm-modal button.btn-cancel, #pole-confirm-modal button[id*='cancel'], #pole-confirm-modal button[class*='cancel']");
    private final By deactivateOverlay  = By.id("deactivateStationOverlay");
    private final By swal2Popup         = By.cssSelector(".swal2-popup");
    private final By swal2Confirm       = By.cssSelector(".swal2-confirm");
    private final By swal2Cancel        = By.cssSelector(".swal2-cancel");
    private final By swal2Title         = By.cssSelector(".swal2-title");
    private final By toastAny           = By.xpath(
        "//*[contains(@class,'swal2') or contains(@class,'toast')" +
        " or contains(@class,'notification') or contains(@class,'alert-success')" +
        " or contains(@class,'alert-danger')][string-length(normalize-space(.))>0]"
    );

    // ===================================================================
    //  NAVIGATION
    // ===================================================================

    public void navigateToPolePage() {
        Constant.WEBDRIVER.navigate().to(Constant.POLE_URL);
        waitForPolePageReady();
    }

    public void waitForPolePageReady() {
        new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
            .until(driver -> ((JavascriptExecutor) driver)
                .executeScript("return document.readyState").equals("complete"));
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("table tbody tr")));
        } catch (Exception ignored) {}
    }

    public void waitPoleTableLoaded() {
        // Cho document ready truoc
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> ((JavascriptExecutor) driver)
                    .executeScript("return document.readyState").equals("complete"));
        } catch (Exception ignored) {}
        // Cho table co row HOAC trang hien thi "No poles found" (table genuinely empty)
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    List<WebElement> rows = driver.findElements(
                        By.cssSelector("table tbody tr, #poleTableBody tr"));
                    if (!rows.isEmpty()) return true;
                    // Kiem tra empty state
                    String body = driver.findElement(By.tagName("body")).getText();
                    return body.contains("No poles") || body.contains("No data") || body.contains("Pole List");
                });
            System.out.println("[waitPoleTableLoaded] Bang da load.");
        } catch (Exception e) {
            System.out.println("[waitPoleTableLoaded] Timeout.");
        }
    }

    public void refresh() {
        Constant.WEBDRIVER.navigate().refresh();
        waitForPolePageReady();
    }

    public void refreshAndWaitPolePage() {
        refresh();
        waitPoleTableLoaded();
    }

    public void acceptAlertIfPresent() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().accept();
        } catch (Exception ignored) {}
    }

    // ===================================================================
    //  TABLE ROWS
    // ===================================================================

    /** Lay tat ca row trong bang */
    public List<WebElement> getPoleRows() {
        waitPoleTableLoaded();
        return Constant.WEBDRIVER.findElements(tableRows);
    }

    /** Dem so row */
    public int getTableRowCount() {
        int count = getAllTableRows().size();
        System.out.println("[getTableRowCount] Row count: " + count);
        return count;
    }

    /** Lay ten pole tu row (td thu 2) */
    public String getPoleNameFromRow(WebElement row) {
        try {
            List<WebElement> tds = row.findElements(By.tagName("td"));
            if (tds.size() >= 2) return tds.get(1).getText().trim();
        } catch (Exception ignored) {}
        return "";
    }

    /** Lay status tu row (span.status-badge) */
    public String getPoleStatusFromRow(WebElement row) {
        try {
            // Uu tien class CSS chinh xac hon text
            List<WebElement> activeBadges = row.findElements(By.cssSelector(".status-badge--active"));
            if (!activeBadges.isEmpty() && activeBadges.get(0).isDisplayed()) return "Active";
            List<WebElement> inactiveBadges = row.findElements(By.cssSelector(".status-badge--inactive"));
            if (!inactiveBadges.isEmpty() && inactiveBadges.get(0).isDisplayed()) return "Inactive";
            // Fallback: doc text cua badge
            List<WebElement> badges = row.findElements(By.cssSelector(".status-badge"));
            if (!badges.isEmpty()) return badges.get(0).getText().trim();
        } catch (Exception ignored) {}
        return "";
    }

    /** Lay ten pole dau tien trong bang */
    public String getFirstPoleNameInTable() {
        List<WebElement> rows = getAllTableRows();
        for (WebElement row : rows) {
            String name = getPoleNameFromRow(row);
            if (!name.isEmpty()) return name;
        }
        return "";
    }

    /** Tim row theo ten pole */
    public WebElement findPoleRowByName(String poleName) {
        waitPoleTableLoaded();
        By loc = By.xpath(
            "//table//tbody//tr[.//td[normalize-space()='" + poleName + "']]"
        );
        try {
            return new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                .until(ExpectedConditions.presenceOfElementLocated(loc));
        } catch (Exception e) {
            System.out.println("[findPoleRowByName] Khong tim thay row: " + poleName);
            return null;
        }
    }

    /** Tim row dau tien co status khop */
    public WebElement findFirstPoleRowByStatus(String status) {
        waitPoleTableLoaded();
        By loc = By.xpath(
            "//table//tbody//tr[.//*[contains(@class,'status-badge') and normalize-space()='" + status + "']]"
        );
        List<WebElement> rows = Constant.WEBDRIVER.findElements(loc);
        if (!rows.isEmpty()) {
            System.out.println("[findFirstPoleRowByStatus] Tim thay row status='" + status + "'");
            return rows.get(0);
        }
        System.out.println("[findFirstPoleRowByStatus] Khong tim thay row status='" + status + "'");
        return null;
    }

    /** Lay status theo ten pole */
    public String getPoleStatusByName(String poleName) {
        WebElement row = findPoleRowByName(poleName);
        if (row != null) return getPoleStatusFromRow(row);
        return "";
    }

    /** Kiem tra toggle cua row co class is-on khong (Active) */
    public boolean isFirstPoleToggleOn() {
        List<WebElement> rows = getPoleRows();
        if (rows.isEmpty()) return false;
        try {
            List<WebElement> toggles = rows.get(0).findElements(
                By.cssSelector("button.station-toggle, button[data-action='deactivate']"));
            if (!toggles.isEmpty()) {
                String cls = toggles.get(0).getAttribute("class");
                return cls != null && cls.contains("is-on");
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ===================================================================
    //  CREATE FORM
    // ===================================================================

    /** Click nut Create New de mo form */
    public void clickCreateNew() {
        try {
            WebElement btn = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.elementToBeClickable(btnCreateNew));
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
            try { btn.click(); }
            catch (Exception e) {
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript("arguments[0].click();", btn);
            }
            // Cho form mo (input Name visible)
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("input[id*='Name'], input[id*='name'], input[placeholder*='Name'], input[placeholder*='name']")));
        } catch (Exception e) {
            System.out.println("[clickCreateNew] Loi: " + e.getMessage());
        }
    }

    /** Kiem tra form Create dang hien thi */
    public boolean isCreateFormDisplayed() {
        try {
            // Kiem tra theo aria-hidden cua panel (giong StationPage)
            String ariaHidden = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var panels = document.querySelectorAll('[class*=\"create-drawer\"], [id*=\"createPole\"], [id*=\"create-pole\"]');" +
                "for(var i=0;i<panels.length;i++){" +
                "  var a=panels[i].getAttribute('aria-hidden');" +
                "  if(a==='false') return 'open';" +
                "  if(a==='true') return 'closed';" +
                "}" +
                // Fallback: kiem tra input Name visible trong panel
                "var panels2 = document.querySelectorAll('[class*=\"drawer\"], [class*=\"create\"], [class*=\"panel\"]');" +
                "for(var p=0;p<panels2.length;p++){" +
                "  var s=window.getComputedStyle(panels2[p]);" +
                "  if(s.display==='none'||s.visibility==='hidden') continue;" +
                "  var rect=panels2[p].getBoundingClientRect();" +
                "  if(rect.width===0||rect.height===0) continue;" +
                // Panel phai nam trong viewport (khong bi slide ra ngoai)
                "  if(rect.right<=0||rect.left>=window.innerWidth) continue;" +
                "  var inputs=panels2[p].querySelectorAll('input');" +
                "  for(var i=0;i<inputs.length;i++){" +
                "    var is=window.getComputedStyle(inputs[i]);" +
                "    if(is.display!=='none'&&is.visibility!=='hidden') return 'open';" +
                "  }" +
                "}" +
                "return 'closed';"
            );
            return "open".equals(ariaHidden);
        } catch (Exception ignored) {}
        return false;
    }

    /** Lay title cua form Create */
    public String getFormTitle() {
        try {
            // Tim h2/h3/h4 hoac element co class title trong panel
            By[] titleLocs = {
                By.cssSelector("[class*='drawer'] h2, [class*='drawer'] h3, [class*='drawer'] h4"),
                By.cssSelector("[class*='create'] h2, [class*='create'] h3"),
                By.cssSelector("[class*='panel'] h2, [class*='panel'] h3"),
                By.cssSelector("h2, h3, h4")
            };
            for (By loc : titleLocs) {
                List<WebElement> els = Constant.WEBDRIVER.findElements(loc);
                for (WebElement el : els) {
                    if (el.isDisplayed()) {
                        String t = el.getText().trim();
                        if (!t.isEmpty()) return t;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    /** Dien thong tin vao form Create */
    public void fillCreateForm(String name, String manufacturer, String model, String connector) {
        enterPoleName(name);
        // Manufacturer
        try {
            WebElement el = findInputByHint("manufacturer", "Manufacturer");
            if (el != null) { el.clear(); el.sendKeys(manufacturer); }
        } catch (Exception ignored) {}
        // Model
        try {
            WebElement el = findInputByHint("model", "Model");
            if (el != null) { el.clear(); el.sendKeys(model); }
        } catch (Exception ignored) {}
        // Station: chon station dang Active (co station-badge--active hoac text Active)
        // Uu tien station chua co pole hoac station dau tien trong dropdown
        try {
            List<WebElement> selects = Constant.WEBDRIVER.findElements(
                By.cssSelector("select[id*='station'], select[id*='Station'], select[name*='station'], select[name*='Station']"));
            for (WebElement sel : selects) {
                if (!sel.isDisplayed()) continue;
                List<WebElement> opts = sel.findElements(By.tagName("option"));
                // Chon option dau tien co gia tri (khong phai placeholder/All)
                for (WebElement opt : opts) {
                    String val = opt.getAttribute("value");
                    String txt = opt.getText().trim();
                    if (val != null && !val.isEmpty() && !val.equals("") && !txt.equalsIgnoreCase("All")
                            && !txt.equalsIgnoreCase("Select") && !txt.isEmpty()) {
                        opt.click();
                        System.out.println("[fillCreateForm] Chon station: '" + txt + "'");
                        break;
                    }
                }
                break;
            }
        } catch (Exception ignored) {}
    }

    /** Nhap ten pole vao input Name */
    public void enterPoleName(String name) {
        try {
            WebElement el = findInputByHint("name", "Name");
            if (el != null) {
                el.clear();
                el.sendKeys(name);
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", el);
            }
        } catch (Exception e) {
            System.out.println("[enterPoleName] Loi: " + e.getMessage());
        }
    }

    /** Nhap manufacturer vao input */
    public void enterManufacturer(String value) {
        try {
            WebElement el = findInputByHint("manufacturer", "Manufacturer");
            if (el != null) {
                el.clear();
                el.sendKeys(value);
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", el);
            }
        } catch (Exception e) {
            System.out.println("[enterManufacturer] Loi: " + e.getMessage());
        }
    }

    /** Nhap model vao input */
    public void enterModel(String value) {
        try {
            WebElement el = findInputByHint("model", "Model");
            if (el != null) {
                el.clear();
                el.sendKeys(value);
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", el);
            }
        } catch (Exception e) {
            System.out.println("[enterModel] Loi: " + e.getMessage());
        }
    }

    /** Xoa trang field Pole Name */
    public void clearPoleName() {
        try {
            WebElement el = findInputByHint("name", "Name");
            if (el != null) {
                el.clear();
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].value=''; arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", el);
            }
        } catch (Exception ignored) {}
    }

    /** Xoa trang field Manufacturer */
    public void clearManufacturer() {
        try {
            WebElement el = findInputByHint("manufacturer", "Manufacturer");
            if (el != null) {
                el.clear();
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].value=''; arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", el);
            }
        } catch (Exception ignored) {}
    }

    /** Xoa trang field Model */
    public void clearModel() {
        try {
            WebElement el = findInputByHint("model", "Model");
            if (el != null) {
                el.clear();
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].value=''; arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", el);
            }
        } catch (Exception ignored) {}
    }

    /** Lay gia tri hien tai cua field Pole Name trong form */
    public String getPoleNameFieldValue() {
        try {
            WebElement el = findInputByHint("name", "Name");
            if (el != null) return el.getAttribute("value");
        } catch (Exception ignored) {}
        return "";
    }

    /**
     * Chon station theo index (0 = placeholder/All, 1 = option dau tien co gia tri).
     * Dung cho Edit form khi muon chon station cu the.
     */
    public void selectStationByIndex(int index) {
        try {
            List<WebElement> selects = Constant.WEBDRIVER.findElements(
                By.cssSelector("select[id*='station'], select[id*='Station'], select[name*='station'], select[name*='Station']"));
            for (WebElement sel : selects) {
                if (!sel.isDisplayed()) continue;
                List<WebElement> opts = sel.findElements(By.tagName("option"));
                if (index < opts.size()) {
                    opts.get(index).click();
                    System.out.println("[selectStationByIndex] Chon index " + index
                        + ": '" + opts.get(index).getText().trim() + "'");
                }
                break;
            }
        } catch (Exception e) {
            System.out.println("[selectStationByIndex] Loi: " + e.getMessage());
        }
    }

    /**
     * Chon connector list theo text (vi du: "1 connector", "2 connectors").
     */
    public void selectConnectorList(String connectorText) {
        try {
            List<WebElement> selects = Constant.WEBDRIVER.findElements(
                By.cssSelector("select[id*='connector'], select[id*='Connector'], select[name*='connector']"));
            for (WebElement sel : selects) {
                if (!sel.isDisplayed()) continue;
                List<WebElement> opts = sel.findElements(By.tagName("option"));
                for (WebElement opt : opts) {
                    if (opt.getText().trim().equalsIgnoreCase(connectorText)) {
                        opt.click();
                        System.out.println("[selectConnectorList] Chon: '" + connectorText + "'");
                        return;
                    }
                }
                // Fallback: chon option dau tien co gia tri
                for (WebElement opt : opts) {
                    String val = opt.getAttribute("value");
                    if (val != null && !val.isEmpty()) {
                        opt.click();
                        System.out.println("[selectConnectorList] Fallback chon: '" + opt.getText().trim() + "'");
                        return;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("[selectConnectorList] Loi: " + e.getMessage());
        }
    }

    /**
     * Click nut Edit cua tru dau tien trong bang.
     * Dung Selenium locator thuan, khong dung JS string dai.
     */
    public void clickEditFirstPole() {
        System.out.println("[clickEditFirstPole] Tim nut Edit...");

        // Lay tat ca row hop le
        List<WebElement> rows = getAllTableRows();
        if (rows.isEmpty()) {
            System.out.println("[clickEditFirstPole] Khong co row nao trong bang.");
            return;
        }

        // Tim row dau tien co ten hop le
        WebElement targetRow = null;
        for (WebElement row : rows) {
            String name = getPoleNameFromRow(row);
            if (!name.isEmpty()) {
                targetRow = row;
                System.out.println("[clickEditFirstPole] Chon row: '" + name + "'");
                break;
            }
        }
        if (targetRow == null) targetRow = rows.get(0);

        // Scroll row vao view
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].scrollIntoView({block:'center'});", targetRow);

        // Tim nut Edit trong row theo nhieu selector
        WebElement editBtn = findEditButtonInRow(targetRow);

        if (editBtn != null) {
            try {
                new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.SHORT_TIMEOUT))
                    .until(ExpectedConditions.elementToBeClickable(editBtn));
                editBtn.click();
            } catch (Exception e) {
                ((JavascriptExecutor) Constant.WEBDRIVER)
                    .executeScript("arguments[0].click();", editBtn);
            }
            System.out.println("[clickEditFirstPole] Da click Edit button.");
        } else {
            System.out.println("[clickEditFirstPole] Khong tim thay Edit button trong row.");
        }

        // Cho form mo
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> isCreateFormDisplayed());
            System.out.println("[clickEditFirstPole] Form da mo.");
        } catch (Exception e) {
            System.out.println("[clickEditFirstPole] Timeout cho form mo.");
        }
    }

    /**
     * Tim nut Edit trong mot row cu the.
     * Thu nhieu selector theo thu tu uu tien.
     */
    private WebElement findEditButtonInRow(WebElement row) {
        // 1. Button co class chua "edit"
        try {
            List<WebElement> btns = row.findElements(
                By.cssSelector("button[class*='edit'], button[class*='Edit']"));
            for (WebElement b : btns) {
                if (b.isDisplayed()) return b;
            }
        } catch (Exception ignored) {}

        // 2. Button co title/aria-label la "Edit"
        try {
            List<WebElement> btns = row.findElements(
                By.cssSelector("button[title*='Edit'], button[title*='edit'], button[aria-label*='Edit'], button[aria-label*='edit']"));
            for (WebElement b : btns) {
                if (b.isDisplayed()) return b;
            }
        } catch (Exception ignored) {}

        // 3. Icon pencil/edit ben trong button
        try {
            List<WebElement> icons = row.findElements(
                By.cssSelector("button i[class*='edit'], button i[class*='pencil'], button svg[class*='edit']"));
            for (WebElement icon : icons) {
                try {
                    WebElement btn = icon.findElement(By.xpath("./ancestor::button[1]"));
                    if (btn.isDisplayed()) return btn;
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}

        // 4. Link co class edit
        try {
            List<WebElement> links = row.findElements(
                By.cssSelector("a[class*='edit'], a[href*='edit']"));
            for (WebElement a : links) {
                if (a.isDisplayed()) return a;
            }
        } catch (Exception ignored) {}

        // 5. Bat ky button nao trong row (button cuoi cung thuong la Edit)
        try {
            List<WebElement> btns = row.findElements(By.tagName("button"));
            // Loc bo toggle button (station-toggle / pole-toggle)
            for (int i = btns.size() - 1; i >= 0; i--) {
                WebElement b = btns.get(i);
                if (!b.isDisplayed()) continue;
                String cls = b.getAttribute("class");
                if (cls != null && (cls.contains("toggle") || cls.contains("status"))) continue;
                String title = b.getAttribute("title");
                if (title != null && (title.equalsIgnoreCase("ON") || title.equalsIgnoreCase("OFF"))) continue;
                System.out.println("[findEditButtonInRow] Fallback button: class='" + cls + "', title='" + title + "'");
                return b;
            }
        } catch (Exception ignored) {}

        return null;
    }

    /** Tim input theo id/name/placeholder hint */
    private WebElement findInputByHint(String... hints) {
        for (String hint : hints) {
            try {
                List<WebElement> els = Constant.WEBDRIVER.findElements(
                    By.cssSelector("input[id*='" + hint + "'], input[name*='" + hint + "'], input[placeholder*='" + hint + "']"));
                for (WebElement el : els) {
                    if (el.isDisplayed()) return el;
                }
            } catch (Exception ignored) {}
        }
        return null;
    }

    /** Click nut Save trong form */
    public void clickSave() {
        Boolean clicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var btns = document.querySelectorAll('button');" +
            "for(var i=0;i<btns.length;i++){" +
            "  var t=(btns[i].innerText||btns[i].textContent||'').trim().toLowerCase();" +
            "  var id=(btns[i].id||'').toLowerCase();" +
            "  var s=window.getComputedStyle(btns[i]);" +
            "  var vis=s.display!=='none'&&s.visibility!=='hidden'&&btns[i].offsetParent!==null;" +
            "  if(vis&&(t==='save'||id.indexOf('save')!==-1)){" +
            "    btns[i].scrollIntoView({block:'center'});btns[i].click();return true;" +
            "  }" +
            "}" +
            "return false;"
        );
        System.out.println("[clickSave] clicked: " + clicked);
    }

    /** Click nut Cancel trong form — tim button Cancel trong panel dang mo */
    public void clickCancel() {
        // Tim Cancel button trong create drawer dang mo
        // Dung nhieu selector de tim chinh xac
        String[] cancelSelectors = {
            "#createPoleCancelBtn",
            "#poleCreateCancelBtn",
            "[id*='cancel'][id*='pole'], [id*='cancel'][id*='Pole']",
            "[id*='Cancel'][id*='create'], [id*='Cancel'][id*='Create']"
        };

        for (String sel : cancelSelectors) {
            try {
                List<WebElement> btns = Constant.WEBDRIVER.findElements(By.cssSelector(sel));
                for (WebElement btn : btns) {
                    if (btn.isDisplayed()) {
                        ((JavascriptExecutor) Constant.WEBDRIVER)
                            .executeScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", btn);
                        System.out.println("[clickCancel] Clicked via selector: " + sel);
                        waitCreateFormClosed();
                        return;
                    }
                }
            } catch (Exception ignored) {}
        }

        // Fallback: tim button Cancel trong panel dang mo (check viewport)
        Boolean clicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var panels = document.querySelectorAll('[class*=\"drawer\"], [class*=\"create\"], [class*=\"panel\"]');" +
            "for(var p=0;p<panels.length;p++){" +
            "  var rect=panels[p].getBoundingClientRect();" +
            "  if(rect.right<=0||rect.left>=window.innerWidth) continue;" +
            "  var s=window.getComputedStyle(panels[p]);" +
            "  if(s.display==='none'||s.visibility==='hidden') continue;" +
            "  var btns=panels[p].querySelectorAll('button');" +
            "  for(var i=0;i<btns.length;i++){" +
            "    var t=(btns[i].innerText||btns[i].textContent||'').trim().toLowerCase();" +
            "    var id=(btns[i].id||'').toLowerCase();" +
            "    var bs=window.getComputedStyle(btns[i]);" +
            "    var vis=bs.display!=='none'&&bs.visibility!=='hidden'&&btns[i].offsetParent!==null;" +
            "    if(vis&&(t==='cancel'||id.indexOf('cancel')!==-1)){" +
            "      btns[i].scrollIntoView({block:'center'});btns[i].click();return true;" +
            "    }" +
            "  }" +
            "}" +
            "return false;"
        );
        System.out.println("[clickCancel] JS fallback clicked: " + clicked);
        waitCreateFormClosed();
    }

    /** Cho form Create dong hoan toan */
    public void waitCreateFormClosed() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> !isCreateFormDisplayed());
            System.out.println("[waitCreateFormClosed] Form da dong.");
        } catch (Exception e) {
            System.out.println("[waitCreateFormClosed] Timeout — form co the van mo.");
        }
    }

    /** Kiem tra Save button co enabled khong */
    public boolean isSaveButtonEnabled() {
        try {
            List<WebElement> btns = Constant.WEBDRIVER.findElements(By.cssSelector("button"));
            for (WebElement btn : btns) {
                String t = (btn.getText() + " " + btn.getAttribute("id")).toLowerCase();
                if (t.contains("save") && btn.isDisplayed()) {
                    return btn.isEnabled() && !btn.getAttribute("class").contains("disabled");
                }
            }
        } catch (Exception ignored) {}
        return true; // mac dinh la enabled
    }

    /** Cho va lay text loi validation trong form */
    public String waitForFormError() {
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("[class*='error'], [class*='invalid'], [class*='text-danger'], [class*='alert-danger']")));
            return el.getText().trim();
        } catch (Exception ignored) {}
        return "";
    }

    /** Lay text loi trong form (khong wait) */
    public String getFormErrorText() {
        try {
            List<WebElement> errors = Constant.WEBDRIVER.findElements(
                By.cssSelector("[class*='error'], [class*='invalid'], [class*='text-danger'], [class*='alert-danger']"));
            for (WebElement el : errors) {
                if (el.isDisplayed()) {
                    String t = el.getText().trim();
                    if (!t.isEmpty()) return t;
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    /** Kiem tra pole co trong bang khong (theo ten) */
    public boolean isPoleInTable(String poleName) {
        try {
            List<WebElement> rows = getAllTableRows();
            for (WebElement row : rows) {
                if (getPoleNameFromRow(row).equals(poleName)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Cho pole xuat hien trong bang.
     * Reset tat ca filter, reload page, tim qua tat ca trang bang cach bam Next.
     */
    public boolean waitForPoleInTable(String poleName) {
        System.out.println("[waitForPoleInTable] Tim '" + poleName + "'...");

        // Buoc 1: Navigate lai Pole page sach (reset tat ca filter)
        navigateToPolePage();

        // Buoc 2: Reset station filter ve All neu co
        resetStationFilter();

        // Buoc 3: Cho table co du lieu lan dau
        waitForTableNonEmpty();

        // Buoc 4: Duyet tung trang bang cach bam Next lien tuc
        int maxPages = 50; // gioi han de tranh loop vo han
        for (int page = 1; page <= maxPages; page++) {
            System.out.println("[waitForPoleInTable] Kiem tra trang " + page + "...");

            // Kiem tra trang hien tai
            if (isPoleInTableAllRows(poleName)) {
                System.out.println("[waitForPoleInTable] Tim thay o trang " + page + ".");
                return true;
            }

            // Tim nut Next
            WebElement nextBtn = findNextPageButton();
            if (nextBtn == null) {
                System.out.println("[waitForPoleInTable] Khong con trang tiep theo (trang " + page + ").");
                break;
            }

            // Click Next va cho table load lai
            try {
                ((JavascriptExecutor) Constant.WEBDRIVER)
                    .executeScript("arguments[0].click();", nextBtn);
                waitForTableNonEmpty();
            } catch (Exception e) {
                System.out.println("[waitForPoleInTable] Loi click Next: " + e.getMessage());
                break;
            }
        }

        // Debug cuoi
        System.out.println("[waitForPoleInTable] Khong tim thay '" + poleName + "'.");
        System.out.println("  URL: " + Constant.WEBDRIVER.getCurrentUrl());
        List<WebElement> rows = getAllTableRows();
        System.out.println("  Row count: " + rows.size());
        for (int i = 0; i < Math.min(rows.size(), 5); i++) {
            try { System.out.println("  Row[" + i + "]: " + getPoleNameFromRow(rows.get(i))); }
            catch (Exception ignored) {}
        }
        return false;
    }

    /**
     * Tim nut Next pagination.
     * Tra ve null neu khong co hoac da bi disabled.
     */
    private WebElement findNextPageButton() {
        // Cac selector pho bien cho nut Next
        String[] selectors = {
            "button[aria-label*='Next'], button[aria-label*='next']",
            "a[aria-label*='Next'], a[aria-label*='next']",
            "button[class*='next'], a[class*='next']",
            "[class*='pagination'] button:last-child",
            "[class*='pagination'] a:last-child",
            "li.next button, li.next a",
            "li[class*='next'] button, li[class*='next'] a"
        };

        for (String sel : selectors) {
            try {
                List<WebElement> btns = Constant.WEBDRIVER.findElements(By.cssSelector(sel));
                for (WebElement btn : btns) {
                    if (!btn.isDisplayed()) continue;
                    // Kiem tra khong bi disabled
                    String disabled = btn.getAttribute("disabled");
                    String cls = btn.getAttribute("class");
                    boolean isDisabled = "true".equals(disabled)
                        || (cls != null && (cls.contains("disabled") || cls.contains("inactive")));
                    if (!isDisabled) {
                        System.out.println("[findNextPageButton] Found via: " + sel);
                        return btn;
                    }
                }
            } catch (Exception ignored) {}
        }

        // Fallback: tim button co text ">" hoac "Next" hoac "»"
        try {
            List<WebElement> allBtns = Constant.WEBDRIVER.findElements(
                By.cssSelector("[class*='pagination'] button, [class*='pagination'] a"));
            for (WebElement btn : allBtns) {
                if (!btn.isDisplayed()) continue;
                String text = btn.getText().trim();
                String disabled = btn.getAttribute("disabled");
                String cls = btn.getAttribute("class");
                boolean isDisabled = "true".equals(disabled)
                    || (cls != null && (cls.contains("disabled") || cls.contains("inactive")));
                if (!isDisabled && (text.equals(">") || text.equals("»")
                        || text.equalsIgnoreCase("Next") || text.equalsIgnoreCase("next"))) {
                    System.out.println("[findNextPageButton] Found via text: '" + text + "'");
                    return btn;
                }
            }
        } catch (Exception ignored) {}

        return null;
    }

    /** Cho table co it nhat 1 row (bat ky selector nao) */
    private void waitForTableNonEmpty() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> !getAllTableRows().isEmpty());
        } catch (Exception e) {
            System.out.println("[waitForTableNonEmpty] Timeout — table co the rong.");
        }
    }

    /** Lay tat ca row trong table, thu nhieu selector de khong bi miss */
    private List<WebElement> getAllTableRows() {
        // Thu selector co data-id truoc, fallback sang tat ca tr trong tbody
        List<WebElement> rows = Constant.WEBDRIVER.findElements(
            By.cssSelector("table tbody tr[data-id]"));
        if (!rows.isEmpty()) return rows;
        rows = Constant.WEBDRIVER.findElements(
            By.cssSelector("#poleTableBody tr"));
        if (!rows.isEmpty()) return rows;
        rows = new java.util.ArrayList<>(Constant.WEBDRIVER.findElements(
            By.cssSelector("table tbody tr")));
        // Loc bo row rong hoac row "no data"
        rows.removeIf(r -> {
            try {
                String text = r.getText().trim();
                return text.isEmpty() || text.toLowerCase().contains("no pole")
                    || text.toLowerCase().contains("no data");
            } catch (Exception e) { return true; }
        });
        if (!rows.isEmpty()) return rows;
        // Fallback cuoi: bat ky tr nao co it nhat 2 td
        rows = new java.util.ArrayList<>(Constant.WEBDRIVER.findElements(By.cssSelector("tr")));
        rows.removeIf(r -> {
            try {
                return r.findElements(By.tagName("td")).size() < 2;
            } catch (Exception e) { return true; }
        });
        return rows;
    }

    /** Kiem tra pole co trong bang khong — dung getAllTableRows thay vi getPoleRows */
    private boolean isPoleInTableAllRows(String poleName) {
        try {
            List<WebElement> rows = getAllTableRows();
            for (WebElement row : rows) {
                if (getPoleNameFromRow(row).equals(poleName)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Reset station filter ve All neu co */
    public void resetStationFilter() {
        try {
            // Tim select station filter
            List<WebElement> selects = Constant.WEBDRIVER.findElements(
                By.cssSelector("select[id*='station'], select[id*='Station'], select[name*='station']"));
            for (WebElement sel : selects) {
                if (!sel.isDisplayed()) continue;
                List<WebElement> opts = sel.findElements(By.tagName("option"));
                // Chon option dau tien (All)
                if (!opts.isEmpty()) {
                    opts.get(0).click();
                    System.out.println("[resetStationFilter] Reset station filter ve All.");
                    try { Thread.sleep(300); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    /** Clear o search */
    public void clearSearch() {
        try {
            List<WebElement> inputs = Constant.WEBDRIVER.findElements(searchBox);
            if (!inputs.isEmpty()) {
                WebElement input = inputs.get(0);
                input.clear();
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].value=''; arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", input);
                input.sendKeys(org.openqa.selenium.Keys.ENTER);
                try { Thread.sleep(300); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    /** Lay Pole ID auto-generate tu form (dang PL + so) */
    public String getGeneratedPoleId() {
        try {
            // Tim input read-only chua PL + so
            String id = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var inputs = document.querySelectorAll('input');" +
                "for(var i=0;i<inputs.length;i++){" +
                "  var v=(inputs[i].value||'').trim();" +
                "  if(/^PL\\d+/.test(v)) return v;" +
                "}" +
                "var all = document.querySelectorAll('span,p,div,h1,h2,h3,h4,small,label');" +
                "for(var i=0;i<all.length;i++){" +
                "  var t=(all[i].innerText||'').trim();" +
                "  var m=t.match(/PL\\d+/);" +
                "  if(m) return m[0];" +
                "}" +
                "return '';"
            );
            return id != null ? id : "";
        } catch (Exception e) {
            return "";
        }
    }

    public void searchPole(String keyword) {
        try {
            List<WebElement> inputs = Constant.WEBDRIVER.findElements(searchBox);
            if (!inputs.isEmpty()) {
                WebElement input = inputs.get(0);
                input.clear();
                input.sendKeys(keyword);
                // Trigger ca input event va Enter
                ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                    "arguments[0].dispatchEvent(new Event('input', {bubbles:true}));", input);
                input.sendKeys(org.openqa.selenium.Keys.ENTER);
                // Cho table update
                try { Thread.sleep(500); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    // ===================================================================
    //  TOGGLE CLICK
    // ===================================================================

    /**
     * Click toggle button trong mot row cu the.
     * DOM: button.station-toggle (Active: has is-on, Inactive: no is-on)
     * Dung Selenium click + JS fallback. KHONG dung JS string dai.
     */
    public void clickToggleInPoleRow(WebElement row) {
        System.out.println("[clickToggleInPoleRow] Tim toggle trong row...");
        // Tim button toggle trong row
        List<WebElement> toggleBtns = row.findElements(
            By.cssSelector("button.station-toggle, button[data-action='deactivate']")
        );
        if (toggleBtns.isEmpty()) {
            // Fallback: tim button co title ON hoac OFF
            toggleBtns = row.findElements(
                By.xpath(".//button[@title='ON' or @title='OFF']")
            );
        }
        if (toggleBtns.isEmpty()) {
            throw new RuntimeException("[clickToggleInPoleRow] Khong tim thay toggle button trong row");
        }
        WebElement btn = toggleBtns.get(0);
        System.out.println("[clickToggleInPoleRow] Toggle class='" + btn.getAttribute("class")
            + "', title='" + btn.getAttribute("title") + "'");
        // Scroll vao view
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
        // Click bang Selenium, fallback JS
        try {
            btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) Constant.WEBDRIVER).executeScript("arguments[0].click();", btn);
        }
        System.out.println("[clickToggleInPoleRow] Da click toggle.");
    }

    /**
     * Click toggle cua pole theo ten.
     * Tim dung row chua poleName, roi click toggle trong row do.
     */
    public void clickToggleByPoleName(String poleName) {
        System.out.println("[clickToggleByPoleName] Tim pole: " + poleName);
        WebElement row = findPoleRowByName(poleName);
        if (row == null) {
            throw new RuntimeException("[clickToggleByPoleName] Khong tim thay row: " + poleName);
        }
        // In HTML de debug
        String html = row.getAttribute("outerHTML");
        System.out.println("[clickToggleByPoleName] Row HTML: "
            + (html != null ? html.substring(0, Math.min(300, html.length())) : "null"));
        clickToggleInPoleRow(row);
    }

    /**
     * Click toggle cua pole dau tien co status khop.
     * Vi du: clickToggleFirstPoleByStatus("Inactive") de activate.
     */
    public void clickToggleFirstPoleByStatus(String status) {
        System.out.println("[clickToggleFirstPoleByStatus] Tim pole status='" + status + "'...");
        WebElement row = findFirstPoleRowByStatus(status);
        if (row == null) {
            throw new RuntimeException("[clickToggleFirstPoleByStatus] Khong co pole status='" + status + "'");
        }
        String poleName = getPoleNameFromRow(row);
        System.out.println("[clickToggleFirstPoleByStatus] Pole: " + poleName);
        clickToggleInPoleRow(row);
    }

    // ===================================================================
    //  CONFIRM POPUP
    // ===================================================================

    /** Kiem tra popup xac nhan dang hien thi — toi da 3s, check tat ca cung luc */
    public boolean isConfirmPopupDisplayed() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(3))
                .until(driver -> {
                    // Uu tien: pole-confirm-modal (ID that su tu log)
                    try {
                        WebElement el = driver.findElement(poleConfirmModal);
                        if (el.isDisplayed()) return true;
                    } catch (Exception ignored) {}
                    // Quet tat ca element co id/class lien quan den popup/modal/overlay
                    String found = (String) ((JavascriptExecutor) driver).executeScript(
                        "var candidates = document.querySelectorAll(" +
                        "  '[id*=\"pole\"][id*=\"confirm\"],[id*=\"pole\"][id*=\"modal\"]," +
                        "   [id*=\"pole\"][id*=\"overlay\"],[id*=\"confirm\"],[id*=\"modal\"]," +
                        "   [id*=\"overlay\"],[class*=\"modal\"],[class*=\"overlay\"]," +
                        "   .swal2-popup');" +
                        "for(var i=0;i<candidates.length;i++){" +
                        "  var s=window.getComputedStyle(candidates[i]);" +
                        "  if(s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'" +
                        "     &&candidates[i].offsetParent!==null){" +
                        "    return candidates[i].id||candidates[i].className;" +
                        "  }" +
                        "}" +
                        "return null;"
                    );
                    if (found != null) {
                        System.out.println("[isConfirmPopupDisplayed] Found visible: " + found);
                        return true;
                    }
                    try { driver.switchTo().alert(); return true; }
                    catch (Exception ignored) {}
                    return false;
                });
            System.out.println("[isConfirmPopupDisplayed] => true");
            return true;
        } catch (Exception ignored) {}
        System.out.println("[isConfirmPopupDisplayed] => false");
        return false;
    }

    public boolean isActivateConfirmPopupDisplayed() {
        return isConfirmPopupDisplayed();
    }

    /** Lay toan bo text cua confirm popup (pole-confirm-modal) */
    public String getConfirmPopupText() {
        try {
            String text = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var modal = document.getElementById('pole-confirm-modal');" +
                "if (!modal) {" +
                // Fallback: tim bat ky modal/popup visible nao
                "  var candidates = document.querySelectorAll('[class*=\"modal\"],[class*=\"popup\"],[class*=\"confirm\"]');" +
                "  for (var i = 0; i < candidates.length; i++) {" +
                "    var s = window.getComputedStyle(candidates[i]);" +
                "    if (s.display !== 'none' && s.visibility !== 'hidden' && candidates[i].offsetParent !== null) {" +
                "      modal = candidates[i]; break;" +
                "    }" +
                "  }" +
                "}" +
                "if (!modal) return '';" +
                "return (modal.innerText || modal.textContent || '').trim();"
            );
            return text != null ? text.trim() : "";
        } catch (Exception ignored) {}
        return "";
    }

    /** Kiem tra nut Confirm/Yes trong popup co hien thi khong */
    public boolean isConfirmButtonDisplayed() {
        try {
            Boolean result = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var modal = document.getElementById('pole-confirm-modal');" +
                "var scope = modal || document;" +
                "var btns = scope.querySelectorAll('button');" +
                "for (var i = 0; i < btns.length; i++) {" +
                "  var t = (btns[i].innerText || btns[i].textContent || '').trim().toLowerCase();" +
                "  var id = (btns[i].id || '').toLowerCase();" +
                "  var cls = (btns[i].className || '').toLowerCase();" +
                "  var s = window.getComputedStyle(btns[i]);" +
                "  var vis = s.display !== 'none' && s.visibility !== 'hidden' && btns[i].offsetParent !== null;" +
                "  if (vis && (t === 'yes' || t === 'confirm' || t === 'ok'" +
                "      || id.indexOf('confirm') !== -1 || cls.indexOf('confirm') !== -1" +
                "      || cls.indexOf('btn-yes') !== -1)) return true;" +
                "}" +
                "return false;"
            );
            return Boolean.TRUE.equals(result);
        } catch (Exception ignored) {}
        return false;
    }

    /** Kiem tra nut Cancel/No trong popup co hien thi khong */
    public boolean isCancelButtonDisplayed() {
        try {
            Boolean result = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var modal = document.getElementById('pole-confirm-modal');" +
                "var scope = modal || document;" +
                "var btns = scope.querySelectorAll('button');" +
                "for (var i = 0; i < btns.length; i++) {" +
                "  var t = (btns[i].innerText || btns[i].textContent || '').trim().toLowerCase();" +
                "  var id = (btns[i].id || '').toLowerCase();" +
                "  var cls = (btns[i].className || '').toLowerCase();" +
                "  var s = window.getComputedStyle(btns[i]);" +
                "  var vis = s.display !== 'none' && s.visibility !== 'hidden' && btns[i].offsetParent !== null;" +
                "  if (vis && (t === 'no' || t === 'cancel'" +
                "      || id.indexOf('cancel') !== -1 || cls.indexOf('cancel') !== -1" +
                "      || cls.indexOf('btn-no') !== -1)) return true;" +
                "}" +
                "return false;"
            );
            return Boolean.TRUE.equals(result);
        } catch (Exception ignored) {}
        return false;
    }

    /** Lay title cua popup */
    public String getConfirmPopupTitle() {
        // Uu tien: pole-confirm-modal (ID that su tu log)
        try {
            String title = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var modal = document.getElementById('pole-confirm-modal');" +
                "if (!modal) return null;" +
                "var s = window.getComputedStyle(modal);" +
                "if (s.display === 'none' || s.visibility === 'hidden') return null;" +
                // Tim h2/h3/h4/p/span co text trong modal
                "var tags = ['h1','h2','h3','h4','h5','p','span','div'];" +
                "for (var t = 0; t < tags.length; t++) {" +
                "  var els = modal.querySelectorAll(tags[t]);" +
                "  for (var i = 0; i < els.length; i++) {" +
                "    var text = (els[i].innerText || els[i].textContent || '').trim();" +
                "    if (text.length > 0 && text.length < 200) return text;" +
                "  }" +
                "}" +
                // Fallback: lay toan bo text cua modal
                "var full = (modal.innerText || modal.textContent || '').trim();" +
                "return full.length > 0 ? full.substring(0, 100) : null;"
            );
            if (title != null && !title.isEmpty()) {
                System.out.println("[getConfirmPopupTitle] pole-confirm-modal title: '" + title + "'");
                return title;
            }
        } catch (Exception ignored) {}
        // swal2 title
        try {
            WebElement el = Constant.WEBDRIVER.findElement(swal2Title);
            if (el.isDisplayed()) return el.getText().trim();
        } catch (Exception ignored) {}
        // Overlay text
        try {
            WebElement overlay = Constant.WEBDRIVER.findElement(deactivateOverlay);
            if (overlay.isDisplayed()) {
                String text = overlay.getText().trim();
                if (!text.isEmpty()) return text.substring(0, Math.min(100, text.length()));
            }
        } catch (Exception ignored) {}
        // Native alert
        try {
            return Constant.WEBDRIVER.switchTo().alert().getText();
        } catch (Exception ignored) {}
        return "";
    }

    /**
     * Debug: In tat ca element visible co the la popup sau khi click toggle.
     * Goi sau clickToggleInPoleRow de biet popup ID that su.
     */
    public void debugDumpVisiblePopups() {
        try {
            String info = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var result = 'Visible popup candidates:\\n';" +
                "var all = document.querySelectorAll('*');" +
                "for(var i=0;i<all.length;i++){" +
                "  var el=all[i];" +
                "  var id=el.id||'';" +
                "  var cls=el.className||'';" +
                "  var s=window.getComputedStyle(el);" +
                "  var isModal=(id.indexOf('modal')!==-1||id.indexOf('overlay')!==-1||" +
                "    id.indexOf('confirm')!==-1||id.indexOf('popup')!==-1||" +
                "    cls.indexOf('modal')!==-1||cls.indexOf('overlay')!==-1||" +
                "    cls.indexOf('swal')!==-1);" +
                "  if(isModal&&s.display!=='none'&&s.visibility!=='hidden'&&el.offsetParent!==null){" +
                "    result+='  id='+id+' class='+cls.substring(0,50)+'\\n';" +
                "  }" +
                "}" +
                "return result;"
            );
            System.out.println("[debugDumpVisiblePopups] " + info);
        } catch (Exception e) {
            System.out.println("[debugDumpVisiblePopups] Error: " + e.getMessage());
        }
    }

    /** Click Confirm trong popup — scan tat ca button Confirm/Yes visible */
    public void confirmActivate() {
        System.out.println("[confirmActivate] Click Confirm...");
        // Native alert
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().accept();
            System.out.println("[confirmActivate] Accepted native alert.");
            waitPoleTableLoaded();
            return;
        } catch (Exception ignored) {}

        // Scan tat ca button Confirm/Yes/OK visible trong bat ky popup nao
        Boolean clicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var btns = document.querySelectorAll('button');" +
            "for(var i=0;i<btns.length;i++){" +
            "  var b=btns[i];" +
            "  var t=(b.innerText||b.textContent||'').trim().toLowerCase();" +
            "  var id=(b.id||'').toLowerCase();" +
            "  var s=window.getComputedStyle(b);" +
            "  var visible=s.display!=='none'&&s.visibility!=='hidden'&&b.offsetParent!==null;" +
            "  if(visible&&(t==='confirm'||t==='yes'||t==='ok'||" +
            "     id.indexOf('confirm')!==-1||id.indexOf('yes')!==-1)){" +
            "    b.scrollIntoView({block:'center'});" +
            "    b.click();" +
            "    return true;" +
            "  }" +
            "}" +
            "return false;"
        );
        System.out.println("[confirmActivate] JS scan clicked: " + clicked);

        // Cho popup dong
        try { Thread.sleep(500); } catch (Exception ignored) {}
        waitPoleTableLoaded();
    }

    /** Click Cancel trong popup — scan tat ca button Cancel/No visible */
    public void cancelActivate() {
        System.out.println("[cancelActivate] Click Cancel...");
        // Native alert
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().dismiss();
            return;
        } catch (Exception ignored) {}

        // Scan tat ca button Cancel/No visible
        Boolean clicked = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
            "var btns = document.querySelectorAll('button');" +
            "for(var i=0;i<btns.length;i++){" +
            "  var b=btns[i];" +
            "  var t=(b.innerText||b.textContent||'').trim().toLowerCase();" +
            "  var id=(b.id||'').toLowerCase();" +
            "  var s=window.getComputedStyle(b);" +
            "  var visible=s.display!=='none'&&s.visibility!=='hidden'&&b.offsetParent!==null;" +
            "  if(visible&&(t==='cancel'||t==='no'||" +
            "     id.indexOf('cancel')!==-1||id.indexOf('no')!==-1)){" +
            "    b.scrollIntoView({block:'center'});" +
            "    b.click();" +
            "    return true;" +
            "  }" +
            "}" +
            "return false;"
        );
        System.out.println("[cancelActivate] JS scan clicked: " + clicked);
        try { Thread.sleep(300); } catch (Exception ignored) {}
    }

    // ===================================================================
    //  WAIT STATUS
    // ===================================================================

    /** Cho status cua pole doi thanh expectedStatus */
    public boolean waitPoleStatusChanged(String poleName, String expectedStatus) {
        System.out.println("[waitPoleStatusChanged] Cho '" + poleName + "' -> '" + expectedStatus + "'...");
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(Constant.MEDIUM_TIMEOUT))
                .until(driver -> {
                    String s = getPoleStatusByName(poleName);
                    return s.equalsIgnoreCase(expectedStatus);
                });
            System.out.println("[waitPoleStatusChanged] Status da doi.");
            return true;
        } catch (Exception e) {
            System.out.println("[waitPoleStatusChanged] Timeout. Status hien tai: " + getPoleStatusByName(poleName));
            return false;
        }
    }

    // ===================================================================
    //  TOAST / ALERT
    // ===================================================================

    /** Lay toast/alert message, khong throw exception neu khong co */
    public String getToastOrAlertMessageOptional() {
        // Native alert
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            String text = Constant.WEBDRIVER.switchTo().alert().getText();
            Constant.WEBDRIVER.switchTo().alert().accept();
            return text != null ? text : "";
        } catch (Exception ignored) {}
        // swal2 title
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.visibilityOfElementLocated(swal2Title));
            return el.getText().trim();
        } catch (Exception ignored) {}
        // Toast element
        try {
            WebElement el = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.visibilityOfElementLocated(toastAny));
            return el.getText().trim();
        } catch (Exception ignored) {}
        return "";
    }

    public boolean isAlertPresent() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            return true;
        } catch (Exception ignored) {}
        try {
            List<WebElement> toasts = Constant.WEBDRIVER.findElements(toastAny);
            return toasts.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception ignored) {}
        return false;
    }

    public String getAlertTextAndAccept() {
        // Cho alert xuat hien voi timeout du lon (5s) de khong bo lo
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(ExpectedConditions.alertIsPresent());
            String text = Constant.WEBDRIVER.switchTo().alert().getText();
            Constant.WEBDRIVER.switchTo().alert().accept();
            return text != null ? text : "";
        } catch (Exception ignored) {}
        // Fallback: toast/notification element
        try {
            List<WebElement> toasts = Constant.WEBDRIVER.findElements(toastAny);
            for (WebElement el : toasts) {
                if (el.isDisplayed()) return el.getText().trim();
            }
        } catch (Exception ignored) {}
        return "";
    }

    // ===================================================================
    //  LEGACY (giu lai de khong break code cu)
    // ===================================================================

    public void clickCreate() {
        click(btnCreateNew);
    }

    /** @deprecated Dung clickToggleByPoleName hoac clickToggleFirstPoleByStatus thay the */
    @Deprecated
    public void clickToggleFirstPole() {
        clickToggleFirstPoleByStatus("Inactive");
    }

    /**
     * Deactivate mot pole Active de tao pole Inactive thuoc station Active.
     * Khong phu thuoc vao popup — kiem tra status doi sau khi click.
     * @return ten pole da deactivate, hoac null neu that bai
     */
    public String deactivateActivePoleForSetup() {
        System.out.println("[deactivateActivePoleForSetup] Tim pole Active de deactivate...");
        WebElement activeRow = findFirstPoleRowByStatus("Active");
        if (activeRow == null) {
            System.out.println("[deactivateActivePoleForSetup] Khong co pole Active.");
            return null;
        }
        String poleName = getPoleNameFromRow(activeRow);
        System.out.println("[deactivateActivePoleForSetup] Deactivate pole: " + poleName);
        clickToggleInPoleRow(activeRow);

        // Kiem tra popup
        if (isConfirmPopupDisplayed()) {
            confirmActivate();
        }

        // Cho status doi thanh Inactive (co hoac khong co popup)
        boolean changed = waitPoleStatusChanged(poleName, "Inactive");
        String status = getPoleStatusByName(poleName);
        System.out.println("[deactivateActivePoleForSetup] Status sau deactivate: " + status + ", changed: " + changed);
        if (status.equalsIgnoreCase("Inactive")) {
            return poleName;
        }
        return null;
    }

    // ===================================================================
    //  VIEW DETAIL
    // ===================================================================

    /**
     * Lay Pole ID tu row dau tien trong bang (cot thu 1: PoleID).
     */
    public String getFirstPoleIdInTable() {
        List<WebElement> rows = getAllTableRows();
        for (WebElement row : rows) {
            try {
                List<WebElement> tds = row.findElements(By.tagName("td"));
                if (!tds.isEmpty()) {
                    String id = tds.get(0).getText().trim();
                    if (!id.isEmpty()) return id;
                }
            } catch (Exception ignored) {}
        }
        return "";
    }

    /**
     * Click vao row dau tien trong bang de mo detail view.
     * Thu click vao ten pole (td thu 2) hoac row chinh.
     */
    public void clickFirstPoleInTable() {
        System.out.println("[clickFirstPoleInTable] Click row dau tien...");
        List<WebElement> rows = getAllTableRows();
        if (rows.isEmpty()) {
            System.out.println("[clickFirstPoleInTable] Khong co row.");
            return;
        }
        WebElement row = rows.get(0);
        ((JavascriptExecutor) Constant.WEBDRIVER)
            .executeScript("arguments[0].scrollIntoView({block:'center'});", row);

        // Thu click vao td thu 2 (Name) truoc
        try {
            List<WebElement> tds = row.findElements(By.tagName("td"));
            if (tds.size() >= 2) {
                tds.get(1).click();
                System.out.println("[clickFirstPoleInTable] Click vao Name cell.");
            } else {
                row.click();
                System.out.println("[clickFirstPoleInTable] Click vao row.");
            }
        } catch (Exception e) {
            ((JavascriptExecutor) Constant.WEBDRIVER)
                .executeScript("arguments[0].click();", row);
        }

        // Cho detail view hien thi (toi da 5s)
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(5))
                .until(driver -> isDetailViewDisplayed());
        } catch (Exception ignored) {}
    }

    /**
     * Kiem tra detail view dang hien thi.
     * Tim panel/drawer/modal co chua thong tin chi tiet pole.
     */
    public boolean isDetailViewDisplayed() {
        try {
            Boolean result = (Boolean) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var selectors = [" +
                "  '[id*=\"detail\"][id*=\"pole\"], [id*=\"pole\"][id*=\"detail\"]'," +
                "  '[class*=\"detail\"][class*=\"pole\"], [class*=\"pole\"][class*=\"detail\"]'," +
                "  '[id*=\"poleDetail\"], [id*=\"pole-detail\"]'," +
                "  '[class*=\"detail-panel\"], [class*=\"detail-drawer\"]'," +
                "  '[id*=\"detail\"], [class*=\"detail-view\"]'" +
                "];" +
                "for (var s = 0; s < selectors.length; s++) {" +
                "  var els = document.querySelectorAll(selectors[s]);" +
                "  for (var i = 0; i < els.length; i++) {" +
                "    var st = window.getComputedStyle(els[i]);" +
                "    var rect = els[i].getBoundingClientRect();" +
                "    if (st.display !== 'none' && st.visibility !== 'hidden'" +
                "        && rect.width > 0 && rect.height > 0" +
                "        && rect.left < window.innerWidth && rect.right > 0) {" +
                "      return true;" +
                "    }" +
                "  }" +
                "}" +
                "return false;"
            );
            return Boolean.TRUE.equals(result);
        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Kiem tra list view (bang danh sach) dang hien thi.
     */
    public boolean isListViewDisplayed() {
        try {
            List<WebElement> rows = getAllTableRows();
            return !rows.isEmpty();
        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Lay text cua mot field trong detail view theo label.
     * Tim label chua labelText roi lay gia tri ke ben.
     */
    private String getDetailFieldByLabel(String... labelHints) {
        try {
            String result = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var hints = arguments[0];" +
                "var allEls = document.querySelectorAll('label, th, td, dt, span, p, div, h1, h2, h3, h4, h5, strong, b');" +
                "for (var h = 0; h < hints.length; h++) {" +
                "  var hint = hints[h].toLowerCase();" +
                "  for (var i = 0; i < allEls.length; i++) {" +
                "    var el = allEls[i];" +
                "    var text = (el.innerText || el.textContent || '').trim().toLowerCase();" +
                "    if (text === hint || text.startsWith(hint + ':') || text.startsWith(hint + ' ')) {" +
                "      var st = window.getComputedStyle(el);" +
                "      if (st.display === 'none' || st.visibility === 'hidden') continue;" +
                "      var next = el.nextElementSibling;" +
                "      if (next) {" +
                "        var val = (next.innerText || next.textContent || '').trim();" +
                "        if (val.length > 0) return val;" +
                "      }" +
                "      var parent = el.parentElement;" +
                "      if (parent) {" +
                "        var siblings = parent.children;" +
                "        for (var j = 0; j < siblings.length; j++) {" +
                "          if (siblings[j] === el) continue;" +
                "          var sv = (siblings[j].innerText || siblings[j].textContent || '').trim();" +
                "          if (sv.length > 0) return sv;" +
                "        }" +
                "      }" +
                "    }" +
                "  }" +
                "}" +
                "return '';",
                (Object) labelHints
            );
            return result != null ? result.trim() : "";
        } catch (Exception ignored) {}
        return "";
    }

    /**
     * Lay tat ca text trong detail panel.
     * Dung lam fallback khi khong tim duoc theo label.
     */
    private String getDetailPanelText() {
        try {
            String text = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var selectors = [" +
                "  '[id*=\"poleDetail\"], [id*=\"pole-detail\"]'," +
                "  '[class*=\"detail-panel\"], [class*=\"detail-drawer\"]'," +
                "  '[id*=\"detail\"], [class*=\"detail-view\"]'" +
                "];" +
                "for (var s = 0; s < selectors.length; s++) {" +
                "  var els = document.querySelectorAll(selectors[s]);" +
                "  for (var i = 0; i < els.length; i++) {" +
                "    var st = window.getComputedStyle(els[i]);" +
                "    var rect = els[i].getBoundingClientRect();" +
                "    if (st.display !== 'none' && st.visibility !== 'hidden'" +
                "        && rect.width > 0 && rect.height > 0) {" +
                "      return (els[i].innerText || els[i].textContent || '').trim();" +
                "    }" +
                "  }" +
                "}" +
                "return '';"
            );
            return text != null ? text.trim() : "";
        } catch (Exception ignored) {}
        return "";
    }

    public String getDetailPoleName() {
        String v = getDetailFieldByLabel("pole name", "name", "ten tru", "ten");
        if (!v.isEmpty()) return v;
        // Fallback: lay tu panel text
        return "";
    }

    public String getDetailPoleId() {
        String v = getDetailFieldByLabel("pole id", "id", "ma tru");
        if (!v.isEmpty()) return v;
        return "";
    }

    public String getDetailManufacturer() {
        return getDetailFieldByLabel("manufacturer", "nha san xuat", "hang san xuat");
    }

    public String getDetailModel() {
        return getDetailFieldByLabel("model", "mo hinh");
    }

    public String getDetailStatus() {
        String v = getDetailFieldByLabel("status", "trang thai");
        if (!v.isEmpty()) return v;
        // Fallback: tim badge trong detail panel
        try {
            String badge = (String) ((JavascriptExecutor) Constant.WEBDRIVER).executeScript(
                "var badges = document.querySelectorAll('.status-badge, [class*=\"status\"]');" +
                "for (var i = 0; i < badges.length; i++) {" +
                "  var st = window.getComputedStyle(badges[i]);" +
                "  if (st.display !== 'none' && st.visibility !== 'hidden') {" +
                "    var t = (badges[i].innerText || badges[i].textContent || '').trim();" +
                "    if (t.length > 0) return t;" +
                "  }" +
                "}" +
                "return '';"
            );
            return badge != null ? badge.trim() : "";
        } catch (Exception ignored) {}
        return "";
    }

    public String getDetailActiveCode() {
        return getDetailFieldByLabel("active code", "activation code", "ma kich hoat", "code");
    }

    /**
     * Click nut quay lai / dong detail view (X, Back, Close).
     */
    public void clickBackToList() {
        System.out.println("[clickBackToList] Tim nut Back/Close...");

        // 1. Tim nut co aria-label/title Close/Back
        String[] closeSelectors = {
            "button[aria-label*='Close'], button[aria-label*='close']",
            "button[aria-label*='Back'], button[aria-label*='back']",
            "button[title*='Close'], button[title*='close']",
            "button[title*='Back'], button[title*='back']",
            "button[class*='close'], button[class*='Close']",
            "button[class*='back'], button[class*='Back']",
            "[id*='close'], [id*='Close']",
            "[id*='back'], [id*='Back']"
        };

        for (String sel : closeSelectors) {
            try {
                List<WebElement> btns = Constant.WEBDRIVER.findElements(By.cssSelector(sel));
                for (WebElement btn : btns) {
                    if (btn.isDisplayed()) {
                        ((JavascriptExecutor) Constant.WEBDRIVER)
                            .executeScript("arguments[0].click();", btn);
                        System.out.println("[clickBackToList] Clicked: " + sel);
                        try { Thread.sleep(500); } catch (Exception ignored) {}
                        return;
                    }
                }
            } catch (Exception ignored) {}
        }

        // 2. Tim nut × (text)
        try {
            List<WebElement> btns = Constant.WEBDRIVER.findElements(By.tagName("button"));
            for (WebElement btn : btns) {
                if (!btn.isDisplayed()) continue;
                String t = btn.getText().trim();
                if (t.equals("×") || t.equals("✕") || t.equals("✖") || t.equalsIgnoreCase("close")
                        || t.equalsIgnoreCase("back") || t.equalsIgnoreCase("quay lai")) {
                    ((JavascriptExecutor) Constant.WEBDRIVER)
                        .executeScript("arguments[0].click();", btn);
                    System.out.println("[clickBackToList] Clicked text button: '" + t + "'");
                    try { Thread.sleep(500); } catch (Exception ignored) {}
                    return;
                }
            }
        } catch (Exception ignored) {}

        // 3. Fallback: navigate lai trang
        System.out.println("[clickBackToList] Fallback: navigate lai trang.");
        navigateToPolePage();
    }
}
