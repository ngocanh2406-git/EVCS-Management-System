package Common;

import Constant.Constant;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

public class ScreenshotHelper {

    /**
     * Dismiss bất kỳ alert nào đang mở trước khi chụp screenshot.
     * Tránh UnhandledAlertException khi Selenium cố chụp màn hình.
     */
    private static void dismissAlertIfPresent() {
        try {
            new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(2))
                .until(ExpectedConditions.alertIsPresent());
            Constant.WEBDRIVER.switchTo().alert().accept();
        } catch (Exception ignored) {}
    }

    /**
     * Chụp màn hình và lưu vào thư mục screenshots/ với tên = testName + timestamp.
     * Được gọi tự động trong BaseTest khi test FAIL.
     *
     * @param testName tên method test (lấy từ ITestResult.getName())
     */
    public static String takeScreenshot(String testName) {
        try {
            dismissAlertIfPresent();
            TakesScreenshot ts = (TakesScreenshot) Constant.WEBDRIVER;
            File source = ts.getScreenshotAs(OutputType.FILE);

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String fileName  = testName + "_" + timestamp + ".png";
            String path      = Constant.SCREENSHOT_DIR + fileName;

            File destination = new File(path);
            destination.getParentFile().mkdirs();
            FileHandler.copy(source, destination);

            System.out.println("[Screenshot] Saved: " + path);
            return path;

        } catch (IOException e) {
            System.err.println("[Screenshot] Failed to capture: " + e.getMessage());
            return null;
        }
    }

    /**
     * Chụp màn hình và lưu vào thư mục Evidence/screenshots/ (dùng khi gom evidence).
     *
     * @param testName tên method test
     */
    public static String takeEvidenceScreenshot(String testName) {
        try {
            dismissAlertIfPresent();
            TakesScreenshot ts = (TakesScreenshot) Constant.WEBDRIVER;
            File source = ts.getScreenshotAs(OutputType.FILE);

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String fileName  = testName + "_" + timestamp + ".png";
            String path      = Constant.EVIDENCE_DIR + "screenshots/" + fileName;

            File destination = new File(path);
            destination.getParentFile().mkdirs();
            FileHandler.copy(source, destination);

            System.out.println("[Evidence Screenshot] Saved: " + path);
            return path;

        } catch (IOException e) {
            System.err.println("[Evidence Screenshot] Failed: " + e.getMessage());
            return null;
        }
    }
}
