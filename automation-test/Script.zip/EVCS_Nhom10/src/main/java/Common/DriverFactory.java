package Common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DriverFactory {

    /**
     * Khởi tạo ChromeDriver với các options cơ bản.
     * WebDriverManager không cần thiết với Selenium 4.6+ (tự quản lý driver).
     */
    public static WebDriver initChromeDriver() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--remote-allow-origins=*");
        return new ChromeDriver(options);
    }

    /**
     * Khởi tạo ChromeDriver chạy headless (dùng cho CI/CD).
     */
    public static WebDriver initChromeDriverHeadless() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new");
        options.addArguments("--window-size=1920,1080");
        options.addArguments("--disable-notifications");
        options.addArguments("--remote-allow-origins=*");
        return new ChromeDriver(options);
    }
}
